package com.prestige.mod.command;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Player-triggered prestige. A player runs /prestige; if their current NXP
 * meets the requirement for their next tier, they prestige: NXP resets to 0,
 * their rank/cap bumps up, all previously-granted kekkei genkai/releases are
 * wiped and they're granted exactly one new one for the tier, any "release"
 * items in inventory are cleared, and their prestige count goes up by 1.
 *
 * SETUP REQUIRED:
 *   1. Run one_time_setup_commands.txt once in console (creates the 12 ranks
 *      + the "prestige" scoreboard objective).
 *   2. Fill in NXP_TAG_PATH below once you've found it with NBTExplorer.
 *   3. Fill in RELEASE_TAG_PATHS_TO_CLEAR below (see the comment above it) —
 *      there's no native command to remove a granted release, so this is
 *      done by editing the player's own saved capability data directly.
 *   4. Fill in RELEASE_ITEMS_TO_CLEAR below with the actual item registry
 *      names of anything that should be wiped from inventory on prestige.
 */
public class CommandPrestige extends CommandBase {

    // Confirmed via NBTExplorer: NXP lives directly in ForgeData (not
    // nested further), under the key "battle_experience".
    private static final String[] NXP_TAG_PATH = { "ForgeData", "battle_experience" };

    // CONFIRMED against the actual mod jar: these kekkei genkai are not
    // tracked by any hidden NBT flag at all - each one IS a specific real
    // item (dojutsu ones sit in the helmet armor slot; Shikotsumyaku/Dust/
    // Wood are held items). Owning the item is the unlock. So resetting a
    // release just means removing the matching item(s) - see
    // RELEASE_ITEMS_TO_CLEAR below. No NBT surgery needed after all.
    private static final String[][] RELEASE_TAG_PATHS_TO_CLEAR = {
    };

    // Updated tier thresholds.
    private static final int[] TIER_CAPS = {
            5000, 7500, 15000, 25000, 50000, 75000,
            100000, 125000, 150000, 175000, 200000, 250000
    };

    // CONFIRMED spellings via in-game tab-completion on /giveNinjaRelease.
    // Note: in this mod, "particle" is the token for Dust Release (not a
    // separate Particle Release) - confirmed directly.
    private static final String[][] TIER_KEKKEI_GENKAI = {
            /* tier 1  */ { "ice", "lava" },
            /* tier 2  */ { "byakugan", "bone" },
            /* tier 3  */ { "ice", "lava", "byakugan", "bone", "explosion", "scorch" },
            /* tier 4  */ { "ice", "lava", "byakugan", "bone", "explosion", "scorch" },
            /* tier 5  */ { "ice", "lava", "byakugan", "bone", "explosion", "scorch" },
            /* tier 6  */ { "sharingan" },
            /* tier 7  */ { "ice", "lava", "byakugan", "bone", "explosion", "scorch", "sharingan", "storm" },
            /* tier 8  */ { "particle" }, // Dust Release
            /* tier 9  */ { "ice", "lava", "byakugan", "bone", "explosion", "scorch", "sharingan", "storm", "particle", "gates", "magnet" },
            /* tier 10 */ { "wood" },
            /* tier 11 */ { "rinnegan" },
            /* tier 12 */ { "tenseigan" },
    };

    // true = randomly grant exactly one entry from that tier's list.
    // false = grant every entry in that tier's list.
    private static final boolean[] TIER_RANDOM_PICK = {
            /* tier 1  */ true,
            /* tier 2  */ true,
            /* tier 3  */ true,
            /* tier 4  */ true,
            /* tier 5  */ true,
            /* tier 6  */ false,
            /* tier 7  */ true,
            /* tier 8  */ false,
            /* tier 9  */ true,
            /* tier 10 */ false,
            /* tier 11 */ false,
            /* tier 12 */ false,
    };

    private static final java.util.Random RANDOM = new java.util.Random();

    // Which granted /giveNinjaRelease tokens correspond to "eye" dojutsu
    // items that need their ownership NBT (player_idMost/player_idLeast)
    // patched to the recipient - confirmed these items don't self-bind the
    // way the elemental "learner" items do, and are otherwise left pointing
    // at whatever random UUID /giveNinjaRelease happened to stamp them
    // with, causing the game to treat them as someone else's (blindness).
    private static final Map<String, String[]> DOJUTSU_ITEMS_TO_BIND = new HashMap<>();
    private static final Map<String, String> DOJUTSU_DISPLAY_NAME = new HashMap<>();
    static {
        DOJUTSU_ITEMS_TO_BIND.put("byakugan", new String[]{ "narutomod:byakuganhelmet" });
        DOJUTSU_DISPLAY_NAME.put("byakugan", "Byakugan");

        DOJUTSU_ITEMS_TO_BIND.put("sharingan", new String[]{ "narutomod:sharinganhelmet" });
        DOJUTSU_DISPLAY_NAME.put("sharingan", "Sharingan");

        DOJUTSU_ITEMS_TO_BIND.put("rinnegan", new String[]{
                "narutomod:rinneganhelmet", "narutomod:rinneganbody", "narutomod:rinneganlegs" });
        DOJUTSU_DISPLAY_NAME.put("rinnegan", "Rinnegan");

        DOJUTSU_ITEMS_TO_BIND.put("tenseigan", new String[]{
                "narutomod:tenseiganhelmet", "narutomod:tenseiganbody", "narutomod:tenseiganlegs" });
        DOJUTSU_DISPLAY_NAME.put("tenseigan", "Tenseigan");
    }

    // CONFIRMED against the actual mod jar (item registrations + models) -
    // these are the real items backing each kekkei genkai this prestige
    // system grants. Rinnegan and Tenseigan are 3-piece armor sets (no
    // boots piece exists for either - checked, not just an oversight).
    private static final String[] RELEASE_ITEMS_TO_CLEAR = {
            "narutomod:tenseiganhelmet",
            "narutomod:tenseiganbody",
            "narutomod:tenseiganlegs",
    };

    @Override
    public String getName() {
        return "prestige";
    }

    @Override
    public String getUsage(ICommandSender sender) {
        return "/prestige";
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 0; // any player can try
    }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (!(sender.getCommandSenderEntity() instanceof EntityPlayerMP)) {
            throw new CommandException("Only players can use /prestige.");
        }
        EntityPlayerMP player = (EntityPlayerMP) sender.getCommandSenderEntity();

        int prestige = getPrestigeScore(player);
        if (prestige >= TIER_CAPS.length) {
            player.sendMessage(new TextComponentString("You're already at max prestige."));
            return;
        }

        Integer nxp = readNxp(player);
        if (nxp == null) {
            throw new CommandException("Could not read your current NXP — NXP_TAG_PATH isn't set up yet.");
        }

        int requiredCap = TIER_CAPS[prestige];
        if (nxp < requiredCap) {
            player.sendMessage(new TextComponentString(
                    "You need " + requiredCap + " NXP to prestige (you currently have " + nxp + ")."));
            return;
        }

        int nextPrestige = prestige + 1;
        String nextRank = "Prestige" + nextPrestige;
        String[] tierPool = TIER_KEKKEI_GENKAI[nextPrestige - 1];
        boolean randomPick = TIER_RANDOM_PICK[nextPrestige - 1];
        String[] kekkeiGenkaiForTier;
        if (randomPick && tierPool.length > 0) {
            kekkeiGenkaiForTier = new String[]{ tierPool[RANDOM.nextInt(tierPool.length)] };
        } else {
            kekkeiGenkaiForTier = tierPool;
        }

        // Bump their enforced cap to the next tier FIRST - confirmed via
        // testing that /addninjaxp does genuinely subtract when run
        // directly, so the earlier "doesn't reset" bug was actually the
        // rank change running before the reset and re-inflating XP back up
        // to that rank's own floor. Doing the reset LAST avoids that.
        server.getCommandManager().executeCommand(server, "rank add " + player.getName() + " " + nextRank);

        // Clear any previously-granted release items BEFORE granting the new
        // one(s) - this has to happen first, or a newly-granted item that's
        // also on the clear list gets swept away right after being given.
        clearReleaseItems(player);

        // Track prestige count.
        setPrestigeScore(player, nextPrestige);

        // Grant every kekkei genkai configured for this tier (may be zero, one, or several).
        for (String genkai : kekkeiGenkaiForTier) {
            server.getCommandManager().executeCommand(server, "giveNinjaRelease " + player.getName() + " " + genkai);
            if (DOJUTSU_ITEMS_TO_BIND.containsKey(genkai)) {
                bindDojutsuOwnership(player, genkai);
            }
        }

        // Reset NXP back to 0 LAST, via the confirmed-working command, so
        // nothing runs afterward that could re-inflate it.
        server.getCommandManager().executeCommand(server, "addninjaxp " + player.getName() + " -" + nxp);

        int newCapDisplay = nextPrestige < TIER_CAPS.length ? TIER_CAPS[nextPrestige] : TIER_CAPS[TIER_CAPS.length - 1];
        String genkaiMessage = kekkeiGenkaiForTier.length == 0 ? "no new kekkei genkai this tier"
                : "you've unlocked " + String.join(" and ", kekkeiGenkaiForTier);
        player.sendMessage(new TextComponentString(
                "\u00A76\u00A7lPrestige " + nextPrestige + "! \u00A7rYour new NXP cap is " + newCapDisplay
                        + ", and " + genkaiMessage + "."));
    }

    private int getPrestigeScore(EntityPlayerMP player) {
        Scoreboard scoreboard = player.getWorldScoreboard();
        ScoreObjective objective = scoreboard.getObjective("prestige");
        if (objective == null) return 0;
        Score score = scoreboard.getOrCreateScore(player.getName(), objective);
        return score.getScorePoints();
    }

    private void setPrestigeScore(EntityPlayerMP player, int value) {
        Scoreboard scoreboard = player.getWorldScoreboard();
        ScoreObjective objective = scoreboard.getObjective("prestige");
        if (objective == null) return;
        Score score = scoreboard.getOrCreateScore(player.getName(), objective);
        score.setScorePoints(value);
    }

    /**
     * Snapshots the live player's NBT (which includes ForgeCaps for any
     * attached capability, populated fresh — no file reads needed) and walks
     * NXP_TAG_PATH down to the raw number.
     */
    private Integer readNxp(EntityPlayerMP player) {
        if (NXP_TAG_PATH.length < 2) return null;

        NBTTagCompound nbt = new NBTTagCompound();
        player.writeToNBT(nbt);

        NBTTagCompound current = nbt;
        for (int i = 0; i < NXP_TAG_PATH.length - 1; i++) {
            String key = NXP_TAG_PATH[i];
            if (!current.hasKey(key)) return null;
            current = current.getCompoundTag(key);
        }
        String lastKey = NXP_TAG_PATH[NXP_TAG_PATH.length - 1];
        if (!current.hasKey(lastKey)) return null;
        // If your NXP is stored as a decimal instead of a whole number, swap
        // getInteger for getDouble and (int) cast the result.
        return current.getInteger(lastKey);
    }

    /**
     * Writes 0 directly into NXP_TAG_PATH on a fresh snapshot of the
     * player's NBT, then writes that snapshot back onto the player. Used
     * instead of trusting a command with a negative amount, since
     * addninjaxp is likely intended only for gaining XP and may not
     * genuinely subtract.
     */
    private void resetNxp(EntityPlayerMP player) {
        if (NXP_TAG_PATH.length < 2) return;

        NBTTagCompound nbt = new NBTTagCompound();
        player.writeToNBT(nbt);

        NBTTagCompound current = nbt;
        for (int i = 0; i < NXP_TAG_PATH.length - 1; i++) {
            String key = NXP_TAG_PATH[i];
            if (!current.hasKey(key)) return; // path doesn't exist, nothing to reset
            current = current.getCompoundTag(key);
        }
        String lastKey = NXP_TAG_PATH[NXP_TAG_PATH.length - 1];
        // If your NXP is stored as a decimal, swap setInteger for setDouble.
        current.setInteger(lastKey, 0);

        player.readFromNBT(nbt);
    }

    /**
     * Deletes every tag listed in RELEASE_TAG_PATHS_TO_CLEAR from a fresh
     * snapshot of the player's NBT, then writes that snapshot back onto the
     * player. Deleting (rather than zeroing) a tag makes the owning mod fall
     * back to its own default the next time it reads that field — which for
     * "do I have this release" style flags is almost always false/empty.
     */
    private void clearGrantedReleases(EntityPlayerMP player) {
        if (RELEASE_TAG_PATHS_TO_CLEAR.length == 0) return;

        NBTTagCompound nbt = new NBTTagCompound();
        player.writeToNBT(nbt);

        for (String[] path : RELEASE_TAG_PATHS_TO_CLEAR) {
            if (path.length == 0) continue;
            NBTTagCompound current = nbt;
            boolean reachable = true;
            for (int i = 0; i < path.length - 1; i++) {
                if (!current.hasKey(path[i])) {
                    reachable = false;
                    break;
                }
                current = current.getCompoundTag(path[i]);
            }
            if (reachable) {
                current.removeTag(path[path.length - 1]);
            }
        }

        player.readFromNBT(nbt);
    }

    /**
     * Finds the just-granted dojutsu item(s) in the player's inventory
     * (armor slots included) and stamps them with the recipient's actual
     * UUID and a "<player>'s <Dojutsu>" display name, matching the format
     * a naturally-obtained one gets. Without this, the item keeps whatever
     * (wrong) UUID /giveNinjaRelease happened to generate, which the game
     * treats as belonging to someone else - causing blindness.
     */
    private void bindDojutsuOwnership(EntityPlayerMP player, String genkaiToken) {
        String[] itemIds = DOJUTSU_ITEMS_TO_BIND.get(genkaiToken);
        String displayName = DOJUTSU_DISPLAY_NAME.get(genkaiToken);
        if (itemIds == null || displayName == null) return;

        List<String> targetIds = Arrays.asList(itemIds);
        UUID uuid = player.getUniqueID();

        IInventory inv = player.inventory;
        for (int i = 0; i < inv.getSizeInventory(); i++) {
            ItemStack stack = inv.getStackInSlot(i);
            if (stack.isEmpty()) continue;
            String regName = stack.getItem().getRegistryName() != null
                    ? stack.getItem().getRegistryName().toString() : "";
            if (!targetIds.contains(regName)) continue;

            NBTTagCompound tag = stack.hasTagCompound() ? stack.getTagCompound() : new NBTTagCompound();
            tag.setLong("player_idMost", uuid.getMostSignificantBits());
            tag.setLong("player_idLeast", uuid.getLeastSignificantBits());

            NBTTagCompound display = tag.hasKey("display") ? tag.getCompoundTag("display") : new NBTTagCompound();
            display.setString("Name", player.getName() + "'s " + displayName);
            tag.setTag("display", display);

            stack.setTagCompound(tag);
        }
    }

    private void clearReleaseItems(EntityPlayerMP player) {
        if (RELEASE_ITEMS_TO_CLEAR.length == 0) return;
        List<String> toRemove = Arrays.asList(RELEASE_ITEMS_TO_CLEAR);
        IInventory inv = player.inventory;
        for (int i = 0; i < inv.getSizeInventory(); i++) {
            ItemStack stack = inv.getStackInSlot(i);
            if (stack.isEmpty()) continue;
            String regName = stack.getItem().getRegistryName() != null
                    ? stack.getItem().getRegistryName().toString() : "";
            if (toRemove.contains(regName)) {
                inv.setInventorySlotContents(i, ItemStack.EMPTY);
            }
        }
    }
}

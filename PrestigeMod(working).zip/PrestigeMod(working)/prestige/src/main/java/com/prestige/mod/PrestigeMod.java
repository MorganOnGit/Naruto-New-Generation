package com.prestige.mod;

import com.prestige.mod.command.CommandPrestige;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;

@Mod(modid = PrestigeMod.MODID, name = PrestigeMod.NAME, version = PrestigeMod.VERSION,
        acceptedMinecraftVersions = "[1.12.2]", dependencies = "required-after:forge")
public class PrestigeMod {

    public static final String MODID = "prestige";
    public static final String NAME = "Prestige";
    public static final String VERSION = "2.0.0";

    @Mod.Instance(MODID)
    public static PrestigeMod instance;

    @Mod.EventHandler
    public void serverStarting(FMLServerStartingEvent event) {
        event.registerServerCommand(new CommandPrestige());
    }
}

# NarutoNewGen

Merged mod for the `naruto server 2026` pack, combining what used to be two
separate mods ("Village System" and "Prestige") into one jar/modid.
Modid: `narutonewgen`, package `com.narutonewgen.mod`, jar comes out as
`narutonewgen-1.0.0.jar`.

Nothing about how either system behaves changed in the merge - this is a
straight package/registration consolidation. See below for what each half
does; more detail also lives in the original two projects' READMEs if you
still have them for reference.

## Server setup

Automatic - no console commands to run by hand. The first time a world's
server (dedicated, or the internal one behind singleplayer/LAN) fully
starts, `NarutoNewGenMod` creates the 6 village FTBUtilities ranks
(rain/cloud/mist/leaf/stone/sand), the 15 Prestige ranks with their current
NXP thresholds, and the `prestige` scoreboard objective - then records a
version number in that world's saved data (`SetupWorldData`,
`narutonewgen_setup`) so it doesn't redo this pointlessly on every restart.
That objective is important: it was missing from the original Prestige
mod's manual setup file even though its README claimed it existed - without
it, `/prestige` silently never remembers a player's prestige count between
runs, since `CommandPrestige` reads/writes that score but does nothing if
the objective doesn't exist yet.

This setup also **automatically re-syncs itself** if `CommandPrestige.TIER_CAPS`
changes after a world already ran it once (see "Fixed" below) - the actual
FTBUtilities `PrestigeN` ranks get deleted and recreated with the current
NXP caps the next time that world's server starts, rather than silently
keeping whatever caps they were created with the first time.

**Rank cap semantics (important, see "Fixed" below):** FTBUtilities enforces
a rank's number as a cap on whoever currently *holds* that rank - so the
`PrestigeN` rank a player is given upon reaching tier N has to carry the NXP
needed to reach tier N+1, not the NXP that got them into tier N in the first
place. `Prestige1` is created with a cap of 7,500 (what a Prestige-1 player
needs for Prestige 2), not 5,000 (what got them to Prestige 1) - `Prestige15`
(max) just repeats the top value since there's no tier 16 to climb toward.

`one_time_setup_commands.txt` is kept around for reference/manual re-use
only (e.g. if you ever want to double-check the exact commands, or force a
re-sync sooner than the next restart) - you shouldn't normally need it.

## Build

Copy this project's `src` into your working MDK (make sure no other mod's
`com\...` package is still sitting there - only `com\narutonewgen` should be
under `src\main\java\com\`), copy this project's `build.gradle` in too, then
`.\gradlew.bat build`. Jar lands in `build\libs\narutonewgen-1.0.0.jar`.
Replace both the old `villagesystem-*.jar` and `prestige-*.jar` in every
`mods\` folder (server and all clients) with this single jar.

## Commands

- `/village open` - opens the GUI (anyone)
- `/village assignvillage <player> <village>` - op-only manual override
- `/village kage startvote <village> <minutes>` - op-only, starts a Kage vote
- `/village kage vote <candidate>` - chat alternative to the GUI vote button
- `/village setrank <player> <genin|chunin|jonin>` - Kage-only, chat alternative to GUI promotions
- `/village quest give <player> <text>` / `quest verify <player>` / `quest turnin` - chat alternatives
- `/village team create <teamName> <joninLeader> <member1> [member2] [member3]` - Kage-only
- `/prestige` - once NXP meets the next tier's requirement, resets NXP to 0, bumps rank/cap, wipes every release and advancement the player holds (each release earned back one at a time as NXP climbs again - see below), and adds +10% to all future NXP gains per prestige level reached. Repeatable forever once Prestige 15 (500,000 NXP, max rank) is reached - see "Repeating Prestige 15" below

### How `/prestige` grants releases

Every release (kekkei genkai, dojutsu, jutsu, addon items) is granted
directly by `CommandPrestige` itself - the third-party `/giveNinjaRelease`
command (from kabutoaddon) is never called anymore. That command's own code
has real bugs (crashes on some argument combinations) and several releases
below never had a working token for it in the first place. Instead,
`CommandPrestige.RELEASES` looks up each item by its registry name and
either equips it (dojutsu/armor) or adds it to inventory (everything else),
then grants the matching advancement if one exists. See
`release-inventory.md` in the project for the full reference of every item
id / advancement id this was built from.

Some releases require already owning another one first (checked live off
the player's actual inventory/armor, not a separate flag): Mangekyou
Sharingan needs Sharingan, Eternal Mangekyou needs Mangekyou, Rinnegan needs
Eternal Mangekyou, Tenseigan needs Byakugan, and Blaze Release needs at
least Mangekyou. A gated item is simply excluded from that roll until its
prerequisite is met - it never crashes or grants something "impossible."

**`/prestige` itself grants NOTHING (changed 2026-09-19).** It used to wipe
the player's release set and immediately re-roll + grant one release for
EVERY tier from 1 up through the new prestige level, all in one go - Dennis
flagged that this made it look like NXP wasn't really being reset (a pile of
releases would appear the instant someone prestiged, before they'd earned a
single point of NXP toward their new climb). NXP was resetting correctly the
whole time - the atomic grant was just handing out everything up front
regardless of actual progress. Now `/prestige` does exactly three things:
bumps your rank, wipes your current release set, and resets your NXP to 0.
Every release you're due for your new prestige level - one per tier, 1
through your new prestige number - gets earned back one at a time as you
climb again, exactly as described in the next section. So going from
Prestige 14 to 15 deletes everything you had, resets you to 0 NXP, and gives
you nothing until you actually earn your way back up past 5,000, then 7,500,
then 15,000, and so on.

Alongside the item wipe, `/prestige` also revokes every release advancement
(`revokeAllReleaseAdvancements()`, added 2026-09-19) - without this, the "X
Acquired" advancement toast/achievement for something you'd earned before
would stay marked complete forever even after the item itself got wiped, and
re-earning that same release on a later climb wouldn't show the toast again
since the game already considered that criterion done. It just loops every
`ReleaseDef` and revokes its criterion unconditionally rather than tracking
exactly which ones this player actually holds - revoking a criterion the
player never had is a harmless no-op, and it's simpler given a few
`ReleaseDef`s intentionally share the same advancement/criterion pair (both
Mangekyou variants use `narutomod:mangekyosharinganopened`).

**Trade-off worth knowing:** Sharingan is one of the options in C Rank's
pool - if your C-Rank rolls in a given climb never land on it, Mangekyou (B
Rank), Eternal Mangekyou (A Rank), and Rinnegan (S Rank) all end up
unreachable for THAT climb (nothing crashes - the roll just skips them as
ineligible). Since everything re-rolls on every prestige's climb - including
every repeat of Prestige 15 (see "Repeating Prestige 15" below) - that's
just a "try again next time" situation with no dead end, even at max
prestige. Same idea for Tenseigan needing Byakugan, also rolled in C Rank.
If you'd rather guarantee the eye chain lands sooner, say so and a safety
net (reroll if a tier's whole pool comes up empty, or bias the odds) can be
added.

### Repeating Prestige 15

Added 2026-09-19 per Dennis's request: once a player reaches Prestige 15
(the top FTBUtilities rank, 500,000 NXP), `/prestige` no longer refuses
further use. Every repeat past that point requires 500,000 NXP again and
does everything a normal prestige does - wipes releases and advancements,
resets NXP to 0, and lets the player re-climb through all 15 checkpoints to
earn everything back - except it doesn't change rank, since there's no rank
higher than Prestige 15 to move into. Only the raw prestige count keeps
climbing internally, which is also what keeps growing the NXP-gain bonus
above with every repeat.

Every 100th repeat (100, 200, 300, ...) grants a Chakra Fruit
(`narutomod:chakrafruit`) as a milestone reward, via
`CommandPrestige.maybeGrantChakraFruitMilestone()`. This fires again at each
multiple of 100 rather than being a single one-time reward, since the whole
point of repeating is to keep doing it indefinitely - say the word if you'd
rather it be a strictly-once reward instead.

### How releases actually get granted: NXP-checkpoint crossings

Releases are earned progressively, one tier at a time, as your NXP actually
climbs - never all at once. NXP resets to 0 after every real `/prestige`,
and the 15 tier thresholds (5,000 up to 500,000) are just fixed, strictly
increasing checkpoints - so any climb toward your next prestige naturally
passes through every smaller checkpoint too on the way up. Climbing from
Prestige 14 toward Prestige 15's 500,000 requirement, for example, means
your NXP passes through 5,000, then 7,500, then 15,000, and so on, all the
way up to 500,000 - and a release is rolled and granted at each one as you
actually cross it.

`CommandPrestige.checkPrestigeProgressPreview()` (run every 20 ticks and on
login, alongside the anti-storage-exploit check below) is what does this -
despite the name, it's not a "preview" of anything anymore, it's the only
way a release is ever granted. It fires the moment your current NXP first
crosses each checkpoint (in order, tier 1 before tier 2 and so on - so a
gated release like Mangekyou can see Sharingan as already granted from an
earlier checkpoint in the same climb), without touching your rank or NXP
itself - you get a chat message and the item right then, and it's yours
until your next `/prestige` wipes it along with everything else and starts
the climb over from tier 1.

### Rank display and pools (D → C → B → A → S)

Purely a display label - it does not change thresholds or the FTBUtilities
rank names (those are still `Prestige1`..`Prestige15` internally).
`TIER_RANK_LABEL` in `CommandPrestige` groups the 15 tiers into 5 bands of
3, and each band shares one pool across its 3 tiers (`/prestige` shows e.g.
"Prestige 3 (D Rank)!"):

Rebalanced 2026-09-19 per Dennis, in two passes (see "Fixed" below for the
full reasoning on both): (1) Typhoon moved from A to B Rank; the generic
kabutoaddon Cursemark was removed outright (superseded by the 4 character
Curse Marks, now capped at one per player - see below); Barrier, Ink and
Acid moved from A to B Rank; Seven Heavenly Breathing Method moved from S
to C Rank; Medical Ninjutsu now also hands over all 4 of its jutsu scrolls.
(2) Dust Release moved from A to S Rank; Ink and Acid moved again, from B
straight to D Rank (Barrier stayed in B, Blue Flame stayed in A).

- **D Rank** - tiers 1-3 (5,000 / 7,500 / 15,000 NXP) - pool: Ice Release,
  Lava Release, Boil Release, Swift Release, Steel Release, Black Lightning
  Release, Ink Release
- **C Rank** - tiers 4-6 (25,000 / 50,000 / 75,000 NXP) - pool: Explosion
  Release, Rasengan, Byakugan, Sharingan, Paper Ninjutsu, Seven Heavenly
  Breathing Method
- **B Rank** - tiers 7-9 (100,000 / 125,000 / 150,000 NXP) - pool:
  Mangekyou Sharingan (Amaterasu, gated on Sharingan), Mangekyou Sharingan
  (Kamui, gated on Sharingan), Skeletal Control, Medical Ninjutsu (also
  grants all 4 of its jutsu scrolls - Cellular Activation, Healing, Poison
  Mist, Chakra Enhanced Strength), Storm Release, Magnet Release, Typhoon
  Release, Barrier Release
- **A Rank** - tiers 10-12 (175,000 / 200,000 / 250,000 NXP) - pool:
  Eternal Mangekyou (gated on Mangekyou), Dark Release, Blaze Release
  (gated on at least Mangekyou), Karma Seal, Scorch Release, Blue Flame
  Release, and the 4 character Curse Marks (Sasuke, Kimimaro, Tayuya,
  Sakon) - **mutually exclusive with each other**: once a player owns any
  one of the 4, the other 3 are permanently excluded from their future
  rolls, so everyone ends up with exactly one, never more
- **S Rank** - tiers 13-15 (300,000 / 400,000 / 500,000 NXP) - pool:
  Rinnegan (gated on Eternal Mangekyou), Tenseigan (gated on Byakugan),
  Eight Gates, Wood Release, Senjutsu, Dust Release/Kekkei Tota

### Prestige NXP-gain bonus (+10% per prestige level)

Added 2026-09-19 per Dennis's request: every prestige level a player has
already earned adds another +10% to any NXP they gain going forward, from
ANY source - Prestige 3 means +30% on top of whatever NXP a fight/quest/etc.
would otherwise have given. Uncapped: since Prestige 15 is itself repeatable
indefinitely (see "Repeating Prestige 15" below), this keeps growing with
every repeat too - Prestige 15 plus 5 repeats means +200%, and so on.

narutomod adds to NXP from many different places scattered through its own
code (combat, quests, and more), none of which this mod can hook directly
without decompiling and patching narutomod's own class files. Instead,
`CommandPrestige.applyPrestigeNxpBonus()` works by simple before/after
comparison, run every 20 ticks and on login (alongside the other periodic
checks, first each pass so the bonus already counts toward that pass's
tier-threshold check too): it remembers the last NXP value it already
accounted for, and whenever the player's current NXP is higher than that,
tops the difference up by `prestige level x 10%` before recording the new,
boosted value as NXP. If NXP goes down instead (most notably `/prestige`'s
own reset to 0) it just re-baselines with no bonus, which is also what
naturally re-arms this for the player's next climb - no special-casing
needed. A player's EXISTING NXP is never retroactively boosted, whether
from before this feature shipped or from before their most recent prestige
- only NXP earned from that point on is.

### Anti-storage-exploit enforcement

Because every `/prestige` wipes a player's release items, and that wipe
only touches their inventory at the exact moment `/prestige` runs, a player
could otherwise stash their current release(s) in a chest right beforehand
and pull them back out afterward to dodge the wipe. This is closed off:

- Every successful `/prestige` records the FULL set of release item ids it
  just (re-)granted (every tier 1..N) as that player's "currently allowed"
  set, REPLACING whatever was recorded before (`PrestigeReleaseData`, a
  per-world `WorldSavedData` keyed by player UUID - survives server
  restarts same as `SetupWorldData`). Each early preview grant (above)
  MERGES its item into that same allowed set too, so it isn't immediately
  treated as contraband before the next real `/prestige`.
- `ReleaseEnforcementHandler` checks every online player's full
  inventory/armor every 20 ticks, and also immediately on login, via
  `CommandPrestige.enforceReleaseOwnership()`. Any item on the known-release
  list (`RELEASE_ITEMS_TO_CLEAR`) that ISN'T in that player's currently-
  allowed set gets silently confiscated, with a chat warning if anything
  was taken.
- Net effect: pulling a stashed release out of a chest gets it removed
  again within a second (next tick check), and logging back in with one
  already in inventory gets it removed immediately.

**Heads up:** narutomod's dojutsu are also traditionally obtainable by
killing another player and picking up the eye they drop - a normal, intended
mechanic. This enforcement will treat a legitimately-stolen eye as
"unrecognized" and confiscate it too, since it only knows about items
`PrestigeReleaseData` recorded as `/prestige` grants. If that kill-and-loot
mechanic is meant to keep working on this server, this check needs a
carve-out for it - flagging this now rather than after someone loses a
stolen eye.

## Fixed

- **Removed Ink Release from the pool entirely, same as Acid Release before
  it (2026-09-20, per Dennis's request).** It's gone from all 3 D-Rank
  tiers in `TIER_POOLS` and can no longer be rolled by `/prestige` at any
  tier. Its `RELEASES.put("ink", ...)` definition was left in place (a
  harmless unused entry) so nothing breaks for any player already granted
  it before this change - it's just no longer reachable going forward.
- **Added a combined "[Hokage] [Leaf] [P5] PlayerName"-style prefix, shown
  in chat, the tab list, and above players' heads (2026-09-20, per Dennis's
  request).** Shows, in order: a player's Kage title if they hold one
  (gold), their village (a per-village color - Leaf green, Sand yellow,
  Mist aqua, Cloud white, Stone gray, Rain blue), and their current
  Prestige tier (dark gray, e.g. "[P5]", "[P0]" before their first
  prestige). New `PrefixManager.refreshPrefix()` builds the tag and applies
  it via a per-player scoreboard team (named exactly after the player) -
  vanilla has no direct per-player API for tab-list/nametag text, and a
  scoreboard team's prefix is the one thing that drives both, plus (for
  free) the default chat line too, since `EntityPlayer.getDisplayName()`
  already folds team prefix/color into the name vanilla hands its chat
  formatter. Chat is also reinforced directly by a new `ChatPrefixHandler`
  (registered at `EventPriority.LOWEST` so it runs after any other mod,
  including FTBUtilities, has already set its own message formatting),
  which explicitly prepends the same tag onto whatever's left in the
  message component - since FTBUtilities is known to build its own
  per-rank chat format (its "syntax" config) rather than using
  `getDisplayName()`, relying on the vanilla path alone risked the tag
  quietly not showing up in chat even though it was correctly showing in
  the tab list and above players' heads.

  The tag refreshes wherever the three things behind it can change:
  `PlayerEventHandler.onPlayerLoggedIn()` (every login - covers a fresh
  village assignment and picks up any Kage/Prestige change since last
  session), `CommandPrestige.execute()` (immediately after a successful
  `/prestige`, so the "[P_]" number updates without needing to relog),
  `VotingTickHandler.onServerTick()` (for both the new Kage and the
  outgoing one, if either is online, right after a Kage vote concludes),
  and `CommandVillage.assignVillage()`/`VillageActions.resetPlayer()` (the
  op-only village commands). `CommandPrestige.getPrestigeScore()` was made
  public so `PrefixManager` could read a player's tier without duplicating
  that scoreboard-objective lookup.
- **Refined the prefix's order and Kage/village behavior (2026-09-20, per
  Dennis's follow-up request, same day as the feature above).** Prestige
  now always leads the tag (previously last) - a player's now shows as
  "[P5] [Leaf] PlayerName" rather than "[Leaf] [P5] PlayerName". And
  becoming a village's Kage now REPLACES the village tag with the Kage
  title instead of showing both - a Kage shows as "[P5] [Hokage]
  PlayerName", not "[P5] [Hokage] [Leaf] PlayerName". This only changes
  what `PrefixManager.buildPrefix()` displays - a Kage is still tracked as
  a member of their village everywhere else (`VillageWorldData`, the GUI's
  roster/promotion/quest/team pages, etc. are all untouched).
- **Prestige tag now shows repeats past Prestige 15 instead of a raw,
  meaningless-looking number (2026-09-20, per Dennis's request).**
  `CommandPrestige.getPrestigeScore()` keeps climbing forever once a player
  repeats Prestige 15 (see "Repeating Prestige 15" above) - a raw score of
  115 there means "Prestige 15, 100 repeats in", not an actual 115th tier.
  New `PrefixManager.prestigeLabel()` shows "[P15+100]" instead of "[P115]"
  once `getPrestigeScore()` exceeds `TIER_CAPS.length` (15); every tier 0-15
  still shows plainly ("[P0]".."[P15]") since there's nothing to add yet.
- **New players now get a "Prestige0" rank capping them at 5,000 NXP until
  their first /prestige (2026-09-20, per Dennis's request).** Previously, a
  brand new player (prestige score 0) held no FTBUtilities Prestige rank at
  all - "rank add PrestigeN" only ever happens inside
  `CommandPrestige.execute()` once a player actually prestiges - so nothing
  stopped them from accumulating NXP well past the 5,000 needed to prestige
  in the first place before ever running the command. Added a new
  `Prestige0` rank, capped at `TIER_CAPS[0]` (5,000, the same number
  `/prestige` itself requires to reach Prestige 1), created alongside
  Prestige1-15 in `NarutoNewGenMod.serverStarted()`'s one-time setup
  (`CURRENT_SETUP_VERSION` bumped 3 -> 4 so it gets created on Dennis's
  live world too, not just a fresh one) and granted to a player the same
  moment `PlayerEventHandler.onPlayerLoggedIn()` auto-assigns their village
  - i.e. on their first-ever login. Unlike Prestige1-15 (each capped at the
  *next* tier's threshold, since they're granted only once that tier is
  already reached), Prestige0's cap is tier 0's own threshold, since there's
  no earlier tier a brand new player has already climbed past. Existing
  players who already hold a real village (so won't re-run that first-login
  block) aren't retroactively given Prestige0 by this - only newly joining
  players are, matching what was asked for; a returning veteran who somehow
  never prestiged would need it granted manually with `/rank add <player>
  Prestige0` if that ever comes up.
- **Replaced the Village GUI's plain "<"/">" page-turn buttons with Dennis's
  kunai-shaped arrow pixel art, and fixed several real overlapping-text/
  button bugs found while wiring it in (2026-09-20, per Dennis's request).**

  New `GuiImageButton` (extends vanilla `GuiButton`, overrides `drawButton()`)
  renders a given texture directly with no background box, instead of
  vanilla's grey beveled button chrome - which would have boxed the new
  kunai art in a shape that clashed with the red/black 9-slice border. It
  brightens and nudges down 1px on hover, and dims when disabled - the two
  nav buttons are now genuinely disabled (not just silently no-op'd) at
  page 1 and the last page. `arrow_left.png`/`arrow_right.png` (Dennis's two
  64x64 pieces - `assets/narutonewgen/textures/gui/`) replace the text "<"/
  ">" at a slightly larger 22x22, re-centered on the same nav row.

  While rewiring the nav row, traced down the actual overlapping text/
  buttons still left over from the earlier GUI rebuild: `rebuildPageWidgets()`
  had been computing its own `contentTop` as `CONTENT_PADDING + 36`, while
  `drawScreen()`'s matching `contentTop` (the one every page's actual text is
  drawn from) used `CONTENT_PADDING + 16` - a stray 20px (one full row)
  mismatch between where a row's text was drawn and where that row's button
  was placed. On the Promotions, Assign Quest, and Create Team pages, this
  meant every promote/Give/Verify/Select button rendered one row below the
  player it was actually supposed to sit next to, overlapping the next
  player's name. Fixed by making `rebuildPageWidgets()` use the exact same
  base as `drawScreen()`, then correcting each page's own offset built on
  top of it to match: the Kage Vote page's active-vote button row was
  missing the header row's +16 (was `+20`, needed `+36`, mirroring
  `drawVotingPage`'s own "+20 for the ends-in line, +16 for the header"
  math), and the Give Quest/Create Team text fields' `contentTop - 20` had
  to become plain `contentTop` to keep landing where they already correctly
  were (that stray `-20` had been silently cancelling out the base's stray
  `+20`).

  Also found and removed a second, more visible overlap: on the
  Promotions/Assign Quest/Create Team pages, a non-Kage viewer got a
  disabled "Kage-only page" placeholder button rendered at the exact same
  (contentLeft, contentTop) spot where `drawRosterPage`/`drawGiveQuestPage`/
  `drawTeamPage` already draw their own, more specific explanation text
  ("Only your village's Kage can promote players/assign quests/create
  teams.") - since buttons render after page content, that gray placeholder
  button was rendering directly on top of (and completely hiding) the real
  message every time a non-Kage player opened one of those pages. Removed
  the placeholder entirely; those three pages now just show their own
  existing text with nothing drawn over it.
- **Added a "G" keybind to open the Village GUI, instead of having to type
  `/village open` every time (2026-09-19, per Dennis's request).** New
  client-only `KeyBindings.OPEN_VILLAGE_GUI` (category "NarutoNewGen",
  default key G - remappable in Controls like any keybind) is registered
  from `ClientProxy.preInit()`, which is never run on a dedicated server
  since it's gated behind `NarutoNewGenMod`'s `@SidedProxy`. A new
  `ClientEventHandler` polls it once a client tick and, only when no other
  screen (chat, inventory, another mod's GUI, ...) is currently open, sends
  the existing client -> server `MessageVillageAction("REFRESH", ...)`
  packet - the same one the GUI already sends itself to refresh its own
  data - which the server answers by building a fresh `VillageDisplayData`
  snapshot and sending it back, exactly like `/village open` does; that
  snapshot is what `ClientProxy.openVillageGui()` opens `GuiVillage` from.
  No new packet type needed since "REFRESH" already does the full
  build-and-send round trip. Added an `en_us.lang` entry so the keybind
  shows as "Open Village GUI" in the Controls menu instead of its raw key.
- **Added a full player-run Kage vote system, with a real FTBUtilities rank
  behind the title (2026-09-19, per Dennis's request).** Any player can now
  start a vote for their own village's Kage - either from the Village GUI's
  new "Start Kage Vote" button (voting page, `GuiVillage` case 3) or with
  `/village kage requestvote` - via the new `VillageActions.startVote()`.
  Three gates must all pass or the requester just gets told why not: (1) no
  vote already running for that village; (2) more than 3 of that village's
  members currently online (`VillageDisplayData.villageMemberCount`, which
  was already computed from `server.getPlayerList().getPlayers()` so it's
  online-only); (3) a 1-week cooldown since the *last vote was started* for
  that village, tracked by a new `VillageWorldData.lastVoteStartTime` map
  (persisted to NBT) and enforced with a new `VOTE_COOLDOWN_MILLIS`
  constant (7 days) - the rejection message tells the requester how many
  hours/days are left. Once a vote starts, every online member of that
  village gets messaged immediately, and `VillageActions.vote()` now
  refuses a self-vote ("You can't vote for yourself.") in addition to its
  existing candidate checks. The op-only `/village kage startvote <village>
  <minutes>` (any village, any duration, no gates) still exists unchanged
  for admin use.

  When `VotingTickHandler` closes out an expired vote and there's a
  winner, it now also calls a new `grantKageRank()`: the matching
  FTBUtilities rank from a new `NarutoNewGenMod.KAGE_TITLES` array (Hokage
  for leaf, Kazekage for sand, Mizukage for mist, Raikage for cloud,
  Tsuchikage for stone/earth, Amekage for rain - looked up by village name
  via the new `kageTitleFor()` helper) is granted to the winner via `ranks
  add`, and stripped from whoever held it before via `ranks remove` (skipped
  if the same player won again, so re-electing an incumbent doesn't
  needlessly yank and re-grant their own rank). The six Kage ranks
  themselves are created the same way the village ranks already were - a
  `ranks create <title>` loop added to `NarutoNewGenMod.serverStarted()` -
  and `CURRENT_SETUP_VERSION` was bumped from 2 to 3 so that one-time setup
  block actually re-runs and creates them on Dennis's already-live world
  (a fresh world would have gotten them anyway).

  Finally, since a vote can still be running when someone logs in mid-vote
  (not just when it starts), `PlayerEventHandler.onPlayerLoggedIn()` was
  restructured so its logic no longer early-returns for already-assigned
  returning players - it now always calls the new
  `VillageActions.notifyOfActiveVoteIfAny()`, which checks the logging-in
  player's village for a live, non-expired `VotingSession` and, if one
  exists, messages them how many minutes are left to vote in the GUI. Combined
  with the online-broadcast in `startVote()`, every village member now hears
  about a vote whether they were already online when it started or joined
  partway through.
- **Rebuilt the Village GUI's background as a real 9-slice using Dennis's
  new pixel art, and fixed footer text/buttons clipping into the border
  (2026-09-19, per Dennis's request).** `GuiVillage` used to draw one flat
  512x384 `scroll.png` at a fixed size - now it draws Dennis's 128x128
  black-and-red border tile (`assets/narutonewgen/textures/gui/panel_border.png`)
  as a proper 9-slice via a new `drawNineSlice()` helper (built on vanilla's
  `drawScaledCustomSizeModalRect`): the four 16px corners are blitted 1:1 so
  the ornamental detail stays crisp, the four edges stretch along one axis
  only, and the center fills the rest - so the panel can be any size
  without warping the art. While rebuilding it, found and fixed a real
  layout bug: the old bottom nav row (`< Page X/Y >`) had its button
  bottoms only 10px above the panel's bottom edge and its page-count text
  only 13px above it - both dipped a few px into that edge's border
  artwork. Every content position in the GUI (title, nav row, page
  bodies, the "Turn In Quest"/"Create Team" action buttons) now derives
  from a single `CONTENT_PADDING` (30px) kept clear of the border, and the
  panel was widened to 500x360 so the widest row in the mod - the 7-column
  rank-promotion button grid on the Kage roster page - also clears the
  right-hand border instead of running 10px into it.
- **Added scrolling to every list-based Village GUI page, closing the
  "large roster runs off the bottom" limitation from the fix above
  (2026-09-19, per Dennis's request).** Mouse wheel now scrolls the
  roster/quests/voting/promotions/give-quest/team pages; a thin scrollbar
  appears on the right (inside the border, never touching it) whenever a
  page's content is taller than its viewport. Implementation: `scrollOffset`
  is subtracted from `contentTop` before any per-page row math runs, so
  every row on every page scrolls together with no changes needed to each
  page's own relative-offset logic. Two new safety helpers stop a scrolled
  row from ever rendering over the title, the nav row, or the border art:
  `drawStringSafe()` (replaces every `fontRenderer.drawString` call in the
  per-page draw methods) and `addButtonClipped()` (replaces `addButton` for
  every per-row button - Vote, the 7 promotion-rank buttons, Give/Verify,
  team Select) both skip anything whose row has scrolled outside the
  viewport, so an off-screen button can't be invisibly clicked either.
  `contentHeight()` mirrors each page's own row-height math (without
  drawing anything) to compute how far a page can scroll, and `Your
  Quests`/`Create Team` get a shorter viewport since those two pages have
  an action button pinned just above the nav row that scrolled content must
  never run underneath.
- **Removed Acid Release from the pool entirely (2026-09-19, per Dennis's
  request).** It's gone from all 3 D-Rank tiers in `TIER_POOLS` and can no
  longer be rolled by `/prestige` at any tier. Its `RELEASES.put("acid", ...)`
  definition was left in place (a harmless unused entry) so nothing breaks
  for any player who was already granted it before this change - it's just
  no longer reachable going forward.
- **Fixed a full server crash in The End caused by a third-party addon's
  broken "disable spawning" config option (2026-09-19, from a crash log
  Dennis sent).** The crash was `IllegalArgumentException: bound must be
  positive` inside vanilla's `WeightedRandom.getRandomItem()`, thrown while
  the server was ticking natural mob spawning in dimension 1 (The End) -
  it took the whole server down with `ReportedException: Exception ticking
  world`, right after a player loaded The End there for the first time.
  Root cause, found by decompiling every jar in `run/mods`: the "AHZNB
  Curse Mark" addon (`springaddon-*.jar`) registers Orochimaru as an
  `EnumCreatureType.AMBIENT` natural spawn in every biome in the game,
  including The End's Sky biome, with its weight taken straight from that
  addon's own `OROCHIMARU_WEIGHT` config option - cast directly from a
  `double` to an `int` with no check. That config option's own in-game
  description says "0 to stop spawning", but setting it to 0 (or anything
  below 1.0) doesn't skip the registration at all - it registers a
  `SpawnListEntry` with weight 0 anyway. The End's `AMBIENT` spawn list has
  no other entries by default (vanilla only ever puts Enderman in The
  End's `MONSTER` list), so that single zero-weight entry became the
  entire list, and its total weight summed to exactly 0 - the next natural
  `AMBIENT`-type spawn attempt there called `Random.nextInt(0)`, which
  always throws. Fixed with a new `SpawnListSanitizer.removeZeroWeightSpawnEntries()`,
  run once from `NarutoNewGenMod.serverStarting()` (after every mod's
  `init()` phase has already registered its spawns), which walks every
  registered biome's spawn list for every creature type and strips out any
  leftover zero-or-negative-weight entry. A list left empty afterward can
  never reach `WeightedRandom.getRandomItem()` in the first place -
  vanilla's own spawn code already skips empty lists before calling it -
  so this is a full fix rather than a patch of that one addon, and it also
  guards against any other addon making the same mistake in the future.
  Nothing needs to change in that addon's config - Orochimaru will still
  stop spawning as intended if `OROCHIMARU_WEIGHT` is 0, it just won't
  crash the server anymore either way.
- **Made Prestige 15 repeatable indefinitely, with a growing NXP bonus and a
  Chakra Fruit every 100 repeats (2026-09-19, per Dennis's request).**
  `/prestige` no longer stops a player once they reach the top rank -
  `execute()`'s "already at max prestige" check was removed, and the raw
  prestige score is now allowed to climb past `TIER_CAPS.length` (15) with
  every repeat. Each repeat still requires 500,000 NXP, still wipes
  releases/advancements and resets NXP to 0, and still lets the player earn
  everything back climbing through all 15 checkpoints again via
  `checkPrestigeProgressPreview()` (which had its own "stop once at max
  prestige" early-return removed for the same reason) - the only thing a
  repeat DOESN'T do is change FTBUtilities rank, since there's nothing above
  Prestige15 to move into. Because the +10%-per-prestige NXP bonus reads the
  same raw prestige score, it now keeps growing forever with each repeat
  too. Every 100th repeat also grants a Chakra Fruit
  (`narutomod:chakrafruit`) via the new `maybeGrantChakraFruitMilestone()`.
  See "Repeating Prestige 15" above for the full mechanic.
- **Added a +10% per-prestige NXP-gain bonus, from any source (2026-09-19,
  per Dennis's request).** See "Prestige NXP-gain bonus" above for the full
  mechanism - `CommandPrestige.applyPrestigeNxpBonus()`, run every 20 ticks
  and on login, compares each player's current NXP against the last value
  it's already accounted for and tops up any genuine increase by
  `prestige level x 10%`, since narutomod itself adds to NXP from too many
  scattered internal places to hook individually. Only ever boosts NEW
  gains - never a player's pre-existing NXP total.
- **Second pool rebalance pass (2026-09-19, per Dennis's request).** Dust
  Release/Kekkei Tota moved from A Rank to S Rank; Ink and Acid Release
  moved again - from the B Rank spot they'd just been given in the prior
  rebalance (below) straight to D Rank. Barrier Release stayed in B Rank,
  Blue Flame Release stayed in A Rank. See "Rank display and pools" above
  for the current pool.
- **Pool rebalance (2026-09-19, per Dennis's request).** Five changes to
  `CommandPrestige.RELEASES`/`TIER_POOLS`: Typhoon Release moved from A
  Rank to B Rank; the generic kabutoaddon Cursemark
  (`ahznbcursemarkaddon:cursemark_mode`) was removed outright, leaving only
  the 4 character-specific Curse Marks; Barrier, Ink and Acid Release moved
  from A Rank to B Rank (Blue Flame Release stays in A); Seven Heavenly
  Breathing Method moved from S Rank to C Rank; and getting Medical
  Ninjutsu now also grants all 4 of its jutsu scrolls (Cellular Activation,
  Healing, Poison Mist, Chakra Enhanced Strength) instead of just the base
  unlock item, via a new `items()` release-def helper that hands over
  several held items from one roll. Also added a general-purpose
  `MUTUALLY_EXCLUSIVE_GROUPS` mechanism (checked by `rollReleaseForTier()`
  alongside the existing prerequisite/already-owned filtering) and put the
  4 character Curse Marks in it, so owning any one of Sasuke/Kimimaro/
  Tayuya/Sakon's mark permanently excludes the other 3 from that player's
  future rolls - everyone ends up with exactly one, never more, even
  across separate prestiges. See "Rank display and pools" above for the
  full current pool.
- **Players got repeating 1-minute Blindness after prestiging while
  wearing an active (even fully healthy, undamaged) Dojutsu (fixed
  2026-09-19).** Decompiled narutomod's `ProcedureOnPlayerPostTick` to find
  the cause: it's a completely separate mechanic from the "worn-out eye"
  durability blindness. Every tick, narutomod compares
  `PlayerTracker.Deaths.mostRecentTime(player)` (an in-memory-only death
  log, 0 for anyone who hasn't died since the server started) against an
  NBT timestamp (`mostRecentlyHadAnyDojutsu`, confirmed against
  `NarutomodModVariables` - the Java field is misleadingly named
  `MostRecentWornDojutsuTime`) that `ItemDojutsu.Base.onArmorTick()`
  (shared by every dojutsu type - Byakugan, the whole Sharingan line,
  Rinnegan, Tenseigan) refreshes to "now" every 20 ticks while ANY dojutsu
  is equipped. If "last worn" is more recent than "last died", the player
  gets blinded for 1200 ticks (1 minute) - and this re-fires every single
  tick the condition still holds, forever, since removing the item just
  freezes "last worn" at its last value instead of clearing it, and "last
  died" only changes if the player actually dies. This is presumably meant
  as a "your eyes need a death/respawn to recover" penalty for
  voluntarily taking a dojutsu off mid-game - but `/prestige`'s own
  `clearReleaseItems()` forcibly removes a player's dojutsu with no death
  involved, permanently satisfying that condition for anyone who hasn't
  happened to die recently (most players peacefully grinding NXP). Fixed
  by having `CommandPrestige` reset that NBT tag back to 0 the instant it
  takes a dojutsu away - both in `clearReleaseItems()` (every `/prestige`)
  and in `enforceReleaseOwnership()` (the anti-stash-exploit confiscation
  check) - putting the player back in the exact state of someone who's
  never worn a dojutsu, so narutomod's own check never fires. If a player
  is already stuck in this loop from before this fix, dying once (any
  cause) clears it immediately, same as it always did.
- **Old advancements ("X Acquired" toasts) stayed marked complete forever
  after a prestige wiped the item itself (fixed 2026-09-19).** Per Dennis's
  request, `/prestige` now calls the new `revokeAllReleaseAdvancements()`
  right alongside the existing item wipe, so a player's advancement list
  matches what they actually still hold - and re-earning a release on a
  later climb shows the achievement toast again instead of staying silently
  suppressed. See the note under "How `/prestige` grants releases" above.
- **`/prestige` was granting every release for the new prestige level all
  at once, which Dennis flagged as NXP looking like it wasn't really being
  reset (fixed 2026-09-19).** NXP was in fact resetting correctly by this
  point - the actual issue was that `/prestige` used to immediately re-roll
  and grant one release per tier for every tier 1 through the new prestige
  number, all in the same command, before the player had earned any NXP
  toward their new climb. Removed that atomic grant entirely - `/prestige`
  now only bumps rank, wipes releases, and resets NXP to 0.
  `checkPrestigeProgressPreview()` (renamed in spirit, not in code - see
  "How releases actually get granted" above) is now the ONLY way a release
  is granted, firing tier by tier as NXP actually climbs back up past each
  checkpoint after the reset, exactly like it already did for early
  previews - so a player now genuinely has to re-earn every release on each
  new climb rather than getting them all up front.
- **shinobiaddon renamed itself to Dynamic Dojutsu, breaking 6 releases
  (fixed 2026-09-19).** Dennis updated that addon in his `mods` folder; the
  new jar (`dynamicdojutsu-1.3.9.6-0.3.1.jar`) changed its modid from
  `shinobiaddon` to `dynamicdojutsu` (display name "Dynamic Dojutsu"), which
  silently broke every `shinobiaddon:...` id in `CommandPrestige.RELEASES` -
  a roll landing on Typhoon/Dark/Mud/Swift/Crystal/Blaze would print
  "Missing item" and grant nothing. Typhoon, Dark, Swift and Blaze still
  exist under the new modid and were repointed there. Mud Release and
  Crystal Release don't exist AT ALL in the new jar anymore (not renamed,
  just gone) - replaced with two of the new jar's items that fill the same
  D-Rank niche, Steel Release and Black Lightning Release, so the pool
  didn't shrink from 6 to 4.
- **New Dynamic Dojutsu content added (2026-09-19).** Barrier/Blue
  Flame/Acid/Ink Release and the 4 character-specific Cursemarks
  (Sasuke/Kimimaro/Tayuya/Sakon) went into A Rank; Seven Heavens (a
  long-standing S-Rank candidate, now confirmed as
  `dynamicdojutsu:sevenheavens`) went into S Rank. Held off on Dynamic
  Sharingan/Byakugan/Ketsuryugan for now - decompiled their progression
  system to confirm how they'd behave first (they auto-level off the
  player's raw NXP almost instantly at our scale, and Byakugan/Ketsuryugan
  both passively drain NXP once awake) - full writeup in
  `release-inventory.md` for whenever that gets revisited.
- **PrestigeN ranks were capping players one tier too early (fixed
  2026-09-19).** Each `PrestigeN` rank was being created with
  `TIER_CAPS[tier - 1]` - the NXP that got a player INTO that rank - but
  FTBUtilities enforces a rank's number as a hard NXP cap on whoever
  *currently holds* it. So a player who just became Prestige 1 (at 5,000
  NXP) was immediately handed the "Prestige1" rank with a cap of... 5,000 -
  the exact amount they already had, permanently blocking them from ever
  earning the 7,500 needed to reach Prestige 2. Dennis caught this from the
  in-game "Available Ranks" list matching `TIER_CAPS` exactly, which is
  actually what exposed the bug: each rank needs the NEXT tier's number, not
  its own. Fixed by shifting every rank's cap up by one tier
  (`prestigeCaps[tier]` instead of `prestigeCaps[tier - 1]`, with the max
  tier reusing the top value since there's no tier beyond it) -
  `CommandPrestige.execute()`'s own `TIER_CAPS[prestige]` gating check
  already used this same "next tier" number, so this just brings the actual
  FTBUtilities rank caps in line with what the code was already checking
  against. `CURRENT_SETUP_VERSION` bumped to 2 so existing worlds re-sync
  automatically on next restart.
- **Prestige ranks' NXP caps didn't match `TIER_CAPS`.** The one-time setup
  that creates the FTBUtilities `PrestigeN` ranks used to be guarded by a
  plain "already ran" flag, so a world that had already run it once (under
  whatever `TIER_CAPS` numbers existed back then) never got its actual
  ranks updated when those numbers later changed (e.g. the move to 15
  tiers / 500,000 max NXP) - the ranks silently kept their stale caps
  forever. `SetupWorldData` now tracks a version number instead
  (`NarutoNewGenMod.CURRENT_SETUP_VERSION`), and `serverStarted()` re-runs
  the (safe to repeat) rank delete-then-recreate setup whenever a world's
  recorded version is behind - see "Server setup" above. A world already
  running an older build reads its old flag as version 0 and re-syncs
  automatically on its next restart; no manual console commands needed.
- **NXP still wasn't being reset after prestiging (fixed for real 2026-09-19).**
  Two earlier attempts at this didn't hold:
  1. The `addninjaxp <player> -<amount>` command wasn't reliably
     subtracting for every player, so a prestige could leave someone able
     to immediately `/prestige` again without having actually lost their
     NXP.
  2. Replacing that with a `player.writeToNBT()` snapshot → edit →
     `player.readFromNBT()` write-back *looked* right but still didn't
     actually reset NXP in practice. The real problem: Forge's
     `Entity#readFromNBT()` doesn't edit the entity's existing custom-data
     compound in place - it swaps in a brand new `NBTTagCompound` object
     (`this.customEntityData = compound.getCompoundTag("ForgeData")`).
     narutomod almost certainly grabbed `player.getEntityData()` once and
     kept that reference around rather than calling it fresh every time it
     touches NXP, so after our swap it kept reading/writing the OLD,
     now-orphaned compound - it never saw the reset at all, even though a
     disconnected copy correctly had 0 in it.

  Fixed by having `CommandPrestige.readNxp()`/`resetNxp()` mutate
  `player.getEntityData()` **directly and in place** instead of doing a
  full entity NBT round trip. `getEntityData()` always hands back the same
  live object, so this changes the exact compound narutomod itself is
  holding onto, rather than quietly replacing it out from under it. As a
  side benefit this also no longer touches anything else about the player
  (inventory, position, capabilities) the way a full `readFromNBT()` call
  risked doing.
- **Old releases weren't being wiped on prestige, and only the newest tier
  was granted.** `RELEASE_ITEMS_TO_CLEAR` used to be a hardcoded list of
  just the Tenseigan armor pieces (fixed to be built from every `ReleaseDef`
  automatically), and each `/prestige` only granted the single tier just
  reached. Per Dennis's request, `/prestige` now wipes everything and
  re-grants a fresh release for EVERY tier from 1 up through the new
  prestige level in one go - see "How `/prestige` grants releases" above.
- **Duplicate rolls within a shared rank pool.** The random pick used to be
  able to re-grant something the player already owns within the same
  regeneration (e.g. rolling Ice twice across D Rank's 3 tiers). The roll
  now skips anything the player already fully owns before picking, so it
  prefers giving something new.
- **Added early NXP-checkpoint previews.** Per Dennis's request, players no
  longer have to wait until they actually run `/prestige` to get anything -
  see "Early NXP-checkpoint previews" above.

**Data format note:** adding the preview-tiers tracking changed
`PrestigeReleaseData`'s NBT layout (the allowed-items list moved under an
"allowed" sub-tag instead of sitting at the root). Since this project is
still pre-launch, no migration was written for old saved data using the
previous flat layout - if this mod has already been run on a world before
this change, that world's existing `PrestigeReleaseData` will just read
back empty (nobody's actual releases are affected, only the enforcement
bookkeeping resets).

## Known gaps carried over from the original two mods (not touched by this merge)

- Village "Members Online" is a live online count, not a lifetime roster.
- Kage vote ties resolve to whichever candidate was tallied first
  internally, not a fair tiebreak.
- A player can only be in one team at a time; there's no explicit "leave
  team" command.

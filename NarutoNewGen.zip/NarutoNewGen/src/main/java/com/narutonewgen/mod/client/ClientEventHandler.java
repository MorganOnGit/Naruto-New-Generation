package com.narutonewgen.mod.client;

import com.narutonewgen.mod.network.MessageVillageAction;
import com.narutonewgen.mod.network.NetworkHandler;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/**
 * Polls KeyBindings.OPEN_VILLAGE_GUI once a client tick (2026-09-19, per
 * Dennis's request for a keybind instead of typing "/village open" every
 * time). The while-loop drains KeyBinding's own queued-press counter in one
 * go (the standard Forge pattern) so a tick hiccup can't leave a leftover
 * press to fire later; only actually sends anything while no other screen
 * (chat, inventory, another mod's GUI, ...) is open, so the keybind can't
 * yank focus away from whatever the player is already doing.
 *
 * Reuses the existing "REFRESH" GUI action rather than adding a new message
 * type - the server handles it exactly like "/village open" does
 * (VillageActions.handleGuiAction() -> sendGuiSnapshot()), building a fresh
 * VillageDisplayData snapshot and sending it back, which
 * ClientProxy.openVillageGui() then opens GuiVillage from (or, if the GUI
 * happens to already be open some other way, just refreshes it in place).
 */
public class ClientEventHandler {

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        while (KeyBindings.OPEN_VILLAGE_GUI.isPressed()) {
            if (Minecraft.getMinecraft().currentScreen == null) {
                NetworkHandler.INSTANCE.sendToServer(new MessageVillageAction("REFRESH", "", "", ""));
            }
        }
    }
}

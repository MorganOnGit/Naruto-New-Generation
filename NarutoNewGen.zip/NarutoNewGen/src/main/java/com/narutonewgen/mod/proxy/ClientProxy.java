package com.narutonewgen.mod.proxy;

import com.narutonewgen.mod.client.ClientEventHandler;
import com.narutonewgen.mod.client.KeyBindings;
import com.narutonewgen.mod.client.gui.GuiVillage;
import com.narutonewgen.mod.client.gui.VillageDisplayData;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;

public class ClientProxy extends CommonProxy {

    @Override
    public void preInit() {
        super.preInit();
        // Lets the player open the Village GUI with the G key instead of
        // typing "/village open" (2026-09-19, per Dennis's request). Both
        // client-only, safe here since preInit() is never called on a
        // dedicated server thanks to NarutoNewGenMod's @SidedProxy.
        KeyBindings.register();
        MinecraftForge.EVENT_BUS.register(new ClientEventHandler());
    }

    @Override
    public void openVillageGui(VillageDisplayData data) {
        Minecraft.getMinecraft().addScheduledTask(() -> {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.currentScreen instanceof GuiVillage) {
                // A refresh after a GUI action - update in place so the
                // player doesn't get bounced back to page 1.
                ((GuiVillage) mc.currentScreen).updateData(data);
            } else {
                mc.displayGuiScreen(new GuiVillage(data));
            }
        });
    }
}

package com.narutonewgen.mod.client.gui;

/** One row for the village member roster / promotion / voting / team-creation lists. */
public class RosterEntry {
    public final String playerName;
    public final String rank;

    public RosterEntry(String playerName, String rank) {
        this.playerName = playerName;
        this.rank = rank;
    }
}

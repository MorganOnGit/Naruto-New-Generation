package com.narutonewgen.mod.client.gui;

import com.narutonewgen.mod.capability.Quest;
import com.narutonewgen.mod.network.MessageVillageAction;
import com.narutonewgen.mod.network.NetworkHandler;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.input.Mouse;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

@SideOnly(Side.CLIENT)
public class GuiVillage extends GuiScreen {

    // New border art Dennis made (2026-09-19), replacing the old fixed-size
    // "scroll.png" background. It's a proper 9-slice: a 128x128 tile with a
    // 16px black-and-red ornamental border/corner design around a plain
    // beige center. Unlike the old texture (which had to be drawn at
    // exactly its own pixel size, 512x384, because it was one flat image),
    // this one is stretched via drawNineSlice() below to fill any panel
    // size we want, with the corners kept crisp and unstretched. Lives
    // under the current "narutonewgen" asset domain since it's new content
    // (the old scroll.png note about staying on the legacy "villagesystem"
    // domain doesn't apply here).
    private static final ResourceLocation TEXTURE =
            new ResourceLocation("narutonewgen", "textures/gui/panel_border.png");
    private static final int TEX_SIZE = 128;
    private static final int BORDER = 16;

    // Dennis's kunai-shaped page-turn arrows (2026-09-19), replacing the
    // plain vanilla "<"/">" text buttons - drawn via GuiImageButton, which
    // skips the default grey button chrome so only this art shows. Square
    // 64x64 source canvas (art itself is an off-center horizontal band
    // within it) means scaling both dimensions by the same factor keeps the
    // art's proportions correct at any NAV_ARROW_SIZE.
    private static final ResourceLocation ARROW_LEFT =
            new ResourceLocation("narutonewgen", "textures/gui/arrow_left.png");
    private static final ResourceLocation ARROW_RIGHT =
            new ResourceLocation("narutonewgen", "textures/gui/arrow_right.png");
    private static final int ARROW_TEX_SIZE = 64;
    private static final int NAV_ARROW_SIZE = 22;

    // Panel size on screen - independent of the texture's own resolution
    // now that it's a real 9-slice. Sized generously (wider than the old
    // 512px-native scroll) specifically so the widest row in the mod - the
    // 7-column promotion button grid on the Kage roster page - clears the
    // right-hand border with room to spare (see rebuildPageWidgets' case 5:
    // the last button's right edge lands at contentLeft + 424, so this
    // needs to stay comfortably above BORDER-clearance of that).
    private static final int PANEL_W = 500, PANEL_H = 360;

    // How far page content is kept from the panel's own edges, i.e. from
    // the 9-slice border. Deliberately bigger than BORDER (16) so nothing
    // ever visually touches the black/red border art - see the crash-log
    // style write-up in README's "Fixed" section for the exact overlap
    // this replaced (the old footer row's text and nav buttons both
    // clipped a few px into the border zone at the old panel's smaller
    // margins).
    private static final int CONTENT_PADDING = 30;
    private static final int PAGE_COUNT = 8;
    private static final String[] PAGE_TITLES = {
            "Village Overview", "Village Roster", "Your Quests", "Kage Vote",
            "Other Villages", "Promotions (Kage)", "Assign Quest (Kage)", "Create Team (Kage)"
    };

    private VillageDisplayData data;
    private int page = 0;

    // Scrolling for the per-player list pages (roster, quests, voting,
    // promotions, give-quest, team) - added 2026-09-19 per Dennis's
    // request, fixing the "a big enough roster/quest list runs off the
    // bottom of the panel" limitation flagged when the 9-slice border art
    // went in. scrollOffset is a pixel offset subtracted from contentTop
    // before any per-page layout math runs, so every row on every page
    // scrolls together with zero changes needed to each page's own
    // relative-offset logic - only drawStringSafe()/addButtonClipped()
    // needed adding, to stop a scrolled row from rendering over the title,
    // the nav row, or the border art itself.
    private int scrollOffset = 0;
    private static final int SCROLL_STEP = 12;

    private GuiTextField questTextField;
    private GuiTextField teamNameTextField;
    private String selectedJoninLeader = "";
    private final Set<String> selectedMembers = new LinkedHashSet<>();

    private final Map<Integer, Runnable> buttonActions = new HashMap<>();
    private int nextButtonId;

    public GuiVillage(VillageDisplayData data) {
        this.data = data;
    }

    /** Called by the network handler when a fresh snapshot arrives after an action. */
    public void updateData(VillageDisplayData newData) {
        this.data = newData;
        // Content may have shrunk (a quest got turned in, a player left the
        // roster, ...) since scrollOffset was last set - clamp it to the
        // new content's max scroll before rebuilding, so a stale offset
        // can't leave the view scrolled past the end of a now-shorter list.
        clampScroll();
        rebuildPageWidgets();
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int wheel = Mouse.getEventDWheel();
        if (wheel != 0) {
            scrollOffset += (wheel > 0 ? -SCROLL_STEP : SCROLL_STEP);
            clampScroll();
            rebuildPageWidgets();
        }
    }

    @Override
    public void initGui() {
        super.initGui();
        rebuildPageWidgets();
    }

    private int left() { return (this.width - PANEL_W) / 2; }
    private int top() { return (this.height - PANEL_H) / 2; }

    // Bottom nav row (< Page X/Y >): kept as one visual row, same as
    // before, but moved up from the old -26/-22 offsets (which put the
    // buttons' bottom edge only 10px above the panel's bottom edge and the
    // page-count text only 13px above it - both dipped a few px into the
    // 16px border) to a row whose bottom edge sits a full CONTENT_PADDING
    // above the panel bottom, matching every other content edge's margin.
    private int footerButtonY() { return top() + PANEL_H - CONTENT_PADDING - 16; }
    private int footerTextY() { return footerButtonY() + 4; }

    private void rebuildPageWidgets() {
        this.buttonList.clear();
        buttonActions.clear();
        nextButtonId = 100;
        questTextField = null;
        teamNameTextField = null;

        int left = left();
        int top = top();

        // Vertically centered on the same row the old text buttons used
        // (footerButtonY()..+16), just re-centered for the new, slightly
        // taller 22px art so it doesn't shift the row's visual midpoint.
        int navArrowY = footerButtonY() - (NAV_ARROW_SIZE - 16) / 2;
        addImageButton(1, left + CONTENT_PADDING - NAV_ARROW_SIZE / 2, navArrowY, ARROW_LEFT, () -> changePage(-1));
        addImageButton(2, left + PANEL_W - CONTENT_PADDING - NAV_ARROW_SIZE / 2, navArrowY, ARROW_RIGHT, () -> changePage(1));
        // Dimmed via GuiImageButton's disabled-brightness instead of just
        // no-oping silently, so it's visually obvious there's nothing
        // further that way (changePage() already no-ops past the ends).
        this.buttonList.get(0).enabled = page > 0;
        this.buttonList.get(1).enabled = page < PAGE_COUNT - 1;

        int contentLeft = left + CONTENT_PADDING;
        // clampScroll() first so a stale offset (e.g. from a page/data
        // change) never pushes contentTop somewhere every row math below
        // would treat as still-valid.
        clampScroll();
        // Matches drawScreen's own contentTop exactly (top + CONTENT_PADDING
        // + 16 - scrollOffset) - every per-page case below adds its own
        // local offset on top of this to reach its first row, mirroring
        // that same page's draw method's own running "y" math line for
        // line, so a button lands on the exact row its label was drawn on.
        // (Was CONTENT_PADDING + 36 - i.e. 20px, one row height, off from
        // drawScreen's base - which silently pushed every list page's
        // buttons one row below the player they belonged to. See README's
        // "Fixed" entry for the full before/after.)
        int contentTop = top + CONTENT_PADDING + 16 - scrollOffset;
        int rowHeight = 16;

        switch (page) {
            case 0:
            case 1:
            case 4:
                break; // read-only pages, no widgets needed
            case 2: {
                Quest latest = data.quests.isEmpty() ? null : data.quests.get(data.quests.size() - 1);
                if (latest != null && latest.getStatus() == Quest.Status.IN_PROGRESS) {
                    // Pinned above the nav row, NOT part of the scrollable
                    // area (see pageHasPinnedFooterButton) - deliberately
                    // not scroll-adjusted and not addButtonClipped.
                    addButton(nextButtonId++, contentLeft, footerButtonY() - 30, 110, 16, "Turn In Quest",
                            () -> sendAction("TURNIN_QUEST", "", "", ""));
                }
                break;
            }
            case 3: {
                if (data.votingActive) {
                    // +20 for the "Voting ends in..." line, +16 for the
                    // Candidate/Votes header row - mirrors drawVotingPage's
                    // own y+=20 then y+=16 before its roster loop starts.
                    int y = contentTop + 36;
                    for (RosterEntry r : data.roster) {
                        final String name = r.playerName;
                        // Can't vote for yourself (VillageActions.vote() also
                        // rejects it server-side) - just skip the button
                        // rather than showing one that would always fail.
                        if (!name.equals(data.selfName)) {
                            String label = name.equals(data.selfVotedFor) ? "Voted" : "Vote";
                            addButtonClipped(nextButtonId++, contentLeft + 160, y, 60, 14, label,
                                    () -> sendAction("VOTE", name, "", ""));
                        }
                        y += rowHeight;
                    }
                } else {
                    // Player-started vote (2026-09-19 per Dennis's request) -
                    // server re-checks the online-count and cooldown gates
                    // regardless of what this button shows, so no need to
                    // duplicate that logic on the client just to enable/
                    // disable it; a rejected attempt just gets a chat message.
                    addButtonClipped(nextButtonId++, contentLeft, contentTop + 46, 150, 16, "Start Kage Vote",
                            () -> sendAction("START_VOTE", "", "", ""));
                }
                break;
            }
            case 5: {
                if (data.selfIsKage) {
                    // +16 matches the "Player"/"Rank" header row drawScreen renders
                    // above the roster; PROMOTION_LEGEND_HEIGHT matches the legend
                    // lines drawn above that - both must line up with drawRosterPage.
                    int y = contentTop + PROMOTION_LEGEND_HEIGHT + 16;
                    // Compact abbreviated buttons so all 7 ranks fit in one row per player.
                    String[] rankIds = { "genin", "chunin", "jonin", "anbu", "anbu captain", "elite jonin", "shadow kage" };
                    String[] rankLabels = { "G", "C", "J", "A", "AC", "EJ", "SK" };
                    for (RosterEntry r : data.roster) {
                        final String name = r.playerName;
                        int x = contentLeft + 160;
                        for (int i = 0; i < rankIds.length; i++) {
                            final String rankId = rankIds[i];
                            addButtonClipped(nextButtonId++, x, y, 36, 14, rankLabels[i],
                                    () -> sendAction("PROMOTE", name, rankId, ""));
                            x += 38;
                        }
                        y += rowHeight;
                    }
                }
                // else: no widget needed - drawRosterPage already shows the
                // read-only roster plus its own "Only your village's Kage
                // can promote players." message for a non-Kage viewer. The
                // placeholder "Kage-only page" button that used to render
                // here sat at the exact same (contentLeft, contentTop) spot
                // as that roster's own header/text, so it rendered directly
                // on top of it every time - see README's "Fixed" entry.
                break;
            }
            case 6: {
                if (data.selfIsKage) {
                    // contentTop already IS the field's top-left, matching
                    // drawGiveQuestPage's own "Quest text:" label 12px above
                    // it (y - 12, where y == contentTop) - no extra offset
                    // needed now that contentTop's base matches drawScreen's.
                    questTextField = new GuiTextField(50, this.fontRenderer, contentLeft, contentTop, 300, 16);
                    questTextField.setMaxStringLength(256);
                    questTextField.setText("Type a quest here...");
                    // +26 matches drawGiveQuestPage's row start (12px label above, then +26).
                    int y = contentTop + 26;
                    for (RosterEntry r : data.roster) {
                        final String name = r.playerName;
                        addButtonClipped(nextButtonId++, contentLeft + 160, y, 60, 14, "Give",
                                () -> sendAction("GIVE_QUEST", name, questTextField.getText(), ""));
                        addButtonClipped(nextButtonId++, contentLeft + 225, y, 60, 14, "Verify",
                                () -> sendAction("VERIFY_QUEST", name, "", ""));
                        y += rowHeight;
                    }
                }
                // else: no widget needed - drawGiveQuestPage already shows
                // its own "Only your village's Kage can assign quests."
                // message at this exact spot; see the case 5 comment above.
                break;
            }
            case 7: {
                if (data.selfIsKage) {
                    // Same base-alignment fix as questTextField above -
                    // contentTop already matches drawTeamPage's "Team name:"
                    // label position (y - 12) with the right gap.
                    teamNameTextField = new GuiTextField(51, this.fontRenderer, contentLeft, contentTop, 200, 16);
                    teamNameTextField.setMaxStringLength(32);
                    teamNameTextField.setText("Team name...");
                    // +26 matches drawTeamPage's row start (12px label above, then +26).
                    int y = contentTop + 26;
                    for (RosterEntry r : data.roster) {
                        final String name = r.playerName;
                        final String rank = r.rank;
                        String label = name.equals(selectedJoninLeader) ? "Leader"
                                : selectedMembers.contains(name) ? "Selected" : "Select";
                        addButtonClipped(nextButtonId++, contentLeft + 160, y, 80, 14, label,
                                () -> toggleTeamSelection(name, rank));
                        y += rowHeight;
                    }
                    // Pinned above the nav row, NOT part of the scrollable
                    // area (see pageHasPinnedFooterButton) - deliberately
                    // not addButtonClipped.
                    addButton(nextButtonId++, contentLeft, footerButtonY() - 30, 110, 16, "Create Team",
                            this::submitCreateTeam);
                }
                // else: no widget needed - drawTeamPage already shows its
                // own "Only your village's Kage can create teams." message
                // at this exact spot; see the case 5 comment above.
                break;
            }
        }
    }

    private void addButton(int id, int x, int y, int w, int h, String label, Runnable onClick) {
        this.buttonList.add(new GuiButton(id, x, y, w, h, label));
        if (onClick != null) buttonActions.put(id, onClick);
    }

    private void addImageButton(int id, int x, int y, ResourceLocation texture, Runnable onClick) {
        this.buttonList.add(new GuiImageButton(id, x, y, NAV_ARROW_SIZE, NAV_ARROW_SIZE,
                texture, ARROW_TEX_SIZE, ARROW_TEX_SIZE));
        if (onClick != null) buttonActions.put(id, onClick);
    }

    private void changePage(int delta) {
        int newPage = page + delta;
        if (newPage >= 0 && newPage < PAGE_COUNT) {
            page = newPage;
            scrollOffset = 0;
            rebuildPageWidgets();
        }
    }

    // --- Scroll geometry -------------------------------------------------
    //
    // Two pages (2 "Your Quests" and 7 "Create Team") have a pinned action
    // button (Turn In Quest / Create Team) sitting just above the nav row,
    // outside the scrollable area - those pages get a shorter viewport so
    // scrolled content can never render underneath that button.

    private boolean pageHasPinnedFooterButton(int p) {
        return p == 2 || p == 7;
    }

    private int contentViewTop() {
        return top() + CONTENT_PADDING + 16;
    }

    private int contentViewBottom(int p) {
        return pageHasPinnedFooterButton(p) ? footerButtonY() - 34 : footerButtonY() - 10;
    }

    private int viewportHeight(int p) {
        return contentViewBottom(p) - contentViewTop();
    }

    /**
     * How tall the CURRENT page's content would be if drawn in full,
     * unscrolled. Mirrors each drawXxxPage()/rebuildPageWidgets() case's
     * own row math exactly (same header heights, same 16px/14px row
     * heights) rather than actually drawing anything, so it's cheap to
     * call every frame for clamping and for the scrollbar.
     */
    private int contentHeight(int p) {
        switch (p) {
            case 0: return 5 * 14; // drawOverviewPage: 5 fixed fields
            case 1: return 16 + data.roster.size() * 16; // header row + roster
            case 2: return questsContentHeight();
            case 3: return data.votingActive ? (20 + 16 + data.roster.size() * 16) : 62;
            case 4: {
                int count = 0;
                for (String v : data.allKages.keySet()) {
                    if (!v.equals(data.selfVillage)) count++;
                }
                return 16 + count * 16;
            }
            case 5: return data.selfIsKage
                    ? (PROMOTION_LEGEND_HEIGHT + 16 + data.roster.size() * 16)
                    : 12;
            case 6: return data.selfIsKage ? (26 + data.roster.size() * 16) : 12;
            case 7: {
                if (!data.selfIsKage) return 12;
                int h = 26 + data.roster.size() * 16 + 6;
                if (!data.teamNamesInVillage.isEmpty()) h += 14;
                return h;
            }
            default: return 0;
        }
    }

    private int questsContentHeight() {
        if (data.quests.isEmpty()) return 20 + 16 + 9;
        int h = 20 + 16;
        for (Quest q : data.quests) {
            h += this.fontRenderer.listFormattedStringToWidth(q.getDescription(), 420).size() * 14;
            h += 18;
        }
        return h;
    }

    private int maxScroll(int p) {
        return Math.max(0, contentHeight(p) - viewportHeight(p));
    }

    private void clampScroll() {
        scrollOffset = MathHelper.clamp(scrollOffset, 0, maxScroll(page));
    }

    /** Skips drawing anything that would land above/below this page's scroll viewport. */
    private void drawStringSafe(String text, int x, int y, int color) {
        if (y + 9 <= contentViewTop() || y >= contentViewBottom(page)) return;
        this.fontRenderer.drawString(text, x, y, color);
    }

    /** Skips creating a widget entirely if its row has scrolled out of view - so it can't be clicked while invisible. */
    private void addButtonClipped(int id, int x, int y, int w, int h, String label, Runnable onClick) {
        if (y + h <= contentViewTop() || y >= contentViewBottom(page)) return;
        addButton(id, x, y, w, h, label, onClick);
    }

    private void drawScrollbarIfNeeded() {
        int max = maxScroll(page);
        if (max <= 0) return;

        int viewTop = contentViewTop();
        int viewBottom = contentViewBottom(page);
        int viewH = viewBottom - viewTop;
        int total = contentHeight(page);

        int trackX = left() + PANEL_W - CONTENT_PADDING + 6;
        drawRect(trackX, viewTop, trackX + 4, viewBottom, 0x50000000);

        int thumbH = Math.max(14, viewH * viewH / total);
        int thumbY = viewTop + (viewH - thumbH) * scrollOffset / max;
        drawRect(trackX, thumbY, trackX + 4, thumbY + thumbH, 0xB0932F1E);
    }

    // Mirrors VillageActions.JONIN_OR_HIGHER - who's senior enough to be
    // selected as a team leader. Duplicated here rather than importing the
    // server-side action class, to keep the client GUI decoupled from it.
    private static final java.util.List<String> JONIN_OR_HIGHER = java.util.Arrays.asList(
            "jonin", "anbu", "anbu captain", "elite jonin", "shadow kage");

    private void toggleTeamSelection(String name, String rank) {
        if (JONIN_OR_HIGHER.contains(rank)) {
            selectedJoninLeader = name.equals(selectedJoninLeader) ? "" : name;
        } else if (selectedMembers.contains(name)) {
            selectedMembers.remove(name);
        } else if (selectedMembers.size() < 3) {
            selectedMembers.add(name);
        }
        rebuildPageWidgets();
    }

    private void submitCreateTeam() {
        String teamName = teamNameTextField != null ? teamNameTextField.getText() : "";
        String members = String.join(",", selectedMembers);
        sendAction("CREATE_TEAM", teamName, selectedJoninLeader, members);
        selectedJoninLeader = "";
        selectedMembers.clear();
    }

    private void sendAction(String action, String arg1, String arg2, String arg3) {
        NetworkHandler.INSTANCE.sendToServer(new MessageVillageAction(action, arg1, arg2, arg3));
    }

    @Override
    protected void actionPerformed(GuiButton button) {
        Runnable action = buttonActions.get(button.id);
        if (action != null) action.run();
    }

    @Override
    public void updateScreen() {
        if (questTextField != null) questTextField.updateCursorCounter();
        if (teamNameTextField != null) teamNameTextField.updateCursorCounter();
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        if (questTextField != null) questTextField.mouseClicked(mouseX, mouseY, mouseButton);
        if (teamNameTextField != null) teamNameTextField.mouseClicked(mouseX, mouseY, mouseButton);
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (questTextField != null && questTextField.isFocused()) {
            questTextField.textboxKeyTyped(typedChar, keyCode);
            return;
        }
        if (teamNameTextField != null && teamNameTextField.isFocused()) {
            teamNameTextField.textboxKeyTyped(typedChar, keyCode);
            return;
        }
        super.keyTyped(typedChar, keyCode);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();

        int left = left();
        int top = top();

        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        this.mc.getTextureManager().bindTexture(TEXTURE);
        drawNineSlice(left, top, PANEL_W, PANEL_H);

        int centerX = left + PANEL_W / 2;
        // Title sits just inside CONTENT_PADDING from the top border - well
        // clear of the 16px border art, with room below it before
        // contentTop (CONTENT_PADDING + 16) starts the page body.
        drawCenteredString(this.fontRenderer, TextFormatting.BOLD + PAGE_TITLES[page], centerX, top + CONTENT_PADDING - 8, 0x3B2A17);
        drawCenteredString(this.fontRenderer, "Page " + (page + 1) + " / " + PAGE_COUNT, centerX, footerTextY(), 0x3B2A17);

        int contentLeft = left + CONTENT_PADDING;
        clampScroll();
        int contentTop = top + CONTENT_PADDING + 16 - scrollOffset;

        switch (page) {
            case 0: drawOverviewPage(contentLeft, contentTop); break;
            case 1: drawRosterPage(contentLeft, contentTop, false); break;
            case 2: drawQuestsPage(contentLeft, contentTop); break;
            case 3: drawVotingPage(contentLeft, contentTop); break;
            case 4: drawOtherVillagesPage(contentLeft, contentTop); break;
            case 5: drawRosterPage(contentLeft, contentTop, true); break;
            case 6: drawGiveQuestPage(contentLeft, contentTop); break;
            case 7: drawTeamPage(contentLeft, contentTop); break;
        }

        drawScrollbarIfNeeded();

        if (questTextField != null) questTextField.drawTextBox();
        if (teamNameTextField != null) teamNameTextField.drawTextBox();

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    /**
     * Draws Dennis's 128x128 border-art texture as a proper 9-slice: the
     * four BORDER-sized (16px) corners are blitted 1:1 so the ornamental
     * black/red detail stays crisp, the four edge strips are stretched
     * along one axis only (so the straight border line - not the corners -
     * is what gets repeated to fill any panel size), and the plain beige
     * center is stretched across both axes to fill the rest. This is why
     * the panel can be PANEL_W x PANEL_H (500x360) even though the source
     * art is only 128x128 - before this, the old scroll.png had to be
     * drawn at exactly its own resolution because it was one flat image
     * with no such slicing.
     *
     * Must be called with TEXTURE already bound (drawScreen does this
     * right before calling in, matching how drawTexturedModalRect is used
     * elsewhere in this class).
     */
    private void drawNineSlice(int x, int y, int width, int height) {
        int b = BORDER;
        int mid = TEX_SIZE - 2 * b;

        // Corners - unstretched, 1:1 blit of the source art.
        drawScaledCustomSizeModalRect(x, y, 0, 0, b, b, b, b, TEX_SIZE, TEX_SIZE);
        drawScaledCustomSizeModalRect(x + width - b, y, TEX_SIZE - b, 0, b, b, b, b, TEX_SIZE, TEX_SIZE);
        drawScaledCustomSizeModalRect(x, y + height - b, 0, TEX_SIZE - b, b, b, b, b, TEX_SIZE, TEX_SIZE);
        drawScaledCustomSizeModalRect(x + width - b, y + height - b, TEX_SIZE - b, TEX_SIZE - b, b, b, b, b, TEX_SIZE, TEX_SIZE);

        // Edges - stretched along the panel's long axis only.
        drawScaledCustomSizeModalRect(x + b, y, b, 0, mid, b, width - 2 * b, b, TEX_SIZE, TEX_SIZE);
        drawScaledCustomSizeModalRect(x + b, y + height - b, b, TEX_SIZE - b, mid, b, width - 2 * b, b, TEX_SIZE, TEX_SIZE);
        drawScaledCustomSizeModalRect(x, y + b, 0, b, b, mid, b, height - 2 * b, TEX_SIZE, TEX_SIZE);
        drawScaledCustomSizeModalRect(x + width - b, y + b, TEX_SIZE - b, b, b, mid, b, height - 2 * b, TEX_SIZE, TEX_SIZE);

        // Center - stretched both ways.
        drawScaledCustomSizeModalRect(x + b, y + b, b, b, mid, mid, width - 2 * b, height - 2 * b, TEX_SIZE, TEX_SIZE);
    }

    private void drawOverviewPage(int x, int y) {
        int lineHeight = 14;
        drawField(x, y, "Village", capitalize(data.selfVillage)); y += lineHeight;
        drawField(x, y, "Members Online", String.valueOf(data.villageMemberCount)); y += lineHeight;
        drawField(x, y, "Current Kage", data.villageKageName.isEmpty() ? "None" : data.villageKageName); y += lineHeight;
        drawField(x, y, "Your Team", data.selfTeamName.isEmpty() ? "None" : data.selfTeamName); y += lineHeight;
        drawField(x, y, "Your Rank", capitalize(data.selfRank));
    }

    // Fixed at exactly 2 lines (rather than auto-wrapped) so its height is
    // known precisely and can be matched by the promotion button layout in
    // rebuildPageWidgets - auto-wrapping could silently drift the two out
    // of alignment depending on font metrics.
    private static final String[] PROMOTION_LEGEND = {
            "G=Genin  C=Chunin  J=Jonin  A=Anbu",
            "AC=Anbu Captain  EJ=Elite Jonin  SK=Shadow Kage"
    };
    static final int PROMOTION_LEGEND_HEIGHT = PROMOTION_LEGEND.length * 12 + 6;

    private void drawRosterPage(int x, int y, boolean withPromotionColumns) {
        if (withPromotionColumns && data.selfIsKage) {
            for (String line : PROMOTION_LEGEND) {
                this.drawStringSafe(TextFormatting.ITALIC + line, x, y, 0x5C4A2E);
                y += 12;
            }
            y += 6;
        }
        this.drawStringSafe(TextFormatting.UNDERLINE + "Player", x, y, 0x3B2A17);
        this.drawStringSafe(TextFormatting.UNDERLINE + "Rank", x + 100, y, 0x3B2A17);
        y += 16;
        for (RosterEntry r : data.roster) {
            this.drawStringSafe(r.playerName, x, y, 0x2A1E10);
            this.drawStringSafe(capitalize(r.rank), x + 100, y, 0x2A1E10);
            y += 16;
        }
        if (withPromotionColumns && !data.selfIsKage) {
            this.drawStringSafe(TextFormatting.ITALIC + "Only your village's Kage can promote players.",
                    x, y + 10, 0x8A2A1A);
        }
    }

    private void drawQuestsPage(int x, int y) {
        drawField(x, y, "Your Rank", capitalize(data.selfRank));
        y += 20;
        this.drawStringSafe(TextFormatting.UNDERLINE + "Current Quests", x, y, 0x3B2A17);
        y += 16;
        if (data.quests.isEmpty()) {
            this.drawStringSafe("No quests assigned.", x + 4, y, 0x5C4A2E);
            return;
        }
        for (Quest q : data.quests) {
            String status;
            int color;
            switch (q.getStatus()) {
                case COMPLETE: status = "[Complete]"; color = 0x2E6B1F; break;
                case PENDING_VERIFICATION: status = "[Pending]"; color = 0x8A6D1A; break;
                default: status = "[In Progress]"; color = 0x5C4A2E;
            }
            for (String wrapped : this.fontRenderer.listFormattedStringToWidth(q.getDescription(), 420)) {
                this.drawStringSafe(wrapped, x + 4, y, 0x2A1E10);
                y += 14;
            }
            this.drawStringSafe(status + " from " + q.getAssignedBy(), x + 8, y, color);
            y += 18;
        }
    }

    private void drawVotingPage(int x, int y) {
        if (!data.votingActive) {
            this.drawStringSafe("No active Kage vote for your village right now.", x, y, 0x5C4A2E);
            this.drawStringSafe("Anyone can start one below - needs more than 3 online", x, y + 14, 0x5C4A2E);
            this.drawStringSafe("village members, and none held in the last 7 days.", x, y + 28, 0x5C4A2E);
            return;
        }
        long remainingMs = data.votingEndTimeMillis - System.currentTimeMillis();
        long minutes = Math.max(0, remainingMs / 60000);
        this.drawStringSafe("Voting ends in about " + minutes + " minute(s).", x, y, 0x2A1E10);
        y += 20;
        this.drawStringSafe(TextFormatting.UNDERLINE + "Candidate", x, y, 0x3B2A17);
        this.drawStringSafe(TextFormatting.UNDERLINE + "Votes", x + 100, y, 0x3B2A17);
        y += 16;
        for (RosterEntry r : data.roster) {
            this.drawStringSafe(r.playerName, x, y, 0x2A1E10);
            int votes = data.voteTally.getOrDefault(r.playerName, 0);
            this.drawStringSafe(String.valueOf(votes), x + 100, y, 0x2A1E10);
            y += 16;
        }
    }

    private void drawOtherVillagesPage(int x, int y) {
        this.drawStringSafe(TextFormatting.UNDERLINE + "Village", x, y, 0x3B2A17);
        this.drawStringSafe(TextFormatting.UNDERLINE + "Kage", x + 100, y, 0x3B2A17);
        y += 16;
        for (Map.Entry<String, String> entry : data.allKages.entrySet()) {
            if (entry.getKey().equals(data.selfVillage)) continue;
            this.drawStringSafe(capitalize(entry.getKey()), x, y, 0x2A1E10);
            String kage = entry.getValue();
            this.drawStringSafe(kage.isEmpty() ? "None" : kage, x + 100, y, 0x2A1E10);
            y += 16;
        }
    }

    private void drawGiveQuestPage(int x, int y) {
        if (!data.selfIsKage) {
            this.drawStringSafe(TextFormatting.ITALIC + "Only your village's Kage can assign quests.", x, y, 0x8A2A1A);
            return;
        }
        this.drawStringSafe("Quest text:", x, y - 12, 0x2A1E10);
        y += 26;
        for (RosterEntry r : data.roster) {
            this.drawStringSafe(r.playerName, x, y, 0x2A1E10);
            y += 16;
        }
    }

    private void drawTeamPage(int x, int y) {
        if (!data.selfIsKage) {
            this.drawStringSafe(TextFormatting.ITALIC + "Only your village's Kage can create teams.", x, y, 0x8A2A1A);
            return;
        }
        this.drawStringSafe("Team name:", x, y - 12, 0x2A1E10);
        y += 26;
        for (RosterEntry r : data.roster) {
            this.drawStringSafe(r.playerName + " (" + capitalize(r.rank) + ")", x, y, 0x2A1E10);
            y += 16;
        }
        y += 6;
        if (!data.teamNamesInVillage.isEmpty()) {
            this.drawStringSafe("Existing teams: " + String.join(", ", data.teamNamesInVillage), x, y, 0x5C4A2E);
        }
    }

    private void drawField(int x, int y, String label, String value) {
        String line = TextFormatting.BOLD + label + ": " + TextFormatting.RESET + value;
        this.drawStringSafe(line, x, y, 0x2A1E10);
    }

    private String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        String[] words = s.split(" ");
        StringBuilder sb = new StringBuilder();
        for (String word : words) {
            if (word.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return sb.toString();
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}

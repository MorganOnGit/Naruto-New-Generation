package com.narutonewgen.mod.capability;

import com.narutonewgen.mod.NarutoNewGenMod;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.Random;

public class PlayerEventHandler {

    public static final ResourceLocation VILLAGE_DATA_ID =
            new ResourceLocation(NarutoNewGenMod.MODID, "village_data");

    private static final Random RANDOM = new Random();

    @SubscribeEvent
    public void attachCapability(AttachCapabilitiesEvent<Entity> event) {
        if (event.getObject() instanceof EntityPlayer) {
            event.addCapability(VILLAGE_DATA_ID, new VillageDataProvider());
        }
    }

    @SubscribeEvent
    public void onPlayerClone(PlayerEvent.Clone event) {
        IVillageData oldData = event.getOriginal().getCapability(CapabilityVillageData.VILLAGE_DATA_CAPABILITY, null);
        IVillageData newData = event.getEntityPlayer().getCapability(CapabilityVillageData.VILLAGE_DATA_CAPABILITY, null);
        if (oldData != null && newData != null) {
            newData.readFromNBT(oldData.writeToNBT());
        }
    }

    // Auto-assign a random village the first time a player ever logs in.
    @SubscribeEvent
    public void onPlayerLoggedIn(net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.player instanceof EntityPlayerMP)) return;
        EntityPlayerMP player = (EntityPlayerMP) event.player;
        IVillageData data = player.getCapability(CapabilityVillageData.VILLAGE_DATA_CAPABILITY, null);
        if (data == null) return;

        if (data.getVillage().isEmpty()) {
            String village = NarutoNewGenMod.VILLAGES[RANDOM.nextInt(NarutoNewGenMod.VILLAGES.length)];
            data.setVillage(village);

            // Grant the matching FTBUtilities rank (ranks named exactly "rain",
            // "cloud", etc. must already exist - see one_time_setup_commands.txt).
            net.minecraft.server.MinecraftServer server =
                    net.minecraftforge.fml.common.FMLCommonHandler.instance().getMinecraftServerInstance();
            server.getCommandManager().executeCommand(server, "ranks add " + player.getName() + " " + village);

            // Also grant Prestige0 (2026-09-20, per Dennis's request) - caps
            // a brand new player at 5,000 NXP (CommandPrestige.TIER_CAPS[0])
            // until their first real /prestige, the same way Prestige1..15
            // each cap a player at the NEXT tier's threshold once earned.
            // Without this, a player who'd never prestiged held no
            // Prestige rank at all and so had no FTBUtilities NXP cap
            // whatsoever. This "rank" (singular) is the actual FTBUtilities
            // rank-with-a-numeric-cap system, created once in
            // NarutoNewGenMod.serverStarted() - separate from the "ranks"
            // (plural) village/Kage group system used just above.
            server.getCommandManager().executeCommand(server, "rank add " + player.getName() + " Prestige0");

            player.sendMessage(new net.minecraft.util.text.TextComponentString(
                    "§6You have been assigned to the " + village.substring(0, 1).toUpperCase()
                            + village.substring(1) + " Village!"));
        }

        // Runs for every login, not just a fresh assignment - added
        // 2026-09-19 per Dennis's request so a player who joins WHILE
        // their village's Kage vote is already running finds out about it
        // (com.narutonewgen.mod.command.VillageActions.startVote() already
        // covers everyone who was online when the vote started).
        com.narutonewgen.mod.command.VillageActions.notifyOfActiveVoteIfAny(player);

        // Syncs the "[Hokage] [Leaf] [P5]"-style prefix (2026-09-20, per
        // Dennis's request) to whatever this player's village/Kage/Prestige
        // state actually is right now - covers both a fresh assignment
        // above and a returning player whose Kage title or Prestige tier
        // may have changed since their last session.
        com.narutonewgen.mod.prefix.PrefixManager.refreshPrefix(player);
    }
}

package com.narutonewgen.mod.worlddata;

import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagIntArray;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagString;
import net.minecraft.world.World;
import net.minecraft.world.storage.MapStorage;
import net.minecraft.world.storage.WorldSavedData;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Persists two things per player, both related to CommandPrestige's release
 * granting:
 *
 * 1. allowedItemIdsByPlayer - exactly which release item registry ids they
 *    are CURRENTLY allowed to hold. A real /prestige REPLACES this wholesale
 *    with the full freshly-regenerated batch (one release per tier 1..N).
 *    checkPrestigeProgressPreview() MERGES individual items into it early,
 *    as they're preview-granted during a climb (see below), so
 *    enforceReleaseOwnership() doesn't immediately confiscate a preview
 *    item as "not entitled" before the next real /prestige formally records
 *    it. This is the source of truth enforceReleaseOwnership() checks every
 *    player's inventory against, so a release stashed in a chest before
 *    prestiging (or handed over by another player, or picked up off the
 *    ground) gets silently confiscated instead of being usable after the
 *    fact - the wipe on /prestige alone isn't enough, since it only touches
 *    the player's inventory at that exact moment.
 *
 * 2. previewGrantedTiersByPlayer - which tiers (1-based) have already been
 *    preview-granted during the player's CURRENT climb (since their last
 *    real /prestige, which clears this). TIER_CAPS is 15 fixed, strictly
 *    increasing NXP checkpoints, and NXP resets to 0 after every real
 *    /prestige, so on any climb toward a player's next prestige their raw
 *    NXP naturally passes through every smaller checkpoint too before
 *    reaching the one they're aiming for.
 *    CommandPrestige.checkPrestigeProgressPreview() grants a release the
 *    moment each checkpoint is first crossed rather than making the player
 *    wait for an explicit /prestige - this set is what stops it from
 *    re-rolling/re-granting the same tier every tick.
 *
 * Stored per-world like SetupWorldData, so both survive server restarts.
 */
public class PrestigeReleaseData extends WorldSavedData {

    private static final String DATA_NAME = "narutonewgen_current_releases";

    private final Map<UUID, List<String>> allowedItemIdsByPlayer = new HashMap<>();
    private final Map<UUID, LinkedHashSet<Integer>> previewGrantedTiersByPlayer = new HashMap<>();

    public PrestigeReleaseData(String name) {
        super(name);
    }

    public static PrestigeReleaseData get(World world) {
        MapStorage storage = world.getPerWorldStorage();
        PrestigeReleaseData data = (PrestigeReleaseData) storage.getOrLoadData(PrestigeReleaseData.class, DATA_NAME);
        if (data == null) {
            data = new PrestigeReleaseData(DATA_NAME);
            storage.setData(DATA_NAME, data);
        }
        return data;
    }

    /** Empty list (never null) if the player hasn't prestiged yet. */
    public List<String> getAllowedItemIds(UUID playerId) {
        List<String> ids = allowedItemIdsByPlayer.get(playerId);
        return ids == null ? Collections.emptyList() : ids;
    }

    /** Replaces (does NOT merge) the player's allowed set - called once per successful /prestige with the FULL freshly-regenerated batch (every tier 1..N). */
    public void setAllowedItemIds(UUID playerId, List<String> itemIds) {
        allowedItemIdsByPlayer.put(playerId, new ArrayList<>(itemIds));
        markDirty();
    }

    /** Merges (does NOT replace) additional item ids into the player's allowed set - used by checkPrestigeProgressPreview() so a preview grant isn't immediately confiscated by enforceReleaseOwnership() before the next real /prestige. */
    public void addAllowedItemIds(UUID playerId, List<String> itemIds) {
        List<String> existing = new ArrayList<>(getAllowedItemIds(playerId));
        for (String id : itemIds) {
            if (!existing.contains(id)) existing.add(id);
        }
        allowedItemIdsByPlayer.put(playerId, existing);
        markDirty();
    }

    /** Tiers (1-based) already preview-granted during the player's CURRENT climb. Empty (never null) if none yet. */
    public Set<Integer> getPreviewGrantedTiers(UUID playerId) {
        LinkedHashSet<Integer> tiers = previewGrantedTiersByPlayer.get(playerId);
        return tiers == null ? Collections.emptySet() : tiers;
    }

    /** Marks a tier as already preview-granted this climb, so checkPrestigeProgressPreview() doesn't re-roll it every tick. */
    public void markPreviewTierGranted(UUID playerId, int tier) {
        previewGrantedTiersByPlayer.computeIfAbsent(playerId, k -> new LinkedHashSet<>()).add(tier);
        markDirty();
    }

    /** Clears the preview-granted tracking - called by a real /prestige, since NXP resets to 0 there and a brand new climb begins. */
    public void clearPreviewGrantedTiers(UUID playerId) {
        previewGrantedTiersByPlayer.remove(playerId);
        markDirty();
    }

    @Override
    public void readFromNBT(NBTTagCompound nbt) {
        allowedItemIdsByPlayer.clear();
        previewGrantedTiersByPlayer.clear();

        NBTTagCompound allowedSection = nbt.getCompoundTag("allowed");
        for (String key : allowedSection.getKeySet()) {
            NBTBase tag = allowedSection.getTag(key);
            if (!(tag instanceof NBTTagList)) continue;
            NBTTagList list = (NBTTagList) tag;
            List<String> ids = new ArrayList<>();
            for (int i = 0; i < list.tagCount(); i++) {
                ids.add(list.getStringTagAt(i));
            }
            try {
                allowedItemIdsByPlayer.put(UUID.fromString(key), ids);
            } catch (IllegalArgumentException ignored) {
                // Skip a malformed key rather than failing the whole load.
            }
        }

        NBTTagCompound previewSection = nbt.getCompoundTag("previewTiers");
        for (String key : previewSection.getKeySet()) {
            NBTBase tag = previewSection.getTag(key);
            if (!(tag instanceof NBTTagIntArray)) continue;
            int[] tierArray = ((NBTTagIntArray) tag).getIntArray();
            LinkedHashSet<Integer> tiers = new LinkedHashSet<>();
            for (int tier : tierArray) {
                tiers.add(tier);
            }
            try {
                previewGrantedTiersByPlayer.put(UUID.fromString(key), tiers);
            } catch (IllegalArgumentException ignored) {
                // Skip a malformed key rather than failing the whole load.
            }
        }
    }

    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound compound) {
        NBTTagCompound allowedSection = new NBTTagCompound();
        for (Map.Entry<UUID, List<String>> entry : allowedItemIdsByPlayer.entrySet()) {
            NBTTagList list = new NBTTagList();
            for (String id : entry.getValue()) {
                list.appendTag(new NBTTagString(id));
            }
            allowedSection.setTag(entry.getKey().toString(), list);
        }
        compound.setTag("allowed", allowedSection);

        NBTTagCompound previewSection = new NBTTagCompound();
        for (Map.Entry<UUID, LinkedHashSet<Integer>> entry : previewGrantedTiersByPlayer.entrySet()) {
            int[] tierArray = new int[entry.getValue().size()];
            int i = 0;
            for (int tier : entry.getValue()) {
                tierArray[i++] = tier;
            }
            previewSection.setIntArray(entry.getKey().toString(), tierArray);
        }
        compound.setTag("previewTiers", previewSection);

        return compound;
    }
}

package com.narutonewgen.mod.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;

/**
 * A GuiButton that renders as a plain image instead of vanilla's grey stone
 * button chrome (2026-09-19, per Dennis's request to make the GUI's buttons
 * "look more fitting" and to use his new page-turn arrow pixel art).
 * Vanilla GuiButton.drawButton() always blits the beveled widgets.png
 * button background before/behind the label, which would have boxed
 * Dennis's kunai-shaped arrow art inside a grey rectangle clashing with the
 * red/black 9-slice border - this class skips that background entirely and
 * draws only the given texture, stretched to (width, height) the same way
 * GuiVillage's own drawNineSlice() stretches its border art. Click handling
 * is untouched (inherited from GuiButton.mousePressed()), so this only
 * needed to override rendering.
 *
 * Gives simple, cheap visual feedback purely via color tint - no extra
 * texture frames needed: full brightness while hovered (plus a 1px nudge
 * down, like a soft "press"), slightly dimmed at rest, and dimmed further
 * while disabled (used for the nav arrows at the first/last page).
 */
public class GuiImageButton extends GuiButton {

    private final ResourceLocation texture;
    private final int texWidth;
    private final int texHeight;

    public GuiImageButton(int id, int x, int y, int width, int height,
                           ResourceLocation texture, int texWidth, int texHeight) {
        super(id, x, y, width, height, "");
        this.texture = texture;
        this.texWidth = texWidth;
        this.texHeight = texHeight;
    }

    @Override
    public void drawButton(Minecraft mc, int mouseX, int mouseY, float partialTicks) {
        if (!this.visible) return;

        this.hovered = mouseX >= this.x && mouseY >= this.y
                && mouseX < this.x + this.width && mouseY < this.y + this.height;

        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        mc.getTextureManager().bindTexture(texture);

        float brightness = !this.enabled ? 0.4f : (this.hovered ? 1.15f : 0.85f);
        GlStateManager.color(brightness, brightness, brightness, 1.0f);

        // Hovered + enabled gets a 1px downward nudge for a soft "press" feel.
        int drawY = this.y + (this.hovered && this.enabled ? 1 : 0);
        drawScaledCustomSizeModalRect(this.x, drawY, 0, 0, texWidth, texHeight,
                this.width, this.height, texWidth, texHeight);

        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.disableBlend();
    }
}

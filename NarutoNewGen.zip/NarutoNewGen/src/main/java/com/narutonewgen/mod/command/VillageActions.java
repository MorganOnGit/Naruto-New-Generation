package com.narutonewgen.mod.command;

import com.narutonewgen.mod.capability.CapabilityVillageData;
import com.narutonewgen.mod.capability.IVillageData;
import com.narutonewgen.mod.capability.Quest;
import com.narutonewgen.mod.client.gui.RosterEntry;
import com.narutonewgen.mod.client.gui.VillageDisplayData;
import com.narutonewgen.mod.network.MessageOpenVillageGui;
import com.narutonewgen.mod.network.NetworkHandler;
import com.narutonewgen.mod.worlddata.Team;
import com.narutonewgen.mod.worlddata.VillageWorldData;
import com.narutonewgen.mod.worlddata.VotingSession;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.fml.common.FMLCommonHandler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * All the real logic behind every /village action, shared between the chat
 * command (CommandVillage) and GUI button clicks (MessageVillageAction) so
 * both paths behave identically and there's exactly one place to fix a bug.
 */
public class VillageActions {

    private static final List<String> RANKS = Arrays.asList(
            "genin", "chunin", "jonin", "anbu", "anbu captain", "elite jonin", "shadow kage");

    // Player-started Kage votes (added 2026-09-19, per Dennis's request -
    // previously only an op could start one via "/village kage startvote").
    // Fixed 10-minute window, no arguments needed from the player.
    private static final int VOTE_DURATION_MINUTES = 10;
    // Minimum online village members (STRICTLY more than this) needed to
    // start a vote - "when more than 3 people with the village's rank are
    // online" per Dennis, i.e. more than 3 online members of that village.
    private static final int MIN_ONLINE_TO_START_VOTE = 3;
    // How long a village must wait after a vote is STARTED before it can
    // start another one - "a cooldown of 1 week, after which they can vote
    // again and either select a new kage or the same again" per Dennis.
    private static final long VOTE_COOLDOWN_MILLIS = 7L * 24 * 60 * 60 * 1000;

    // Who's senior enough to lead a team - anyone Jonin-tier or above.
    // Assumption: these 4 new ranks all sit above plain Jonin in seniority.
    // Flag it if that's not the intended hierarchy.
    private static final List<String> JONIN_OR_HIGHER = Arrays.asList(
            "jonin", "anbu", "anbu captain", "elite jonin", "shadow kage");

    /** Confirmed-safe way to get the running server, rather than the unverified EntityPlayerMP.getServer(). */
    private static MinecraftServer server() {
        return FMLCommonHandler.instance().getMinecraftServerInstance();
    }

    // ---------------------------------------------------------------
    // Snapshot building / sending
    // ---------------------------------------------------------------

    /**
     * Wipes a player's village state entirely (village, rank, team, quests)
     * so their next login is treated as brand new and triggers
     * auto-assignment again, exactly like PlayerEventHandler checks for.
     * Also strips their old village's FTBUtilities rank so it doesn't sit
     * stacked alongside whatever they get reassigned next.
     */
    public static void resetPlayer(EntityPlayerMP target) {
        IVillageData data = dataOf(target);
        String oldVillage = data.getVillage();

        data.setVillage("");
        data.setRank("genin");
        data.setTeamName("");
        data.clearQuests();

        if (oldVillage != null && !oldVillage.isEmpty()) {
            server().getCommandManager().executeCommand(server(),
                    "ranks remove " + target.getName() + " " + oldVillage);
        }

        // Drops the village bracket from their prefix immediately, in case
        // they're online when an op runs this (2026-09-20, per Dennis's
        // request) - their next login re-assigns a village and re-syncs it
        // anyway via PlayerEventHandler.
        com.narutonewgen.mod.prefix.PrefixManager.refreshPrefix(target);
    }

    public static VillageDisplayData buildDisplayData(EntityPlayerMP player) {
        MinecraftServer server = server();
        IVillageData selfData = player.getCapability(CapabilityVillageData.VILLAGE_DATA_CAPABILITY, null);
        String selfVillage = selfData.getVillage();

        VillageWorldData worldData = VillageWorldData.get(server.getEntityWorld());
        String kage = worldData.getKage(selfVillage);
        boolean isKage = player.getName().equals(kage);

        List<RosterEntry> roster = new ArrayList<>();
        for (EntityPlayerMP p : server.getPlayerList().getPlayers()) {
            IVillageData d = p.getCapability(CapabilityVillageData.VILLAGE_DATA_CAPABILITY, null);
            if (d != null && selfVillage.equals(d.getVillage())) {
                roster.add(new RosterEntry(p.getName(), d.getRank()));
            }
        }

        Map<String, String> allKages = new HashMap<>(worldData.getAllKages());
        for (String village : com.narutonewgen.mod.NarutoNewGenMod.VILLAGES) {
            allKages.putIfAbsent(village, "");
        }

        VotingSession session = worldData.getActiveVote(selfVillage);
        boolean votingActive = session != null && !session.isExpired();
        long endTime = session != null ? session.getEndTimeMillis() : 0L;
        Map<String, Integer> tally = new HashMap<>();
        String selfVotedFor = "";
        if (session != null) {
            for (Map.Entry<String, String> vote : session.getVotes().entrySet()) {
                tally.merge(vote.getValue(), 1, Integer::sum);
                if (vote.getKey().equals(player.getName())) {
                    selfVotedFor = vote.getValue();
                }
            }
        }

        List<String> teamNames = new ArrayList<>();
        for (Team t : worldData.getAllTeams().values()) {
            if (selfVillage.equals(t.getVillage())) {
                teamNames.add(t.getName());
            }
        }

        return new VillageDisplayData(player.getName(), selfVillage, selfData.getRank(), selfData.getTeamName(),
                isKage, roster.size(), kage == null ? "" : kage, roster, selfData.getQuests(), allKages,
                votingActive, endTime, tally, selfVotedFor, teamNames);
    }

    public static void sendGuiSnapshot(EntityPlayerMP player) {
        NetworkHandler.INSTANCE.sendTo(new MessageOpenVillageGui(buildDisplayData(player)), player);
    }

    // ---------------------------------------------------------------
    // Action dispatch (shared by GUI buttons and the chat command)
    // ---------------------------------------------------------------

    public static void handleGuiAction(EntityPlayerMP player, String action, String arg1, String arg2, String arg3) {
        switch (action) {
            case "START_VOTE":
                startVote(player);
                break;
            case "VOTE":
                vote(player, arg1);
                break;
            case "PROMOTE":
                promote(player, arg1, arg2);
                break;
            case "GIVE_QUEST":
                giveQuest(player, arg1, arg2);
                break;
            case "VERIFY_QUEST":
                verifyQuest(player, arg1);
                break;
            case "TURNIN_QUEST":
                turninQuest(player);
                break;
            case "CREATE_TEAM":
                createTeam(player, arg1, arg2, Arrays.asList(arg3.split(",")));
                break;
            case "REFRESH":
                break; // no-op, sendGuiSnapshot below covers it
            default:
                player.sendMessage(new TextComponentString("Unknown village action: " + action));
                return;
        }
        sendGuiSnapshot(player);
    }

    private static IVillageData dataOf(EntityPlayerMP player) {
        return player.getCapability(CapabilityVillageData.VILLAGE_DATA_CAPABILITY, null);
    }

    private static boolean isKageOf(EntityPlayerMP player, String village) {
        VillageWorldData worldData = VillageWorldData.get(server().getEntityWorld());
        return player.getName().equals(worldData.getKage(village));
    }

    private static EntityPlayerMP findOnline(MinecraftServer server, String name) {
        return server.getPlayerList().getPlayerByUsername(name);
    }

    /**
     * Reminds a player their village has a Kage vote in progress - called
     * from PlayerEventHandler.onPlayerLoggedIn() (2026-09-19, per Dennis's
     * request: "each villager online and each villager that joins should
     * get an announcement"). startVote() already messages every online
     * village member the moment a vote starts; this covers the other half
     * - anyone who logs in WHILE one is already running, who wouldn't
     * otherwise know it's happening. No-op if there's no active vote, or
     * the player isn't in a village yet.
     */
    public static void notifyOfActiveVoteIfAny(EntityPlayerMP player) {
        IVillageData data = dataOf(player);
        String village = data == null ? null : data.getVillage();
        if (village == null || village.isEmpty()) return;

        VotingSession session = VillageWorldData.get(server().getEntityWorld()).getActiveVote(village);
        if (session == null || session.isExpired()) return;

        long remainingMinutes = Math.max(1, (session.getEndTimeMillis() - System.currentTimeMillis()) / 60_000L);
        player.sendMessage(new TextComponentString("§6Your village is holding a Kage vote! You have about "
                + remainingMinutes + " minute(s) left to vote in the Village GUI."));
    }

    public static void vote(EntityPlayerMP player, String candidateName) {
        IVillageData selfData = dataOf(player);
        String village = selfData.getVillage();
        VillageWorldData worldData = VillageWorldData.get(server().getEntityWorld());
        VotingSession session = worldData.getActiveVote(village);
        if (session == null || session.isExpired()) {
            player.sendMessage(new TextComponentString("There's no active Kage vote for your village right now."));
            return;
        }
        if (player.getName().equalsIgnoreCase(candidateName)) {
            player.sendMessage(new TextComponentString("You can't vote for yourself."));
            return;
        }
        EntityPlayerMP candidate = findOnline(server(), candidateName);
        if (candidate == null || !village.equals(dataOf(candidate) != null ? dataOf(candidate).getVillage() : null)) {
            player.sendMessage(new TextComponentString(candidateName + " isn't an online member of your village."));
            return;
        }
        session.castVote(player.getName(), candidateName);
        worldData.markVotesDirty();
        player.sendMessage(new TextComponentString("Voted for " + candidateName + " for Kage."));
    }

    /**
     * Lets ANY village member start a Kage vote for their own village -
     * added 2026-09-19 per Dennis's request, alongside the existing
     * op-only "/village kage startvote <village> <minutes>" (kept as-is
     * for admin override/testing with a custom duration). Three gates, in
     * the order Dennis described them: no vote already running, the
     * per-village 1-week cooldown since the last one STARTED, then more
     * than MIN_ONLINE_TO_START_VOTE village members online right now.
     */
    public static void startVote(EntityPlayerMP player) {
        String village = dataOf(player).getVillage();
        if (village == null || village.isEmpty()) {
            player.sendMessage(new TextComponentString("You need to belong to a village to start a Kage vote."));
            return;
        }

        VillageWorldData worldData = VillageWorldData.get(server().getEntityWorld());
        VotingSession existing = worldData.getActiveVote(village);
        if (existing != null && !existing.isExpired()) {
            player.sendMessage(new TextComponentString("There's already an active Kage vote for your village."));
            return;
        }

        long remainingCooldown = (worldData.getLastVoteStartTime(village) + VOTE_COOLDOWN_MILLIS) - System.currentTimeMillis();
        if (remainingCooldown > 0) {
            long hours = Math.max(1, remainingCooldown / 3_600_000L);
            long days = hours / 24;
            String eta = days >= 1 ? (days + " day(s)") : (hours + " hour(s)");
            player.sendMessage(new TextComponentString(
                    "Your village held a Kage vote too recently - try again in about " + eta + "."));
            return;
        }

        int onlineCount = 0;
        for (EntityPlayerMP p : server().getPlayerList().getPlayers()) {
            IVillageData d = dataOf(p);
            if (d != null && village.equals(d.getVillage())) onlineCount++;
        }
        if (onlineCount <= MIN_ONLINE_TO_START_VOTE) {
            player.sendMessage(new TextComponentString("You need more than " + MIN_ONLINE_TO_START_VOTE
                    + " online members of your village to start a Kage vote (currently " + onlineCount + " online)."));
            return;
        }

        long endTime = System.currentTimeMillis() + VOTE_DURATION_MINUTES * 60_000L;
        worldData.startVote(village, endTime);
        worldData.setLastVoteStartTime(village, System.currentTimeMillis());

        String starter = player.getName();
        for (EntityPlayerMP p : server().getPlayerList().getPlayers()) {
            IVillageData d = dataOf(p);
            if (d != null && village.equals(d.getVillage())) {
                p.sendMessage(new TextComponentString("§6" + starter + " started a Kage vote for your village! "
                        + "You have " + VOTE_DURATION_MINUTES + " minutes to vote in the Village GUI."));
            }
        }
    }

    public static void promote(EntityPlayerMP kage, String targetName, String newRank) {
        String village = dataOf(kage).getVillage();
        if (!isKageOf(kage, village)) {
            kage.sendMessage(new TextComponentString("Only your village's Kage can promote players."));
            return;
        }
        if (!RANKS.contains(newRank)) {
            kage.sendMessage(new TextComponentString("Rank must be genin, chunin, or jonin."));
            return;
        }
        EntityPlayerMP target = findOnline(server(), targetName);
        if (target == null || !village.equals(dataOf(target).getVillage())) {
            kage.sendMessage(new TextComponentString(targetName + " isn't an online member of your village."));
            return;
        }
        dataOf(target).setRank(newRank);
        kage.sendMessage(new TextComponentString("Set " + targetName + "'s rank to " + newRank + "."));
        target.sendMessage(new TextComponentString("§6Your rank was set to " + newRank + " by your Kage."));
    }

    public static void giveQuest(EntityPlayerMP kage, String targetName, String questText) {
        String village = dataOf(kage).getVillage();
        if (!isKageOf(kage, village)) {
            kage.sendMessage(new TextComponentString("Only your village's Kage can assign quests."));
            return;
        }
        EntityPlayerMP target = findOnline(server(), targetName);
        if (target == null || !village.equals(dataOf(target).getVillage())) {
            kage.sendMessage(new TextComponentString(targetName + " isn't an online member of your village."));
            return;
        }
        if (questText == null || questText.trim().isEmpty()) {
            kage.sendMessage(new TextComponentString("Quest text can't be empty."));
            return;
        }
        dataOf(target).addQuest(new Quest(questText, kage.getName(), Quest.Status.IN_PROGRESS));
        kage.sendMessage(new TextComponentString("Gave " + targetName + " a quest."));
        target.sendMessage(new TextComponentString("§6New quest from your Kage: " + questText));
    }

    public static void verifyQuest(EntityPlayerMP kage, String targetName) {
        String village = dataOf(kage).getVillage();
        if (!isKageOf(kage, village)) {
            kage.sendMessage(new TextComponentString("Only your village's Kage can verify quests."));
            return;
        }
        EntityPlayerMP target = findOnline(server(), targetName);
        if (target == null || !village.equals(dataOf(target).getVillage())) {
            kage.sendMessage(new TextComponentString(targetName + " isn't an online member of your village."));
            return;
        }
        Quest quest = dataOf(target).getLatestQuest();
        if (quest == null || quest.getStatus() != Quest.Status.PENDING_VERIFICATION) {
            kage.sendMessage(new TextComponentString(targetName + " has no quest awaiting verification."));
            return;
        }
        quest.setStatus(Quest.Status.COMPLETE);
        kage.sendMessage(new TextComponentString("Verified " + targetName + "'s quest."));
        target.sendMessage(new TextComponentString("§6Your Kage verified your quest as complete!"));
    }

    public static void turninQuest(EntityPlayerMP player) {
        Quest quest = dataOf(player).getLatestQuest();
        if (quest == null || quest.getStatus() != Quest.Status.IN_PROGRESS) {
            player.sendMessage(new TextComponentString("You don't have an in-progress quest to turn in."));
            return;
        }
        quest.setStatus(Quest.Status.PENDING_VERIFICATION);
        player.sendMessage(new TextComponentString("Quest turned in. Waiting on your Kage to verify it."));
    }

    public static void createTeam(EntityPlayerMP kage, String teamName, String joninLeaderName, List<String> members) {
        String village = dataOf(kage).getVillage();
        if (!isKageOf(kage, village)) {
            kage.sendMessage(new TextComponentString("Only your village's Kage can create teams."));
            return;
        }
        if (teamName == null || teamName.trim().isEmpty()) {
            kage.sendMessage(new TextComponentString("Team name can't be empty."));
            return;
        }
        VillageWorldData worldData = VillageWorldData.get(server().getEntityWorld());
        if (worldData.getTeam(teamName) != null) {
            kage.sendMessage(new TextComponentString("A team named '" + teamName + "' already exists."));
            return;
        }
        EntityPlayerMP leader = findOnline(server(), joninLeaderName);
        if (leader == null || !village.equals(dataOf(leader).getVillage()) || !JONIN_OR_HIGHER.contains(dataOf(leader).getRank())) {
            kage.sendMessage(new TextComponentString(joninLeaderName + " must be an online Jonin (or higher) in your village."));
            return;
        }
        List<String> cleanMembers = new ArrayList<>();
        for (String m : members) {
            String trimmed = m.trim();
            if (trimmed.isEmpty()) continue;
            EntityPlayerMP member = findOnline(server(), trimmed);
            if (member == null || !village.equals(dataOf(member).getVillage())) {
                kage.sendMessage(new TextComponentString(trimmed + " isn't an online member of your village - skipped."));
                continue;
            }
            cleanMembers.add(trimmed);
        }
        if (cleanMembers.size() > 3) {
            kage.sendMessage(new TextComponentString("A team can have at most 3 members plus the Jonin leader."));
            return;
        }

        worldData.addTeam(new Team(teamName, village, joninLeaderName, cleanMembers));
        dataOf(leader).setTeamName(teamName);
        leader.sendMessage(new TextComponentString("§6You're now leading team '" + teamName + "'."));
        for (String m : cleanMembers) {
            EntityPlayerMP member = findOnline(server(), m);
            dataOf(member).setTeamName(teamName);
            member.sendMessage(new TextComponentString("§6You've been added to team '" + teamName + "'."));
        }
        kage.sendMessage(new TextComponentString("Created team '" + teamName + "'."));
    }
}

package com.narutonewgen.mod.capability;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;

import java.util.ArrayList;
import java.util.List;

public class VillageData implements IVillageData {

    private String village = "";
    private String rank = "genin";
    private String teamName = "";
    private List<Quest> quests = new ArrayList<>();

    @Override public String getVillage() { return village; }
    @Override public void setVillage(String village) { this.village = village; }

    @Override public String getRank() { return rank; }
    @Override public void setRank(String rank) { this.rank = rank; }

    @Override public String getTeamName() { return teamName; }
    @Override public void setTeamName(String teamName) { this.teamName = teamName; }

    @Override public List<Quest> getQuests() { return quests; }
    @Override public void addQuest(Quest quest) { quests.add(quest); }

    @Override
    public boolean removeQuest(int index) {
        if (index < 0 || index >= quests.size()) return false;
        quests.remove(index);
        return true;
    }

    @Override
    public Quest getLatestQuest() {
        return quests.isEmpty() ? null : quests.get(quests.size() - 1);
    }

    @Override public void clearQuests() { quests.clear(); }

    @Override
    public NBTTagCompound writeToNBT() {
        NBTTagCompound tag = new NBTTagCompound();
        tag.setString("village", village);
        tag.setString("rank", rank);
        tag.setString("teamName", teamName);

        NBTTagList questList = new NBTTagList();
        for (Quest q : quests) {
            questList.appendTag(q.writeToNBT());
        }
        tag.setTag("quests", questList);
        return tag;
    }

    @Override
    public void readFromNBT(NBTTagCompound nbt) {
        village = nbt.hasKey("village") ? nbt.getString("village") : "";
        rank = nbt.hasKey("rank") ? nbt.getString("rank") : "genin";
        teamName = nbt.hasKey("teamName") ? nbt.getString("teamName") : "";

        quests.clear();
        if (nbt.hasKey("quests")) {
            NBTTagList questList = nbt.getTagList("quests", 10); // TAG_COMPOUND
            for (int i = 0; i < questList.tagCount(); i++) {
                quests.add(Quest.readFromNBT(questList.getCompoundTagAt(i)));
            }
        }
    }
}

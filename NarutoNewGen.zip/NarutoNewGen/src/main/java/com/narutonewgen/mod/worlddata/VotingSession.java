package com.narutonewgen.mod.worlddata;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;

import java.util.HashMap;
import java.util.Map;

/** An active Kage vote for one village. voterName -> candidateName. */
public class VotingSession {
    private long endTimeMillis;
    private Map<String, String> votes = new HashMap<>();

    public VotingSession() {
    }

    public VotingSession(long endTimeMillis) {
        this.endTimeMillis = endTimeMillis;
    }

    public long getEndTimeMillis() { return endTimeMillis; }
    public boolean isExpired() { return System.currentTimeMillis() >= endTimeMillis; }

    public void castVote(String voter, String candidate) { votes.put(voter, candidate); }
    public Map<String, String> getVotes() { return votes; }

    /** Returns the candidate with the most votes, or null if no votes were cast. */
    public String getWinner() {
        Map<String, Integer> tally = new HashMap<>();
        for (String candidate : votes.values()) {
            tally.merge(candidate, 1, Integer::sum);
        }
        String winner = null;
        int best = -1;
        for (Map.Entry<String, Integer> entry : tally.entrySet()) {
            if (entry.getValue() > best) {
                best = entry.getValue();
                winner = entry.getKey();
            }
        }
        return winner;
    }

    public NBTTagCompound writeToNBT() {
        NBTTagCompound tag = new NBTTagCompound();
        tag.setLong("endTimeMillis", endTimeMillis);
        NBTTagList voteList = new NBTTagList();
        for (Map.Entry<String, String> entry : votes.entrySet()) {
            NBTTagCompound voteTag = new NBTTagCompound();
            voteTag.setString("voter", entry.getKey());
            voteTag.setString("candidate", entry.getValue());
            voteList.appendTag(voteTag);
        }
        tag.setTag("votes", voteList);
        return tag;
    }

    public static VotingSession readFromNBT(NBTTagCompound tag) {
        VotingSession session = new VotingSession();
        session.endTimeMillis = tag.getLong("endTimeMillis");
        session.votes = new HashMap<>();
        NBTTagList voteList = tag.getTagList("votes", 10); // TAG_COMPOUND
        for (int i = 0; i < voteList.tagCount(); i++) {
            NBTTagCompound voteTag = voteList.getCompoundTagAt(i);
            session.votes.put(voteTag.getString("voter"), voteTag.getString("candidate"));
        }
        return session;
    }
}

package com.narutonewgen.mod.prefix;

import com.narutonewgen.mod.NarutoNewGenMod;
import com.narutonewgen.mod.capability.CapabilityVillageData;
import com.narutonewgen.mod.capability.IVillageData;
import com.narutonewgen.mod.command.CommandPrestige;
import com.narutonewgen.mod.worlddata.VillageWorldData;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.util.text.TextFormatting;

/**
 * Builds and applies the combined "[P5] [Hokage] PlayerName"-style prefix
 * Dennis asked for (2026-09-20, refined further that same day): Prestige
 * tier always first, then EITHER the player's Kage title (if they hold
 * one) OR their village - never both, since becoming Kage replaces the
 * village tag rather than sitting alongside it. Shown in chat, the tab
 * list, and the player's above-head nametag.
 *
 * Vanilla Minecraft has no per-player "just set a prefix" API for the tab
 * list or nametag - the only thing that drives both of those (and, for
 * free, the DEFAULT chat line too, since EntityPlayer.getDisplayName()
 * folds team prefix/color in automatically) is the scoreboard TEAM system.
 * So every player gets their own dedicated team, named exactly after them
 * (guaranteed unique, and always a valid team name since it's a real MC
 * username), whose prefix is rebuilt and re-applied here whenever anything
 * that feeds into it changes - see refreshPrefix()'s call sites: player
 * login, a successful /prestige, a Kage vote concluding, and an op
 * assigning/resetting someone's village.
 *
 * Chat is ALSO reinforced directly by ChatPrefixHandler rather than relying
 * solely on the "team prefix flows into getDisplayName()" trick, since
 * FTBUtilities is known to build its own chat formatting per rank (its
 * "syntax" config) - if that replaces the message component before our
 * chat handler runs, buildPrefix() below is what gets explicitly prepended
 * onto whatever's left, so the combined tag can't silently go missing in
 * chat only.
 */
public class PrefixManager {

    private PrefixManager() {
    }

    /** Rebuilds this player's tab-list/nametag prefix from their current village/Kage/Prestige state. */
    public static void refreshPrefix(EntityPlayerMP player) {
        Scoreboard scoreboard = player.getWorldScoreboard();
        String name = player.getName();

        ScorePlayerTeam team = scoreboard.getTeam(name);
        if (team == null) {
            team = scoreboard.createTeam(name);
        }
        if (scoreboard.getPlayersTeam(name) != team) {
            scoreboard.addPlayerToTeam(name, name);
        }

        team.setPrefix(buildPrefix(player));
    }

    /**
     * The plain prefix text (with color codes), independent of the
     * scoreboard team - used both by refreshPrefix() above and directly by
     * ChatPrefixHandler, which can't rely on the team having already been
     * (re-)applied on the exact tick a chat message is sent.
     */
    public static String buildPrefix(EntityPlayerMP player) {
        StringBuilder sb = new StringBuilder();

        // Prestige always leads (2026-09-20, per Dennis's request).
        int prestige = CommandPrestige.getPrestigeScore(player);
        appendTag(sb, TextFormatting.DARK_GRAY, prestigeLabel(prestige));

        IVillageData data = player.getCapability(CapabilityVillageData.VILLAGE_DATA_CAPABILITY, null);
        String village = data == null ? "" : data.getVillage();

        if (village != null && !village.isEmpty()) {
            VillageWorldData worldData = VillageWorldData.get(player.getEntityWorld());
            String kage = worldData.getKage(village);
            if (kage != null && kage.equalsIgnoreCase(player.getName())) {
                // Kage REPLACES the village tag rather than joining it
                // (2026-09-20, per Dennis's request) - a Kage is still a
                // member of their village internally (VillageWorldData,
                // the GUI, etc. are all untouched), this only changes what
                // the second tag shows.
                String kageTitle = NarutoNewGenMod.kageTitleFor(village);
                if (kageTitle != null) {
                    appendTag(sb, TextFormatting.GOLD, kageTitle);
                } else {
                    appendTag(sb, villageColor(village), capitalize(village));
                }
            } else {
                appendTag(sb, villageColor(village), capitalize(village));
            }
        }

        return sb.toString();
    }

    private static void appendTag(StringBuilder sb, TextFormatting color, String text) {
        sb.append(color).append('[').append(text).append(']').append(TextFormatting.RESET).append(' ');
    }

    // Matches each village's forehead-protector "element" color where an
    // obvious one exists (Leaf=green, Sand=yellow-sand, Mist=watery aqua,
    // Rain=blue). Cloud and Stone don't have as obvious a color, so they get
    // plain white/gray - deliberately neither DARK_GRAY (reserved for the
    // Prestige tag) nor GOLD (reserved for the Kage tag), so no two tags on
    // the same player ever render in the same color.
    private static TextFormatting villageColor(String village) {
        switch (village) {
            case "leaf": return TextFormatting.DARK_GREEN;
            case "sand": return TextFormatting.YELLOW;
            case "mist": return TextFormatting.AQUA;
            case "cloud": return TextFormatting.WHITE;
            case "stone": return TextFormatting.GRAY;
            case "rain": return TextFormatting.BLUE;
            default: return TextFormatting.GRAY;
        }
    }

    private static String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }
}

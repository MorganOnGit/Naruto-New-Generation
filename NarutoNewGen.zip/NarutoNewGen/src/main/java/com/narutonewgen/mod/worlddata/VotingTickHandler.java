package com.narutonewgen.mod.worlddata;

import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;


/**
 * Checks once every 20 ticks (1 second) for any active Kage vote whose
 * window has ended, tallies it, and promotes the winner automatically.
 * Cheap enough at this interval to not be a lag concern.
 */
public class VotingTickHandler {

    private static final int CHECK_INTERVAL_TICKS = 20;
    private int tickCounter = 0;

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        tickCounter++;
        if (tickCounter < CHECK_INTERVAL_TICKS) return;
        tickCounter = 0;

        MinecraftServer server = FMLCommonHandler.instance().getMinecraftServerInstance();
        if (server == null) return;

        VillageWorldData data = VillageWorldData.get(server.getEntityWorld());

        for (String village : com.narutonewgen.mod.NarutoNewGenMod.VILLAGES) {
            VotingSession session = data.getActiveVote(village);
            if (session == null || !session.isExpired()) continue;

            String winner = session.getWinner();
            String previousKage = data.getKage(village);
            data.endVote(village);
            if (winner != null) {
                data.setKage(village, winner);
                grantKageRank(server, village, winner, previousKage);
                refreshPrefixIfOnline(server, winner);
                if (previousKage != null && !previousKage.equals(winner)) {
                    refreshPrefixIfOnline(server, previousKage);
                }
                announce(server, "§6The " + capitalize(village) + " Village has a new Kage: " + winner + "!");
            } else {
                announce(server, "§6The Kage vote for " + capitalize(village) + " Village ended with no votes cast.");
            }
        }
    }

    /**
     * Moves the village's FTBUtilities Kage rank (Hokage, Kazekage, ... -
     * see NarutoNewGenMod.KAGE_TITLES) from whoever held it before onto the
     * new winner. Added 2026-09-19 per Dennis's request - being "Kage" used
     * to be tracked only internally (VillageWorldData.kageOf, used for the
     * GUI's promote/quest/team permission checks) with no actual in-game
     * rank behind it. Skips the "remove" half when the same player won
     * again, so re-electing an incumbent doesn't needlessly strip and
     * re-grant their own rank.
     */
    private void grantKageRank(MinecraftServer server, String village, String winner, String previousKage) {
        String kageTitle = com.narutonewgen.mod.NarutoNewGenMod.kageTitleFor(village);
        if (kageTitle == null) return; // shouldn't happen - every VILLAGES entry has a KAGE_TITLES match

        if (previousKage != null && !previousKage.equals(winner)) {
            server.getCommandManager().executeCommand(server, "ranks remove " + previousKage + " " + kageTitle);
        }
        server.getCommandManager().executeCommand(server, "ranks add " + winner + " " + kageTitle);
    }

    /**
     * Updates the "[Hokage]"-style prefix immediately for whoever just
     * gained or lost the title (2026-09-20, per Dennis's request), rather
     * than leaving it stale until their next login - only meaningful for
     * whichever of the two happens to be online right now, since
     * PlayerEventHandler.onPlayerLoggedIn() already re-syncs it for anyone
     * who logs in later anyway.
     */
    private void refreshPrefixIfOnline(MinecraftServer server, String playerName) {
        EntityPlayerMP player = server.getPlayerList().getPlayerByUsername(playerName);
        if (player != null) {
            com.narutonewgen.mod.prefix.PrefixManager.refreshPrefix(player);
        }
    }

    private String capitalize(String s) {
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }

    private void announce(MinecraftServer server, String message) {
        for (EntityPlayerMP player : server.getPlayerList().getPlayers()) {
            player.sendMessage(new TextComponentString(message));
        }
    }
}

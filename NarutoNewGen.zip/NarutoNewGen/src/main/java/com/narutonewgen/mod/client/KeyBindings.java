package com.narutonewgen.mod.client;

import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import org.lwjgl.input.Keyboard;

/**
 * Client-side keybinding that opens the Village GUI (2026-09-19, per
 * Dennis's request to replace typing "/village open" every time). Bound to
 * G by default - like any Forge keybind, the player can still remap it in
 * Controls if it conflicts with something else. Registered from
 * ClientProxy.preInit() (client-only, thanks to @SidedProxy on
 * NarutoNewGenMod.proxy - this class is never touched on a dedicated
 * server), and polled once a client tick by ClientEventHandler.
 */
public class KeyBindings {

    public static final KeyBinding OPEN_VILLAGE_GUI = new KeyBinding(
            "key.narutonewgen.openvillage", KeyConflictContext.IN_GAME, Keyboard.KEY_G,
            "key.categories.narutonewgen");

    public static void register() {
        ClientRegistry.registerKeyBinding(OPEN_VILLAGE_GUI);
    }
}

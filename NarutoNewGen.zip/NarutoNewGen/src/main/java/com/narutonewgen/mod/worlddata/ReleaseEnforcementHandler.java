package com.narutonewgen.mod.worlddata;

import com.narutonewgen.mod.command.CommandPrestige;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/**
 * Three periodic per-player checks tied to CommandPrestige's release
 * granting and NXP bonus, all run every 20 ticks (same interval as
 * VotingTickHandler) and immediately on login:
 *
 *   1. applyPrestigeNxpBonus() - added 2026-09-19 per Dennis's request for
 *      a per-prestige NXP-gain bonus (+10% per prestige level, from any
 *      source). Run FIRST each pass so any bonus this pass applies is
 *      already reflected in the player's NXP before the tier-threshold
 *      check right below evaluates it - i.e. the bonus counts toward
 *      reaching the next prestige checkpoint too, not just as a separate
 *      display number.
 *   2. checkPrestigeProgressPreview() - grants a release early, the moment
 *      a player's current (un-reset) NXP crosses each of the 15 TIER_CAPS
 *      checkpoints, without waiting for them to run /prestige. Run before
 *      the enforcement check right below so a freshly preview-granted item
 *      is already merged into PrestigeReleaseData's allowed set before that
 *      check evaluates that same player this same pass.
 *   3. enforceReleaseOwnership() - confiscates any release item a player
 *      holds that isn't part of their currently-allowed set, so stashing a
 *      release in a chest right before running /prestige (to dodge the
 *      wipe /prestige does) doesn't work.
 *
 * NOTE (migration caveat): PrestigeReleaseData only knows what a player was
 * granted (by /prestige or by the preview check) AFTER this feature
 * shipped. A player who legitimately earned a release before this update
 * has no recorded "allowed" entry for it, so the very first enforcement
 * pass will treat it as contraband and confiscate it. If that's not
 * acceptable, existing players' current legitimate releases need a
 * one-time grandfather-in pass (seeding PrestigeReleaseData from whatever
 * they're already holding) before this ships live.
 */
public class ReleaseEnforcementHandler {
    private static final int CHECK_INTERVAL_TICKS = 20;
    private int tickCounter = 0;

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        tickCounter++;
        if (tickCounter < CHECK_INTERVAL_TICKS) return;
        tickCounter = 0;

        MinecraftServer server = FMLCommonHandler.instance().getMinecraftServerInstance();
        if (server == null) return;

        for (EntityPlayerMP player : server.getPlayerList().getPlayers()) {
            CommandPrestige.applyPrestigeNxpBonus(player);
            CommandPrestige.checkPrestigeProgressPreview(player);
            CommandPrestige.enforceReleaseOwnership(player);
        }
    }

    @SubscribeEvent
    public void onPlayerLoggedIn(net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.player instanceof EntityPlayerMP)) return;
        EntityPlayerMP player = (EntityPlayerMP) event.player;
        CommandPrestige.applyPrestigeNxpBonus(player);
        CommandPrestige.checkPrestigeProgressPreview(player);
        CommandPrestige.enforceReleaseOwnership(player);
    }
}

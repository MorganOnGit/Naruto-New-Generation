package com.narutonewgen.mod;

import com.narutonewgen.mod.capability.CapabilityVillageData;
import com.narutonewgen.mod.capability.PlayerEventHandler;
import com.narutonewgen.mod.command.CommandPrestige;
import com.narutonewgen.mod.command.CommandVillage;
import com.narutonewgen.mod.network.NetworkHandler;
import com.narutonewgen.mod.prefix.ChatPrefixHandler;
import com.narutonewgen.mod.proxy.CommonProxy;
import com.narutonewgen.mod.worlddata.ReleaseEnforcementHandler;
import com.narutonewgen.mod.worlddata.SetupWorldData;
import com.narutonewgen.mod.worlddata.SpawnListSanitizer;
import com.narutonewgen.mod.worlddata.VotingTickHandler;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartedEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;

/**
 * Merged mod combining the former separate "Village System" and "Prestige"
 * mods into a single jar/modid, since both were always meant to run together
 * on the same server. All original functionality is unchanged - this class
 * just replaces VillageSystemMod + PrestigeMod as the single @Mod entry
 * point, registering both /village and /prestige.
 */
@Mod(modid = NarutoNewGenMod.MODID, name = NarutoNewGenMod.NAME, version = NarutoNewGenMod.VERSION,
        acceptedMinecraftVersions = "[1.12.2]", dependencies = "required-after:forge")
public class NarutoNewGenMod {

    public static final String MODID = "narutonewgen";
    public static final String NAME = "NarutoNewGen";
    public static final String VERSION = "1.0.0";

    public static final String[] VILLAGES = { "rain", "cloud", "mist", "leaf", "stone", "sand" };

    // Parallel to VILLAGES - the FTBUtilities rank name granted to whoever
    // wins that village's Kage vote, per Dennis's naming (2026-09-19).
    // "stone" maps to Tsuchikage: that's the Naruto lore village governing
    // Earth Country (Iwagakure, "Hidden Stone Village") - Dennis called it
    // "earth" when naming the titles, but it's the same village as "stone"
    // in VILLAGES, there's no separate 7th village.
    public static final String[] KAGE_TITLES = { "Amekage", "Raikage", "Mizukage", "Hokage", "Tsuchikage", "Kazekage" };

    public static String kageTitleFor(String village) {
        for (int i = 0; i < VILLAGES.length; i++) {
            if (VILLAGES[i].equals(village)) return KAGE_TITLES[i];
        }
        return null;
    }

    // Bump this whenever a change to CommandPrestige.TIER_CAPS (or the
    // number of tiers) means the actual FTBUtilities Prestige1..N ranks
    // need to be deleted and recreated to match - see SetupWorldData's
    // javadoc for why a plain "already ran" flag wasn't enough. A world
    // whose recorded version is behind this gets its ranks re-synced the
    // next time its server starts.
    //
    // Bumped to 2 (2026-09-19): each PrestigeN rank's cap used to be
    // created as TIER_CAPS[tier - 1] - the threshold that got a player
    // INTO that rank - but FTBUtilities enforces a rank's number as a cap
    // on whoever currently HOLDS it. So "Prestige1" (cap 5,000) was
    // capping a freshly-prestiged player at exactly the NXP they already
    // had, blocking them from ever reaching the 7,500 needed for Prestige
    // 2. See serverStarted() below for the corrected mapping.
    //
    // Bumped to 3 (2026-09-19): added the 6 Kage ranks (KAGE_TITLES above)
    // so player-started Kage votes (VillageActions.startVote()) have an
    // actual FTBUtilities rank to grant the winner, the same way the 6
    // village ranks already get created below. This needs the version
    // bump so Dennis's already-set-up live world actually creates these
    // new ranks on its next restart, rather than only on a brand new world.
    //
    // Bumped to 4 (2026-09-20): added a "Prestige0" rank, capped at
    // TIER_CAPS[0] (5,000 NXP) - per Dennis's request, a brand new player
    // (prestige score 0, no Prestige rank at all yet) previously had NO
    // FTBUtilities NXP cap whatsoever until their first /prestige, since
    // "rank add PrestigeN" only ever happens inside CommandPrestige.execute()
    // once a player actually prestiges. PlayerEventHandler now grants
    // Prestige0 the same moment it auto-assigns a village, i.e. on a
    // player's first-ever login - see its javadoc.
    private static final int CURRENT_SETUP_VERSION = 4;

    @Mod.Instance(MODID)
    public static NarutoNewGenMod instance;

    @SidedProxy(clientSide = "com.narutonewgen.mod.proxy.ClientProxy",
            serverSide = "com.narutonewgen.mod.proxy.CommonProxy")
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        CapabilityVillageData.register();
        NetworkHandler.register();
        MinecraftForge.EVENT_BUS.register(new PlayerEventHandler());
        MinecraftForge.EVENT_BUS.register(new VotingTickHandler());
        // Two jobs: (1) grants a release early the moment a player's NXP
        // crosses each tier's checkpoint, ahead of them actually running
        // /prestige; (2) confiscates any release item a player holds that
        // isn't part of their currently-allowed set, so stashing one in a
        // chest right before prestiging can't dodge the wipe. See
        // ReleaseEnforcementHandler's and CommandPrestige.enforceReleaseOwnership()'s
        // javadoc - the latter has a heads-up about the mod's "steal a
        // dojutsu by killing its owner" mechanic.
        MinecraftForge.EVENT_BUS.register(new ReleaseEnforcementHandler());
        // Combined "[Hokage] [Leaf] [P5] PlayerName"-style prefix in chat
        // (2026-09-20, per Dennis's request) - see PrefixManager's javadoc
        // for the full mechanism (tab list/nametag via a per-player
        // scoreboard team, chat reinforced directly here).
        MinecraftForge.EVENT_BUS.register(new ChatPrefixHandler());
        proxy.preInit();
    }

    @Mod.EventHandler
    public void serverStarting(FMLServerStartingEvent event) {
        event.registerServerCommand(new CommandVillage());
        event.registerServerCommand(new CommandPrestige());
        // Fixes the 2026-09-19 "Exception ticking world" crash in The End -
        // see SpawnListSanitizer's javadoc for the full root cause (a
        // third-party addon's Orochimaru spawn registration ending up with
        // weight 0 in a biome list that's otherwise empty). Runs here
        // because every mod's init() phase (where addSpawn calls happen)
        // has already finished by FMLServerStartingEvent, so this always
        // sees every registration a mod is going to make.
        SpawnListSanitizer.removeZeroWeightSpawnEntries();
    }

    /**
     * Runs the rank/scoreboard setup automatically every time this world's
     * server fully starts (dedicated server, or the internal integrated
     * server behind a singleplayer/LAN world - this event fires for both),
     * but SKIPS it whenever SetupWorldData says this world is already at
     * CURRENT_SETUP_VERSION - so in practice it's a no-op on every restart
     * except the very first one, and any later one right after an update
     * that bumped CURRENT_SETUP_VERSION (see that constant's comment).
     * Delete-then-recreate makes re-running this safe/idempotent. Replaces
     * having to paste one_time_setup_commands.txt into console by hand -
     * that file is still there for reference/manual re-use if you ever need
     * it (e.g. to force a re-sync sooner than the next restart).
     */
    @Mod.EventHandler
    public void serverStarted(FMLServerStartedEvent event) {
        MinecraftServer server = FMLCommonHandler.instance().getMinecraftServerInstance();
        if (server == null) {
            return;
        }

        World overworld = server.getWorld(0);
        SetupWorldData setup = SetupWorldData.get(overworld);
        if (setup.getSetupVersion() >= CURRENT_SETUP_VERSION) {
            return;
        }

        for (String village : VILLAGES) {
            server.getCommandManager().executeCommand(server, "ranks create " + village);
        }

        for (String kageTitle : KAGE_TITLES) {
            server.getCommandManager().executeCommand(server, "ranks create " + kageTitle);
        }

        int[] prestigeCaps = CommandPrestige.TIER_CAPS;

        // Prestige0: the cap a brand new player (prestige score 0) sits
        // under before their first-ever /prestige - see the
        // CURRENT_SETUP_VERSION=4 comment above. Unlike Prestige1..15
        // below, its cap is TIER_CAPS[0] itself (the threshold to reach
        // Prestige1), not the NEXT tier's threshold - there's no "tier -1"
        // to have already climbed past.
        server.getCommandManager().executeCommand(server, "rank delete Prestige0");
        server.getCommandManager().executeCommand(server, "rank create Prestige0 " + prestigeCaps[0]);

        for (int tier = 1; tier <= prestigeCaps.length; tier++) {
            server.getCommandManager().executeCommand(server, "rank delete Prestige" + tier);
        }
        for (int tier = 1; tier <= prestigeCaps.length; tier++) {
            // The "PrestigeN" rank is what a player HOLDS once they've
            // reached tier N - FTBUtilities enforces its number as an NXP
            // CAP on the holder, so it has to be the threshold for the
            // NEXT tier (prestigeCaps[tier], not prestigeCaps[tier - 1]
            // which was only ever the threshold to become tier N in the
            // first place - CommandPrestige.execute()'s own
            // "TIER_CAPS[prestige]" check already uses that same
            // next-tier number, this just makes the in-game rank cap
            // agree with it). Prestige<max> has no next tier to reuse, so
            // it just repeats the top value.
            int cap = (tier < prestigeCaps.length) ? prestigeCaps[tier] : prestigeCaps[tier - 1];
            server.getCommandManager().executeCommand(server,
                    "rank create Prestige" + tier + " " + cap);
        }

        server.getCommandManager().executeCommand(server, "scoreboard objectives add prestige dummy");

        setup.markSetupVersion(CURRENT_SETUP_VERSION);
    }
}

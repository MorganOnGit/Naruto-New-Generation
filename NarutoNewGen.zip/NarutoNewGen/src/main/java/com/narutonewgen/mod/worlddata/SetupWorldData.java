package com.narutonewgen.mod.worlddata;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.world.storage.MapStorage;
import net.minecraft.world.storage.WorldSavedData;

/**
 * Persisted VERSION marking how far the one-time rank/scoreboard setup (the
 * 6 village ranks, the 15 Prestige ranks with their current NXP thresholds,
 * and the "prestige" scoreboard objective) has run for this world.
 *
 * This started as a plain boolean flag so NarutoNewGenMod could run that
 * setup automatically on first boot instead of requiring an admin to paste
 * one_time_setup_commands.txt into console by hand, and so it only ran
 * ONCE - re-running /rank delete + /rank create on every restart would be
 * wasteful, and briefly removing a Prestige rank a player currently holds
 * (between the delete and the create) on every boot is exactly the kind of
 * thing that flag avoided.
 *
 * FIXED (2026-09-18): a plain "already ran" boolean meant that whenever
 * CommandPrestige.TIER_CAPS changed (e.g. the move to 15 tiers / 500,000
 * max NXP), a world that had already run setup under the OLD numbers never
 * got its actual FTBUtilities Prestige ranks updated to match - the ranks
 * silently kept their stale caps forever, which is exactly the "the
 * prestige ranks' NXP cap doesn't match up to the prestige caps" bug this
 * was reported as. Versioning fixes this: NarutoNewGenMod.CURRENT_SETUP_VERSION
 * is bumped any time a tier-cap-affecting change like that is made, and
 * serverStarted() re-runs the (idempotent - delete-then-recreate) rank
 * setup whenever a world's recorded version is behind, self-healing stale
 * ranks on the next boot instead of needing a manual console fix.
 */
public class SetupWorldData extends WorldSavedData {

    private static final String DATA_NAME = "narutonewgen_setup";

    // -1 = setup has never run at all yet for this world.
    private int setupVersion = -1;

    public SetupWorldData(String name) {
        super(name);
    }

    public static SetupWorldData get(World world) {
        MapStorage storage = world.getPerWorldStorage();
        SetupWorldData data = (SetupWorldData) storage.getOrLoadData(SetupWorldData.class, DATA_NAME);
        if (data == null) {
            data = new SetupWorldData(DATA_NAME);
            storage.setData(DATA_NAME, data);
        }
        return data;
    }

    public int getSetupVersion() {
        return setupVersion;
    }

    public void markSetupVersion(int version) {
        setupVersion = version;
        markDirty();
    }

    @Override
    public void readFromNBT(NBTTagCompound nbt) {
        if (nbt.hasKey("setupVersion")) {
            setupVersion = nbt.getInteger("setupVersion");
        } else if (nbt.getBoolean("setupComplete")) {
            // Migrating a world saved by the old boolean-only flag - treat
            // it as version 0 so it re-syncs against whatever
            // CURRENT_SETUP_VERSION is now, fixing stale rank caps left
            // over from before this versioning existed.
            setupVersion = 0;
        } else {
            setupVersion = -1;
        }
    }

    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound compound) {
        compound.setInteger("setupVersion", setupVersion);
        return compound;
    }
}

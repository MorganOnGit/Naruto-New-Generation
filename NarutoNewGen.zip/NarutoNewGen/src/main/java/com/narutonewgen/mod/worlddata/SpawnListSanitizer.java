package com.narutonewgen.mod.worlddata;

import net.minecraft.entity.EnumCreatureType;
import net.minecraft.world.biome.Biome;
import net.minecraftforge.fml.common.FMLLog;

import java.util.Iterator;

/**
 * Fixes the server crash from 2026-09-19's crash log:
 *
 *   IllegalArgumentException at net.minecraft.util.WeightedRandom.getRandomItem
 *   <- WorldServer.getSpawnListEntryForTypeAt
 *   <- WorldEntitySpawner.findChunksForSpawning
 *   <- WorldServer.tick
 *
 * which happened right after a player loaded The End (dimension 1) for the
 * first time in the world and the server attempted its next natural
 * mob-spawn pass there.
 *
 * Root cause, found by decompiling every addon jar in run/mods: the "AHZNB
 * Curse Mark" addon (springaddon-*.jar, package
 * net.mcreator.ahznbcursemarkaddon) registers its Orochimaru mob as an
 * EnumCreatureType.AMBIENT natural spawn in EVERY biome in the game -
 * including The End's Sky biome - via
 *   EntityRegistry.addSpawn(EntityOrochimaru.class, (int) ModConfig.OROCHIMARU_WEIGHT,
 *           1, 1, EnumCreatureType.AMBIENT, allBiomes)
 * The addon's own config screen describes OROCHIMARU_WEIGHT as "Orochimaru's
 * spawn weight (0~20). 0 to stop spawning" - but setting it to 0 doesn't
 * skip this addSpawn call, it just registers a SpawnListEntry with
 * itemWeight 0 anyway (unlike some of the other addons' spawn registration
 * code, which does guard against a zero-or-lower configured weight by
 * skipping the addSpawn call entirely). The End's AMBIENT spawn list has no
 * other entries by default (vanilla only ever puts Enderman in The End's
 * MONSTER list), so that single zero-weight entry became the ENTIRE list,
 * and the list's total weight summed to exactly 0. The moment the server
 * tried to naturally spawn an AMBIENT-type creature in The End,
 * WeightedRandom.getRandomItem() called Random.nextInt(0), which always
 * throws IllegalArgumentException ("bound must be positive") - and because
 * this happens on the main server-tick thread inside world tick, that
 * exception takes the whole server down (ReportedException: "Exception
 * ticking world").
 *
 * This isn't something patchable from OROCHIMARU_WEIGHT's own config file -
 * ANY value from 0 up to (but not including) 1 truncates to the same
 * zero-weight registration (it's cast straight from a double to an int with
 * no rounding), and there's no config option that skips the registration
 * outright. Rather than editing or rebuilding a third-party mod's jar (and
 * leaving the door open for the exact same bug from any other addon that
 * makes the same mistake), this runs once per server start, after every
 * mod's init() phase has already finished registering its natural spawns,
 * and strips out any leftover zero-or-negative-weight SpawnListEntry from
 * every biome's spawn list, for every creature type. A list left empty
 * after that can never reach WeightedRandom.getRandomItem() in the first
 * place - vanilla's own WorldServer.getSpawnListEntryForTypeAt() already
 * skips empty lists before calling it - so this is a complete fix, not a
 * band-aid, and it also covers any future addon that ships the same kind
 * of bug.
 */
public class SpawnListSanitizer {

    public static void removeZeroWeightSpawnEntries() {
        int removed = 0;

        for (Biome biome : Biome.REGISTRY) {
            for (EnumCreatureType type : EnumCreatureType.values()) {
                Iterator<Biome.SpawnListEntry> it = biome.getSpawnableList(type).iterator();
                while (it.hasNext()) {
                    Biome.SpawnListEntry entry = it.next();
                    if (entry.itemWeight <= 0) {
                        FMLLog.log.warn("[NarutoNewGen] Removing zero/negative-weight natural spawn entry "
                                + entry.entityClass.getName() + " (weight " + entry.itemWeight + ") from biome "
                                + biome.getRegistryName() + " / " + type + " - left in place, this crashes "
                                + "natural mob spawning the moment it's the only entry in that biome's list "
                                + "(see SpawnListSanitizer's class javadoc for the full story).");
                        it.remove();
                        removed++;
                    }
                }
            }
        }

        if (removed > 0) {
            FMLLog.log.warn("[NarutoNewGen] Removed " + removed + " zero/negative-weight natural-spawn "
                    + "entries across all biomes on this server start, to prevent a WeightedRandom "
                    + "IllegalArgumentException from crashing world ticking.");
        }
    }
}

package com.narutonewgen.mod.network;

import com.narutonewgen.mod.command.VillageActions;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/**
 * Client -> server packet covering every GUI button action (vote, promote,
 * assign/verify quest, create team). One generic message with a named
 * action and a few string args, rather than a dozen near-identical message
 * classes. All real logic lives in VillageActions, shared with the /village
 * chat command so both paths behave identically.
 */
public class MessageVillageAction implements IMessage {

    private String action;
    private String arg1 = "";
    private String arg2 = "";
    private String arg3 = "";

    public MessageVillageAction() {
    }

    public MessageVillageAction(String action, String arg1, String arg2, String arg3) {
        this.action = action;
        this.arg1 = arg1;
        this.arg2 = arg2;
        this.arg3 = arg3;
    }

    @Override
    public void toBytes(ByteBuf buf) {
        ByteBufUtils.writeUTF8String(buf, action);
        ByteBufUtils.writeUTF8String(buf, arg1);
        ByteBufUtils.writeUTF8String(buf, arg2);
        ByteBufUtils.writeUTF8String(buf, arg3);
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        action = ByteBufUtils.readUTF8String(buf);
        arg1 = ByteBufUtils.readUTF8String(buf);
        arg2 = ByteBufUtils.readUTF8String(buf);
        arg3 = ByteBufUtils.readUTF8String(buf);
    }

    public static class Handler implements IMessageHandler<MessageVillageAction, IMessage> {
        @Override
        public IMessage onMessage(MessageVillageAction message, MessageContext ctx) {
            EntityPlayerMP sender = ctx.getServerHandler().player;
            // Hop onto the server thread - network messages arrive on the
            // network thread, and touching world/player state off-thread is
            // a common cause of race conditions and crashes.
            net.minecraftforge.fml.common.FMLCommonHandler.instance().getMinecraftServerInstance()
                    .addScheduledTask(() ->
                            VillageActions.handleGuiAction(sender, message.action, message.arg1, message.arg2, message.arg3));
            return null;
        }
    }
}

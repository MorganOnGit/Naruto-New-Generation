package com.narutonewgen.mod.prefix;

import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * Prepends PrefixManager's combined "[Hokage] [Leaf] [P5]" tag directly onto
 * chat messages (2026-09-20, per Dennis's request), rather than trusting
 * the scoreboard-team trick (PrefixManager.refreshPrefix()) to reach chat
 * on its own. Vanilla WOULD show it there for free - EntityPlayer.getDisplayName()
 * already folds a player's team prefix into the name it hands the default
 * "chat.type.text" formatter - but FTBUtilities is known to build its own
 * chat line per rank (its "syntax" config) rather than using
 * getDisplayName() at all, so relying only on the vanilla path risks the
 * tag quietly not showing up in chat even though it's correctly showing in
 * the tab list and above players' heads.
 *
 * Registered at LOWEST priority specifically so this runs AFTER any other
 * mod (FTBUtilities included) has already set its own formatted
 * event.getComponent() - this handler doesn't replace that, it just
 * prepends the combined tag in front of whatever's already there, so it
 * degrades gracefully instead of fighting another mod's chat formatting or
 * silently losing it if FTBUtilities changes its format in some future
 * update.
 */
public class ChatPrefixHandler {

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onServerChat(ServerChatEvent event) {
        if (event.isCanceled()) return;

        EntityPlayerMP player = event.getPlayer();
        String prefix = PrefixManager.buildPrefix(player);
        if (prefix.isEmpty()) return;

        ITextComponent existing = event.getComponent();
        ITextComponent withPrefix = new TextComponentString(prefix).appendSibling(existing);
        event.setComponent(withPrefix);
    }
}

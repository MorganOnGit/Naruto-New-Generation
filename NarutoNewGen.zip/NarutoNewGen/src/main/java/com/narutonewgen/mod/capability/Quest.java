package com.narutonewgen.mod.capability;

import net.minecraft.nbt.NBTTagCompound;

/** A quest assigned to a specific player by their village's Kage. */
public class Quest {

    public enum Status {
        IN_PROGRESS,
        PENDING_VERIFICATION,
        COMPLETE
    }

    private String description;
    private String assignedBy;
    private Status status;

    public Quest() {
    }

    public Quest(String description, String assignedBy, Status status) {
        this.description = description;
        this.assignedBy = assignedBy;
        this.status = status;
    }

    public String getDescription() { return description; }
    public String getAssignedBy() { return assignedBy; }
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }

    public NBTTagCompound writeToNBT() {
        NBTTagCompound tag = new NBTTagCompound();
        tag.setString("description", description);
        tag.setString("assignedBy", assignedBy);
        tag.setString("status", status.name());
        return tag;
    }

    public static Quest readFromNBT(NBTTagCompound tag) {
        Quest quest = new Quest();
        quest.description = tag.getString("description");
        quest.assignedBy = tag.getString("assignedBy");
        quest.status = Status.valueOf(tag.getString("status"));
        return quest;
    }
}

package com.narutonewgen.mod.command;

import com.narutonewgen.mod.worlddata.PrestigeReleaseData;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.TextComponentString;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Player-triggered prestige. A player runs /prestige; if their current NXP
 * meets the requirement for their next tier, they prestige: their rank/cap
 * bumps up, their prestige count goes up by 1, their ENTIRE release set is
 * wiped, and their NXP resets to 0 - starting a brand new climb toward their
 * next prestige.
 *
 * REPEATABLE PRESTIGE 15 (added 2026-09-19, per Dennis): once a player
 * reaches the top FTBUtilities rank (Prestige15), /prestige no longer
 * refuses further use. Every repeat past that point requires Prestige15's
 * own cap again (500,000 NXP) and does everything a normal prestige does
 * (wipe releases, revoke advancements, reset NXP, re-climb through all 15
 * checkpoints) EXCEPT change rank, since there's no rank higher than
 * Prestige15 to move into - only the raw prestige count keeps climbing,
 * which also keeps growing the +10%-per-prestige NXP bonus below with every
 * repeat, and every 100th repeat grants a Chakra Fruit. See execute()'s
 * "reachingNewRank" handling and maybeGrantChakraFruitMilestone().
 *
 * IMPORTANT (changed 2026-09-19, per Dennis): /prestige itself grants NO
 * releases anymore. It used to wipe everything and immediately re-roll +
 * grant one release for EVERY tier from 1 through the new prestige number,
 * all in one go - but that made it look like NXP wasn't really being reset
 * (a pile of releases would appear the instant someone prestiged, before
 * they'd earned a single point of NXP toward their new climb). NXP WAS
 * resetting correctly the whole time; the atomic grant was just misleading.
 * Now /prestige is purely the rank-up + wipe + reset action. Every release
 * the player is due - one per tier, 1 through their new prestige level -
 * gets (re-)earned the exact same way early previews always worked DURING a
 * climb: see checkPrestigeProgressPreview() below. Since /prestige clears
 * both the player's current releases AND which tiers were already
 * preview-granted, and resets NXP to 0, that preview check naturally starts
 * granting tier 1's release again the moment NXP first re-crosses 5,000 (no
 * earlier), tier 2's at 7,500, and so on - never all at once, only as each
 * threshold is actually passed again.
 *
 * Because everything gets wiped together every time, PrestigeReleaseData/
 * ReleaseEnforcementHandler (the anti-storage-exploit check that stops a
 * player from stashing a release in a chest right before prestiging to
 * dodge the wipe) is relevant and registered/active - see
 * enforceReleaseOwnership() below.
 *
 * IMPORTANT: every release listed in RELEASES is granted DIRECTLY by this
 * class - the "/giveNinjaRelease" command (from the third-party kabutoaddon
 * mod) is never invoked anymore. That command's own procedure code has real
 * bugs (confirmed NPEs on several argument combinations, e.g. "sagemode"),
 * and several of the releases below have no working command token at all
 * (Boil, Storm, Scorch, Typhoon/Dark/Mud/Swift/Crystal/Blaze Release,
 * Cursemark, Paper Ninjutsu, Karma Seal, Rasengan...). None of that matters
 * here: every release is just a normal registered item, looked up by its
 * registry name and placed into the player's inventory or armor slot
 * ourselves, with the matching advancement granted afterward. See
 * grantRelease() below.
 *
 * SETUP REQUIRED:
 *   1. Run one_time_setup_commands.txt once in console (creates the 12 ranks
 *      + the "prestige" scoreboard objective) - or just let
 *      NarutoNewGenMod's automatic first-boot setup do it.
 *   2. Fill in NXP_TAG_PATH below once you've found it with NBTExplorer.
 */
public class CommandPrestige extends CommandBase {

    // Confirmed via NBTExplorer: NXP lives directly in ForgeData (not
    // nested further), under the key "battle_experience".
    private static final String[] NXP_TAG_PATH = { "ForgeData", "battle_experience" };

    // Updated tier thresholds - now 15 tiers, max 500,000 NXP. Public so
    // NarutoNewGenMod's automatic one-time setup (creates the
    // Prestige1..15 ranks on first server start) can read the same numbers
    // instead of duplicating them - keeps this array the single source of
    // truth for the thresholds. That setup loop already runs
    // "for (tier = 1; tier <= TIER_CAPS.length; tier++)", so going from 12
    // to 15 tiers here is the only code change it needed.
    public static final int[] TIER_CAPS = {
            5000, 7500, 15000, 25000, 50000, 75000,
            100000, 125000, 150000, 175000, 200000, 250000,
            300000, 400000, 500000
    };

    private static final Random RANDOM = new Random();

    // Confirmed via decompiling NarutomodModVariables: the Java field is
    // named "MostRecentWornDojutsuTime" but the actual NBT key it writes is
    // this string - narutomod's own field name doesn't match the tag it
    // holds. See resetDojutsuBlindnessTracking()'s javadoc for the full
    // story of why this needs resetting.
    private static final String LAST_WORN_DOJUTSU_TIME_TAG = "mostRecentlyHadAnyDojutsu";

    // Own NBT key (never touched by narutomod) tracking the last raw NXP
    // value applyPrestigeNxpBonus() has already seen/accounted for, per
    // player. See that method's javadoc for the full mechanism - this is
    // what lets it tell "the player naturally gained some NXP since the
    // last check" apart from "NXP went down" or "no change", without
    // needing to hook every one of the many scattered places narutomod
    // itself adds to battle_experience internally.
    private static final String NXP_BASELINE_TAG = "narutonewgen_lastObservedNxp";

    // +10% total NXP gained per prestige level, added 2026-09-19 per
    // Dennis's request ("for each prestige you did you get 10% more total
    // ninxp from any source"). Prestige 3 => +30% on top of whatever NXP a
    // player earns from then on. Uncapped: since Prestige 15 is itself
    // repeatable indefinitely (also added 2026-09-19 - see execute()'s
    // "reachingNewRank" handling), getPrestigeScore() keeps climbing past
    // 15 with every repeat, so this bonus keeps growing right along with
    // it - Prestige 15 plus 5 repeats (score 20) => +200%, and so on. See
    // applyPrestigeNxpBonus() below for exactly how "from any source" is
    // achieved without narutomod cooperating, and for why this only ever
    // boosts NEW gains, never a player's existing NXP total.
    private static final double NXP_BONUS_PER_PRESTIGE = 0.10;

    /**
     * One entry per grantable release. key is the internal id used by
     * TIER_POOLS below (arbitrary, just has to be unique here).
     *
     * itemIds: the item(s) to give. A single-entry array for a normal held
     * item; multiple entries for a dojutsu-style armor SET (helmet/body/
     * legs - none of these have a boots piece, confirmed against the actual
     * item registrations).
     *
     * armorSlots: null for a normal held item (added straight to inventory).
     * For armor, one slot per entry in itemIds, in the same order - the item
     * is equipped directly into that slot (and silently replaces whatever
     * was worn there before, which is the desired behaviour for an eye
     * evolving into a stronger form).
     *
     * advancementId / criterionId: nullable. Every advancement in these
     * jars uses a "minecraft:impossible" trigger, meaning the game will
     * never grant it on its own - it has to be granted from code, which is
     * exactly what grantRelease() below does. Some of shinobiaddon's own
     * advancement JSONs have a copy-pasted criterion key of literally
     * "mud_release" regardless of which release the file is actually for
     * (a bug in that addon, not ours) - criterionId reflects that ACTUAL
     * key, not the display name, so the grant still works correctly.
     *
     * prerequisiteItemIds: nullable. If set, the player must already own at
     * least one of these items to be eligible for this release. Checked at
     * grant time against their live inventory/armor, not a separate flag -
     * see hasAnyItem().
     *
     * fallbackKey: nullable. Only meaningful for a FIXED single-release
     * tier. If the player isn't eligible yet when that tier fires (e.g. they
     * reach the Rinnegan tier without ever having rolled Eternal Mangekyou
     * from an earlier random pool), instead of granting nothing we walk
     * back to this key and try again - so a fixed "capstone" tier always
     * gives useful forward progress instead of occasionally whiffing.
     */
    private static final class ReleaseDef {
        final String displayName;
        final String[] itemIds;
        final EntityEquipmentSlot[] armorSlots;
        final String advancementId;
        final String criterionId;
        final String[] prerequisiteItemIds;
        final String fallbackKey;

        ReleaseDef(String displayName, String[] itemIds, EntityEquipmentSlot[] armorSlots,
                   String advancementId, String criterionId, String[] prerequisiteItemIds, String fallbackKey) {
            this.displayName = displayName;
            this.itemIds = itemIds;
            this.armorSlots = armorSlots;
            this.advancementId = advancementId;
            this.criterionId = criterionId;
            this.prerequisiteItemIds = prerequisiteItemIds;
            this.fallbackKey = fallbackKey;
        }
    }

    private static ReleaseDef item(String key, String display, String itemId, String advId, String critId) {
        return new ReleaseDef(display, new String[]{ itemId }, null, advId, critId, null, null);
    }

    private static ReleaseDef itemGated(String display, String itemId, String advId, String critId,
                                         String[] prereqIds) {
        return new ReleaseDef(display, new String[]{ itemId }, null, advId, critId, prereqIds, null);
    }

    // Like item(), but for a single roll that hands over SEVERAL held items
    // at once (e.g. Medical Ninjutsu + all of its jutsu scrolls) rather than
    // just one. armorSlots stays null so grantRelease() adds every one of
    // itemIds straight to inventory, same as a plain item() grant just
    // looped - and clearReleaseItems()/RELEASE_ITEMS_TO_CLEAR (built from
    // every itemId across every ReleaseDef automatically) wipes all of them
    // together on the next prestige, same as any other release.
    private static ReleaseDef items(String display, String[] itemIds, String advId, String critId) {
        return new ReleaseDef(display, itemIds, null, advId, critId, null, null);
    }

    private static ReleaseDef armor(String display, String[] itemIds, EntityEquipmentSlot[] slots,
                                     String advId, String critId) {
        return new ReleaseDef(display, itemIds, slots, advId, critId, null, null);
    }

    private static ReleaseDef armorGated(String display, String[] itemIds, EntityEquipmentSlot[] slots,
                                          String advId, String critId, String[] prereqIds, String fallbackKey) {
        return new ReleaseDef(display, itemIds, slots, advId, critId, prereqIds, fallbackKey);
    }

    private static final EntityEquipmentSlot[] HEAD = { EntityEquipmentSlot.HEAD };
    private static final EntityEquipmentSlot[] HEAD_CHEST_LEGS =
            { EntityEquipmentSlot.HEAD, EntityEquipmentSlot.CHEST, EntityEquipmentSlot.LEGS };

    // All registry ids and advancement/criterion ids below were confirmed
    // directly against the actual mod jars (lang files + advancement JSON +
    // decompiled class references), not guessed - see the release-inventory
    // reference doc for the full breakdown of how each one was found.
    private static final Map<String, ReleaseDef> RELEASES = new HashMap<>();
    static {
        // --- narutomod: basic kekkei genkai (held items) ---
        RELEASES.put("ice", item("ice", "Ice Release",
                "narutomod:hyoton", "narutomod:hyoton_acquired", "hyoton_acquired"));
        RELEASES.put("lava", item("lava", "Lava Release",
                "narutomod:yooton", "narutomod:yooton_acquired", "yooton_acquired"));
        RELEASES.put("bone", item("bone", "Skeletal Control (Shikotsumyaku)",
                "narutomod:shikotsumyaku", "narutomod:shikotsumyaku_acquired", "shikotsumyaku_acquired"));
        RELEASES.put("explosion", item("explosion", "Explosion Release",
                "narutomod:bakuton", "narutomod:bakuton_acquired", "bakuton_acquired"));
        RELEASES.put("scorch", item("scorch", "Scorch Release",
                "narutomod:shakuton", "narutomod:shakuton_acquired", "shakuton_acquired"));
        RELEASES.put("boil", item("boil", "Boil Release",
                "narutomod:futton", "narutomod:futton_acquired", "futton_acquired"));
        RELEASES.put("storm", item("storm", "Storm Release",
                "narutomod:ranton", "narutomod:ranton_acquired", "ranton_acquired"));
        RELEASES.put("wood", item("wood", "Wood Release",
                "narutomod:mokuton", "narutomod:mokuton_acquired", "mokuton_acquired"));
        RELEASES.put("magnet", item("magnet", "Magnet Release",
                "narutomod:jiton", "narutomod:jiton_acquired", "jiton_acquired"));
        // "particle"/"Dust Release" from the old pool and narutomod's own
        // Kekkei Tota advancement are the SAME item (narutomod:jinton,
        // confirmed via that advancement's own icon field) - not two
        // separate things, so there's only one entry for it.
        RELEASES.put("dust", item("dust", "Dust Release (Kekkei Tota)",
                "narutomod:jinton", "narutomod:kekkei_tota_awakened", "kekkei_tota_awakened"));
        RELEASES.put("eightgates", item("eightgates", "Eight Gates",
                "narutomod:eightgates", "narutomod:openedgates", "openedgates"));
        RELEASES.put("senjutsu", item("senjutsu", "Senjutsu",
                "narutomod:senjutsu", null, null));
        // Per Dennis's request (2026-09-19): getting Medical Ninjutsu should
        // also hand over every one of its jutsu scrolls, not just the base
        // unlock item - confirmed against the jar's lang file/item classes,
        // these 4 scrolls are the only "Medical Ninjutsu - ... jutsu" items
        // that exist (a separate "Medical Scroll" item also exists but
        // isn't one of the named jutsus, so it's left out).
        RELEASES.put("medicalninjutsu", items("Medical Ninjutsu",
                new String[]{ "narutomod:iryo_jutsu", "narutomod:scroll_cellular_activation",
                        "narutomod:scroll_healing", "narutomod:scroll_poison_mist",
                        "narutomod:scroll_enhanced_strength" },
                null, null));
        RELEASES.put("rasengan", item("rasengan", "Rasengan",
                "narutomod:scroll_rasengan", null, null));

        // --- narutomod: dojutsu (armor, equipped directly + advancement) ---
        RELEASES.put("byakugan", armor("Byakugan",
                new String[]{ "narutomod:byakuganhelmet" }, HEAD,
                "narutomod:byakuganopened", "byakuganopened"));
        RELEASES.put("sharingan", armor("Sharingan",
                new String[]{ "narutomod:sharinganhelmet" }, HEAD,
                "narutomod:sharinganopened", "sharinganopened"));
        // Mangekyou has two narutomod variants (Amaterasu-line helmet and
        // the Obito/Kamui-line helmet) - picked randomly so it feels like a
        // real "which Mangekyou did you awaken" moment rather than always
        // being the same one. Either counts for anything gated on "have
        // Mangekyou".
        RELEASES.put("mangekyo_amaterasu", armorGated("Mangekyou Sharingan - Amaterasu",
                new String[]{ "narutomod:mangekyosharinganhelmet" }, HEAD,
                "narutomod:mangekyosharinganopened", "mangekyosharinganopened",
                new String[]{ "narutomod:sharinganhelmet" }, "sharingan"));
        RELEASES.put("mangekyo_kamui", armorGated("Mangekyou Sharingan - Kamui",
                new String[]{ "narutomod:mangekyosharinganobitohelmet" }, HEAD,
                "narutomod:mangekyosharinganopened", "mangekyosharinganopened",
                new String[]{ "narutomod:sharinganhelmet" }, "sharingan"));
        RELEASES.put("eternalmangekyo", armorGated("Eternal Mangekyou Sharingan",
                new String[]{ "narutomod:mangekyosharinganeternalhelmet" }, HEAD,
                "narutomod:eternalmangekyoachieved", "eternalmangekyoachieved",
                new String[]{ "narutomod:mangekyosharinganhelmet", "narutomod:mangekyosharinganobitohelmet" },
                "mangekyo_amaterasu"));
        RELEASES.put("rinnegan", armorGated("Rinnegan",
                new String[]{ "narutomod:rinneganhelmet", "narutomod:rinneganbody", "narutomod:rinneganlegs" },
                HEAD_CHEST_LEGS,
                "narutomod:rinneganawakened", "rinneganawakened",
                new String[]{ "narutomod:mangekyosharinganeternalhelmet" }, "eternalmangekyo"));
        RELEASES.put("tenseigan", armorGated("Tenseigan",
                new String[]{ "narutomod:tenseiganhelmet", "narutomod:tenseiganbody", "narutomod:tenseiganlegs" },
                HEAD_CHEST_LEGS,
                "narutomod:tenseigan_achieved", "tenseigan_achieved",
                new String[]{ "narutomod:byakuganhelmet" }, "byakugan"));

        // --- kabutoaddon's own items (no advancements exist in that addon at all) ---
        RELEASES.put("paperninjutsu", item("paperninjutsu", "Paper Ninjutsu",
                "kabutoaddon:paper_release", null, null));
        RELEASES.put("karmaseal", item("karmaseal", "Karma Seal",
                "kabutoaddon:karma_seal", null, null));

        // REMOVED (2026-09-19, per Dennis): ahznbcursemarkaddon's own
        // generic "Cursemark" (ahznbcursemarkaddon:cursemark_mode) is no
        // longer granted at all - superseded by the 4 character-specific
        // Curse Marks below (Sasuke/Kimimaro/Tayuya/Sakon), which are now
        // mutually exclusive with each other (see MUTUALLY_EXCLUSIVE_GROUPS).

        // --- dynamicdojutsu (2026-09-19: this addon was renamed from
        // "ShinobiAdditions"/shinobiaddon to "Dynamic Dojutsu" - the jar,
        // display name AND modid all changed to dynamicdojutsu, even though
        // the Java package underneath is still com.leolifeless.shinobiaddon.
        // Every ITEM id and ADVANCEMENT id below that used to start with
        // "shinobiaddon:" had to move to "dynamicdojutsu:" - confirmed
        // directly against the new jar's assets, not guessed. Every one of
        // these advancements still has the SAME criterion key,
        // "mud_release", regardless of which release it's actually for -
        // the copy/paste bug carried over into the new items too, still not
        // ours to fix, still harmless as long as the criterion name we
        // grant matches what's actually in the file. ---
        //
        // REMOVED: Mud Release and Crystal Release no longer exist as items
        // in the new jar at all (no lang entry, no advancement, nothing) -
        // granting either of the old "shinobiaddon:mud_release" /
        // "shinobiaddon:crystal_release" ids would now just silently fail
        // ("Missing item" message, nothing granted). Swapped them for two
        // of the new items that fill the same D-Rank "elemental release
        // side-grade" niche - Steel Release and Black Lightning Release -
        // so the pool stays at 6 instead of shrinking to 4. This was MY
        // call to keep the pool from being broken/thin in the meantime -
        // say the word if you'd rather slot different new content in here
        // (see release-inventory.md's "Dynamic Dojutsu update" section for
        // everything else the new jar adds that isn't wired in yet).
        RELEASES.put("typhoon", item("typhoon", "Typhoon Release",
                "dynamicdojutsu:typhoon_release", "dynamicdojutsu:typhoon_release_acquired", "mud_release"));
        RELEASES.put("dark", item("dark", "Dark Release",
                "dynamicdojutsu:dark_release", "dynamicdojutsu:dark_release_acquired", "mud_release"));
        RELEASES.put("steel", item("steel", "Steel Release",
                "dynamicdojutsu:steel_release", "dynamicdojutsu:steel_release_acquired", "mud_release"));
        RELEASES.put("swift", item("swift", "Swift Release",
                "dynamicdojutsu:swift_release", "dynamicdojutsu:swift_release_acquired", "mud_release"));
        RELEASES.put("blacklightning", item("blacklightning", "Black Lightning Release",
                "dynamicdojutsu:black_lightning_release", "dynamicdojutsu:black_lightning_release_acquired", "mud_release"));
        // dynamicdojutsu's own advancement for this is still parented under
        // narutomod's mangekyosharinganopened advancement, same as it was
        // under the old shinobiaddon jar - i.e. the addon's own author
        // still intends Blaze Release to require Mangekyou, matching
        // exactly what was asked for here originally.
        RELEASES.put("blaze", itemGated("Blaze Release",
                "dynamicdojutsu:blaze_release", "dynamicdojutsu:blaze_release_acquired", "mud_release",
                new String[]{ "narutomod:mangekyosharinganhelmet", "narutomod:mangekyosharinganobitohelmet",
                        "narutomod:mangekyosharinganeternalhelmet" }));

        // --- more dynamicdojutsu content, added 2026-09-19 per Dennis's
        // request. All 4 of these (like kabutoaddon's own items) have zero
        // advancement defined in the addon at all - confirmed against the
        // jar's advancements/ folder, not just assumed. ---
        RELEASES.put("barrier", item("barrier", "Barrier Release",
                "dynamicdojutsu:barrier_release", null, null));
        RELEASES.put("blueflame", item("blueflame", "Blue Flame Release",
                "dynamicdojutsu:blue_flame_release", null, null));
        RELEASES.put("acid", item("acid", "Acid Release",
                "dynamicdojutsu:acid_release", null, null));
        RELEASES.put("ink", item("ink", "Ink Release",
                "dynamicdojutsu:ink_release", null, null));
        // Sitting on the "candidate" list since the very first inventory
        // pass, before it had a confirmed registry id - now confirmed and
        // added. Moved from S Rank to C Rank 2026-09-19 per Dennis.
        RELEASES.put("sevenheavens", item("sevenheavens", "Seven Heavenly Breathing Method",
                "dynamicdojutsu:sevenheavens", null, null));
        // 4 character-specific cursemarks - now the ONLY cursemark content
        // granted at all (the generic ahznbcursemarkaddon one was removed
        // 2026-09-19) - and mutually exclusive with each other, see
        // MUTUALLY_EXCLUSIVE_GROUPS: a player ends up with exactly one of
        // these 4, never more. Zero advancements defined for any of these.
        RELEASES.put("cursemark_sasuke", item("cursemark_sasuke", "Curse Mark [Sasuke]",
                "dynamicdojutsu:cursemark_sasuke", null, null));
        RELEASES.put("cursemark_kimimaro", item("cursemark_kimimaro", "Curse Mark [Kimimaro]",
                "dynamicdojutsu:cursemark_kimimaro", null, null));
        RELEASES.put("cursemark_tayuya", item("cursemark_tayuya", "Curse Mark [Tayuya]",
                "dynamicdojutsu:cursemark_tayuya", null, null));
        RELEASES.put("cursemark_sakon", item("cursemark_sakon", "Curse Mark [Sakon]",
                "dynamicdojutsu:cursemark_sakon", null, null));
    }

    // Rank bands: D = tiers 1-3, C = 4-6, B = 7-9, A = 10-12, S = 13-15.
    // Each band shares ONE pool across its 3 tiers, and every tier is a
    // random pick - there are no more fixed single-item tiers (Sharingan,
    // Mangekyou, Dust Release, Wood, Rinnegan and Tenseigan all moved from
    // being guaranteed at a specific tier to being one option among their
    // band's pool, same as everything else).
    //
    // IMPORTANT TRADE-OFF from removing the fixed tiers: Sharingan is one
    // of 5 options rolled 3 times across tiers 4-6 (C Rank), not
    // guaranteed. Mangekyou (B Rank) needs Sharingan, and Eternal Mangekyou
    // (A Rank) needs Mangekyou - if a player rolls unluckily and never gets
    // Sharingan during their 3 C-Rank prestiges, Mangekyou/Eternal
    // Mangekyou/Rinnegan all become permanently unreachable, since C
    // Rank's pool isn't offered again once a player has moved on to B/A/S.
    // Same idea for Tenseigan needing Byakugan, also now in C Rank's pool.
    // The isEligible() filtering still prevents any crash or "impossible"
    // grant - a gated item is just silently excluded from the roll until
    // its prerequisite is met - but there is no more guaranteed catch-up
    // path. If that's not what you want, say so and I can add a "reroll if
    // the whole pool comes up empty" safety net, or bias the odds so gated
    // items' prerequisites are more likely to show up early in their band.
    // Rebalanced 2026-09-19 per Dennis: Typhoon moved A -> B; the generic
    // kabutoaddon Cursemark removed outright; Barrier/Ink/Acid moved
    // A -> B (Blue Flame stays in A); Seven Heavens moved S -> C. See
    // MUTUALLY_EXCLUSIVE_GROUPS below for the 4 character Curse Marks now
    // being capped at one per player.
    //
    // Rebalanced AGAIN 2026-09-19 per Dennis: Dust Release moved A -> S;
    // Ink and Acid Release moved from the B-Rank spot they'd just been
    // given above straight to D Rank (Barrier stays in B).
    //
    // Rebalanced YET AGAIN 2026-09-19 per Dennis: Acid Release removed from
    // the pool entirely - it can no longer be rolled at any tier. Its
    // RELEASES definition is left in place (harmless dead entry) so nothing
    // breaks for a player who was already granted it before this change.
    //
    // Rebalanced AGAIN 2026-09-20 per Dennis: Ink Release removed from the
    // pool entirely too, the same way Acid was above - its RELEASES
    // definition is likewise left in place (harmless dead entry) for any
    // player already granted it.
    private static final String[][] TIER_POOLS = {
            /* tier 1  */ { "ice", "lava", "boil", "swift", "steel", "blacklightning" },  // D Rank pool
            /* tier 2  */ { "ice", "lava", "boil", "swift", "steel", "blacklightning" },
            /* tier 3  */ { "ice", "lava", "boil", "swift", "steel", "blacklightning" },
            /* tier 4  */ { "explosion", "rasengan", "byakugan", "sharingan", "paperninjutsu", "sevenheavens" }, // C Rank pool
            /* tier 5  */ { "explosion", "rasengan", "byakugan", "sharingan", "paperninjutsu", "sevenheavens" },
            /* tier 6  */ { "explosion", "rasengan", "byakugan", "sharingan", "paperninjutsu", "sevenheavens" },
            /* tier 7  */ { "mangekyo_amaterasu", "mangekyo_kamui", "bone", "medicalninjutsu", "storm", "magnet",
                             "typhoon", "barrier" },  // B Rank pool
            /* tier 8  */ { "mangekyo_amaterasu", "mangekyo_kamui", "bone", "medicalninjutsu", "storm", "magnet",
                             "typhoon", "barrier" },
            /* tier 9  */ { "mangekyo_amaterasu", "mangekyo_kamui", "bone", "medicalninjutsu", "storm", "magnet",
                             "typhoon", "barrier" },
            /* tier 10 */ { "eternalmangekyo", "dark", "blaze", "karmaseal", "scorch", "blueflame",
                             "cursemark_sasuke", "cursemark_kimimaro", "cursemark_tayuya", "cursemark_sakon" }, // A Rank pool
            /* tier 11 */ { "eternalmangekyo", "dark", "blaze", "karmaseal", "scorch", "blueflame",
                             "cursemark_sasuke", "cursemark_kimimaro", "cursemark_tayuya", "cursemark_sakon" },
            /* tier 12 */ { "eternalmangekyo", "dark", "blaze", "karmaseal", "scorch", "blueflame",
                             "cursemark_sasuke", "cursemark_kimimaro", "cursemark_tayuya", "cursemark_sakon" },
            // S Rank pool. Candidates still not decided (see
            // release-inventory.md): Six Path Senjutsu, Kekkei Mora, Yin
            // Release, the full Rinne-Sharingan armor upgrade, Susanoo
            // Armor, Byakugou.
            /* tier 13 */ { "rinnegan", "tenseigan", "eightgates", "wood", "senjutsu", "dust" },  // S Rank pool
            /* tier 14 */ { "rinnegan", "tenseigan", "eightgates", "wood", "senjutsu", "dust" },
            /* tier 15 */ { "rinnegan", "tenseigan", "eightgates", "wood", "senjutsu", "dust" },
    };

    // Groups of releases where owning ANY ONE means every OTHER member
    // should never be rollable again for that player - added 2026-09-19 per
    // Dennis's request that a player end up with exactly one of the 4
    // character-specific Curse Marks, never more than one, even across
    // separate re-rolls on later tiers or future prestiges. Checked by
    // rollReleaseForTier() via excludedByMutualExclusivity() below, on top
    // of (not instead of) the normal isEligible()/hasAllItems() filtering.
    private static final String[][] MUTUALLY_EXCLUSIVE_GROUPS = {
            { "cursemark_sasuke", "cursemark_kimimaro", "cursemark_tayuya", "cursemark_sakon" },
    };

    /**
     * True if `key` belongs to a MUTUALLY_EXCLUSIVE_GROUPS entry and the
     * player already owns a DIFFERENT member of that same group - meaning
     * `key` should be excluded from any future roll for this player,
     * regardless of whether they're otherwise eligible for it.
     */
    private static boolean excludedByMutualExclusivity(EntityPlayerMP player, String key) {
        for (String[] group : MUTUALLY_EXCLUSIVE_GROUPS) {
            if (!Arrays.asList(group).contains(key)) continue;
            for (String other : group) {
                if (other.equals(key)) continue;
                ReleaseDef otherDef = RELEASES.get(other);
                if (otherDef != null && hasAnyItem(player, otherDef.itemIds)) return true;
            }
        }
        return false;
    }

    // Purely a display label - does NOT change thresholds, FTBUtilities
    // rank names (still Prestige1..Prestige15), pools, or how /prestige
    // works at all. Just shown in the success message so players see
    // "D Rank" instead of a bare tier number.
    private static final String[] TIER_RANK_LABEL = {
            /* tier 1  */ "D Rank",
            /* tier 2  */ "D Rank",
            /* tier 3  */ "D Rank",
            /* tier 4  */ "C Rank",
            /* tier 5  */ "C Rank",
            /* tier 6  */ "C Rank",
            /* tier 7  */ "B Rank",
            /* tier 8  */ "B Rank",
            /* tier 9  */ "B Rank",
            /* tier 10 */ "A Rank",
            /* tier 11 */ "A Rank",
            /* tier 12 */ "A Rank",
            /* tier 13 */ "S Rank",
            /* tier 14 */ "S Rank",
            /* tier 15 */ "S Rank",
    };

    // No fixed tiers anymore - every tier is a random pick from its band's
    // pool. resolveWithFallback() below is now unreachable (it only runs
    // for a non-random tier) but left in place in case a fixed tier ever
    // comes back.
    private static final boolean[] TIER_RANDOM_PICK = {
            /* tier 1  */ true,
            /* tier 2  */ true,
            /* tier 3  */ true,
            /* tier 4  */ true,
            /* tier 5  */ true,
            /* tier 6  */ true,
            /* tier 7  */ true,
            /* tier 8  */ true,
            /* tier 9  */ true,
            /* tier 10 */ true,
            /* tier 11 */ true,
            /* tier 12 */ true,
            /* tier 13 */ true,
            /* tier 14 */ true,
            /* tier 15 */ true,
    };

    // Every known release item id, built directly from every itemId across
    // every ReleaseDef in RELEASES, so ANY release this system can ever
    // grant gets wiped on every prestige - nothing to keep in sync by hand.
    // Used both by clearReleaseItems() (the wipe) and enforceReleaseOwnership()
    // (the "which items are release items at all" watch list).
    private static final String[] RELEASE_ITEMS_TO_CLEAR = buildAllReleaseItemIds();

    private static String[] buildAllReleaseItemIds() {
        java.util.LinkedHashSet<String> ids = new java.util.LinkedHashSet<>();
        for (ReleaseDef def : RELEASES.values()) {
            ids.addAll(Arrays.asList(def.itemIds));
        }
        return ids.toArray(new String[0]);
    }

    @Override
    public String getName() {
        return "prestige";
    }

    @Override
    public String getUsage(ICommandSender sender) {
        return "/prestige";
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 0; // any player can try
    }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (!(sender.getCommandSenderEntity() instanceof EntityPlayerMP)) {
            throw new CommandException("Only players can use /prestige.");
        }
        EntityPlayerMP player = (EntityPlayerMP) sender.getCommandSenderEntity();

        int prestige = getPrestigeScore(player);

        Integer nxp = readNxp(player);
        if (nxp == null) {
            throw new CommandException("Could not read your current NXP — NXP_TAG_PATH isn't set up yet.");
        }

        // Once a player holds the top FTBUtilities rank (Prestige15,
        // prestige == TIER_CAPS.length), there's no higher rank left to
        // climb into - but per Dennis's request (2026-09-19), /prestige no
        // longer stops there. Every repeat past that point just requires
        // Prestige15's own cap again (TIER_CAPS' last entry, 500,000 NXP)
        // forever, exactly like Prestige15's rank itself already reuses
        // that same top value (see NarutoNewGenMod's rank-cap setup) since
        // there's no tier 16 to have a real threshold for.
        int requiredCap = prestige < TIER_CAPS.length ? TIER_CAPS[prestige] : TIER_CAPS[TIER_CAPS.length - 1];
        if (nxp < requiredCap) {
            player.sendMessage(new TextComponentString(
                    "You need " + requiredCap + " NXP to prestige (you currently have " + nxp + ")."));
            return;
        }

        int nextPrestige = prestige + 1;
        // True for every ordinary prestige (1 through 15); false once a
        // player is repeating past Prestige 15, where there's no further
        // FTBUtilities rank to move into - see the block below and
        // execute()'s message/Chakra-Fruit handling further down.
        boolean reachingNewRank = nextPrestige <= TIER_CAPS.length;

        if (reachingNewRank) {
            // Bump their enforced cap to the next tier FIRST - confirmed via
            // testing that /addninjaxp does genuinely subtract when run
            // directly, so the earlier "doesn't reset" bug was actually the
            // rank change running before the reset and re-inflating XP back up
            // to that rank's own floor. Doing the reset LAST avoids that.
            String nextRank = "Prestige" + nextPrestige;
            server.getCommandManager().executeCommand(server, "rank add " + player.getName() + " " + nextRank);
        }
        // else: player already holds the max FTBUtilities rank (Prestige15)
        // and there's nothing higher to "rank add" into - this repeat just
        // wipes/resets/re-climbs at that same rank and cap, as many times as
        // they want, with setPrestigeScore() below still letting the raw
        // score climb past TIER_CAPS.length so applyPrestigeNxpBonus()'s
        // +10%-per-prestige bonus keeps growing with every repeat too.

        // Wipe every release the player currently holds. FIXED (2026-09-19):
        // /prestige used to immediately re-roll and grant one release per
        // tier for EVERY tier 1..nextPrestige right here, all in one go -
        // Dennis flagged that this made it look like NXP wasn't really
        // being reset (a player would see a pile of releases appear the
        // instant they prestiged, before they'd earned a single point of
        // NXP toward their new climb). It WAS resetting correctly - the
        // atomic grant was just handing out every tier's worth of releases
        // up front regardless. Per Dennis's call, /prestige is now PURELY
        // the rank-up + wipe + reset action - it grants nothing itself.
        // Every release the player is due (one per tier, 1 through their
        // new prestige level) gets (re-)earned exactly the way early
        // previews already worked during a climb: checkPrestigeProgressPreview()
        // (run every 20 ticks and on login - see ReleaseEnforcementHandler)
        // grants a release the moment NXP first crosses each tier's
        // checkpoint AFTER this reset, tier by tier, in order, as it's
        // actually passed - not all at once.
        clearReleaseItems(player);

        // Revoke every release advancement too, not just the items - added
        // 2026-09-19 per Dennis's request. Without this, a player who'd
        // already earned e.g. "Sharingan Acquired" before this prestige
        // would keep that advancement showing complete forever even after
        // losing the actual item above, and re-earning Sharingan on a
        // future climb wouldn't show the achievement toast again since the
        // game already considers it done. See revokeAllReleaseAdvancements()
        // below.
        revokeAllReleaseAdvancements(player);

        // Track prestige count.
        setPrestigeScore(player, nextPrestige);

        // Nothing has been (re-)granted yet at this point - the player's
        // "currently allowed" set starts EMPTY, and checkPrestigeProgressPreview()
        // will merge items back into it one at a time as NXP climbs past
        // each checkpoint below. Without this, enforceReleaseOwnership()
        // would still be comparing against whatever was allowed before this
        // prestige, even though clearReleaseItems() just wiped all of it.
        PrestigeReleaseData.get(player.world).setAllowedItemIds(player.getUniqueID(), new ArrayList<>());

        // NXP is about to reset to 0 below, starting a brand new climb -
        // clear which tiers were already preview-granted during the climb
        // that just ended, so checkPrestigeProgressPreview() starts fresh
        // and re-fires for tier 1 onward again as this new climb actually
        // passes each checkpoint (otherwise it would think every tier up to
        // the old prestige was already handled and stay silent).
        PrestigeReleaseData.get(player.world).clearPreviewGrantedTiers(player.getUniqueID());

        // Reset NXP back to 0 LAST (after "rank add" above), by writing the
        // NBT tag directly rather than trusting the "addninjaxp" command to
        // subtract correctly - FIXED: that command was leaving NXP untouched
        // (or only partially reduced) for some players, so /prestige could
        // be re-run immediately without ever actually losing NXP. Also
        // FIXED (2026-09-19): this used to go through a full
        // player.writeToNBT()/readFromNBT() round trip, which silently
        // replaced the player's live custom-data compound with a
        // disconnected copy instead of editing it in place - see
        // resetNxp()'s own javadoc below for the full story. Doing the
        // reset LAST (after "rank add") also avoids rank add's own
        // rank-floor behavior re-inflating NXP right back up.
        resetNxp(player);

        // Pull the NXP-gain-bonus baseline (see applyPrestigeNxpBonus())
        // down to 0 right along with the reset above, instead of just
        // letting the next periodic check notice the drop on its own -
        // avoids a narrow (up to CHECK_INTERVAL_TICKS-long) window right
        // after prestiging where any NXP gained is compared against the
        // OLD, pre-reset baseline and reads as "a decrease", so that
        // sliver of genuine post-reset gain would silently miss its bonus
        // instead of just being a no-op re-baseline like normal.
        player.getEntityData().setDouble(NXP_BASELINE_TAG, 0.0);

        if (reachingNewRank) {
            String rankLabel = TIER_RANK_LABEL[nextPrestige - 1];
            player.sendMessage(new TextComponentString(
                    "§6§lPrestige " + nextPrestige + " (" + rankLabel + ")! §rYour NXP is back to 0 - your releases for "
                            + "this rank will unlock again as you climb back up to each threshold."));
        } else {
            // repeatNumber: 1 for the first repeat past Prestige 15, 2 for
            // the second, and so on - used both for the message and for
            // maybeGrantChakraFruitMilestone()'s every-100th-repeat check.
            int repeatNumber = nextPrestige - TIER_CAPS.length;
            player.sendMessage(new TextComponentString(
                    "§6§lPrestige 15 (S Rank) - repeat #" + repeatNumber + "! §rYour NXP is back to 0 - your "
                            + "releases will unlock again as you climb back up to each threshold."));
            maybeGrantChakraFruitMilestone(player, repeatNumber);
        }

        // Updates the "[P5]"-style tag in chat/tab/nametag immediately,
        // rather than leaving it stale until the player's next login
        // (2026-09-20, per Dennis's request).
        com.narutonewgen.mod.prefix.PrefixManager.refreshPrefix(player);
    }

    // Registry id for narutomod's own "Chakra Fruit" food item - confirmed
    // against the jar's lang file (item.chakrafruit.name=Chakra Fruit) and
    // the decompiled ItemChakraFruit class.
    private static final String CHAKRA_FRUIT_ITEM_ID = "narutomod:chakrafruit";

    // Per Dennis's request (2026-09-19): repeating Prestige 15 this many
    // times earns a Chakra Fruit. Implemented as a recurring milestone
    // (fires again at 200, 300, ...) rather than a one-time reward that
    // stops mattering after the first 100 repeats, since the whole point of
    // repeating is to keep doing it indefinitely - say the word if you'd
    // rather it fire exactly once, ever, instead.
    private static final int CHAKRA_FRUIT_REPEAT_INTERVAL = 100;

    /**
     * Grants a Chakra Fruit every CHAKRA_FRUIT_REPEAT_INTERVAL Prestige-15
     * repeats. Called from execute() right after a successful repeat -
     * repeatNumber is 1 for the first repeat past Prestige 15, 2 for the
     * second, and so on, so repeatNumber % CHAKRA_FRUIT_REPEAT_INTERVAL == 0
     * lands on repeat 100, 200, 300, ...
     */
    private static void maybeGrantChakraFruitMilestone(EntityPlayerMP player, int repeatNumber) {
        if (repeatNumber <= 0 || repeatNumber % CHAKRA_FRUIT_REPEAT_INTERVAL != 0) return;

        Item item = Item.REGISTRY.getObject(new ResourceLocation(CHAKRA_FRUIT_ITEM_ID));
        if (item == null) {
            player.sendMessage(new TextComponentString(
                    "§c[NarutoNewGen] Missing item " + CHAKRA_FRUIT_ITEM_ID + " for your Chakra Fruit milestone "
                            + "reward - is narutomod installed?"));
            return;
        }
        giveOrDropItem(player, new ItemStack(item));
        player.sendMessage(new TextComponentString(
                "§b[NarutoNewGen] " + repeatNumber + " Prestige 15 repeats - here's a Chakra Fruit!"));
    }

    /** True if the player already owns any one of the given item ids, anywhere in their inventory or armor. */
    private static boolean hasAnyItem(EntityPlayerMP player, String[] itemIds) {
        if (itemIds == null || itemIds.length == 0) return true;
        List<String> targets = Arrays.asList(itemIds);
        IInventory inv = player.inventory;
        for (int i = 0; i < inv.getSizeInventory(); i++) {
            ItemStack stack = inv.getStackInSlot(i);
            if (stack.isEmpty()) continue;
            String regName = stack.getItem().getRegistryName() != null
                    ? stack.getItem().getRegistryName().toString() : "";
            if (targets.contains(regName)) return true;
        }
        return false;
    }

    private static boolean isEligible(EntityPlayerMP player, String key) {
        ReleaseDef def = RELEASES.get(key);
        if (def == null) return false;
        return def.prerequisiteItemIds == null || hasAnyItem(player, def.prerequisiteItemIds);
    }

    /** True only if the player currently holds EVERY one of the given item ids (all pieces of a multi-part release). */
    private static boolean hasAllItems(EntityPlayerMP player, String[] itemIds) {
        for (String id : itemIds) {
            if (!hasAnyItem(player, new String[]{ id })) return false;
        }
        return true;
    }

    /**
     * Rolls one release for a single tier during a full /prestige
     * regeneration: builds the eligible list from that tier's rank-band
     * pool (excluding anything gated whose prerequisite isn't held YET in
     * this run, and anything the player already fully holds from an
     * earlier tier rolled earlier in this same run - see hasAllItems()),
     * then picks randomly among what's left. Returns null if nothing in
     * the pool is currently eligible/new (the player simply gets nothing
     * for that tier this time, same as before).
     */
    private static String rollReleaseForTier(EntityPlayerMP player, int tier) {
        String[] tierPool = TIER_POOLS[tier - 1];
        List<String> eligible = new ArrayList<>();
        for (String key : tierPool) {
            if (!isEligible(player, key)) continue;
            if (excludedByMutualExclusivity(player, key)) continue;
            ReleaseDef candidate = RELEASES.get(key);
            if (candidate != null && hasAllItems(player, candidate.itemIds)) continue;
            eligible.add(key);
        }
        if (eligible.isEmpty()) return null;
        return eligible.get(RANDOM.nextInt(eligible.size()));
    }

    /**
     * THE mechanism that actually grants releases - run periodically (every
     * 20 ticks, see ReleaseEnforcementHandler) and on login, for every
     * online player regardless of whether they've run /prestige recently.
     *
     * IMPORTANT (changed 2026-09-19): this used to be described as an
     * "early preview" ahead of /prestige's own separate atomic grant -
     * that atomic grant is gone now (see execute()'s javadoc above), so
     * this is no longer a preview of anything, it's the ONLY way a release
     * is ever granted. NXP resets to 0 after a real /prestige and
     * TIER_CAPS is just 15 fixed, strictly increasing NXP checkpoints
     * (5,000 up to 500,000) - so on ANY climb toward a player's next
     * prestige, their raw NXP naturally passes through every smaller
     * checkpoint too before reaching the one they're aiming for (e.g.
     * climbing from Prestige 14 toward Prestige 15's 500,000 requirement
     * means passing through 5,000, then 7,500, then 15,000, ... all the way
     * up). This grants a release the MOMENT current NXP first crosses each
     * checkpoint, without touching prestige rank or NXP itself - /prestige
     * only wipes releases, bumps rank, and resets NXP to 0, which is what
     * makes this fire again from tier 1 onward on the next climb.
     *
     * PrestigeReleaseData.getPreviewGrantedTiers() tracks which tiers have
     * already fired since the player's last real /prestige (cleared there
     * too), so this doesn't re-roll/re-grant the same tier every tick. A
     * tier whose threshold is reached but currently has nothing eligible
     * (e.g. Mangekyou before Sharingan has come up) is simply retried again
     * next tick rather than being marked done, in case eligibility opens up
     * from a later checkpoint firing first.
     *
     * REMOVED (2026-09-19, per Dennis's request that Prestige 15 be
     * repeatable indefinitely): this used to bail out entirely once
     * getPrestigeScore(player) reached TIER_CAPS.length, on the assumption
     * there was nothing left to climb toward. Now that /prestige lets the
     * raw prestige score keep climbing past 15 with each repeat (see
     * execute()'s javadoc), that assumption no longer holds - a player
     * repeating Prestige 15 re-climbs from 0 back up through all 15
     * checkpoints again just like any other prestige, and needs this to
     * keep firing tier by tier along the way.
     */
    public static void checkPrestigeProgressPreview(EntityPlayerMP player) {
        Integer nxp = readNxp(player);
        if (nxp == null) return;

        PrestigeReleaseData data = PrestigeReleaseData.get(player.world);
        java.util.Set<Integer> alreadyPreviewed = data.getPreviewGrantedTiers(player.getUniqueID());

        for (int tier = 1; tier <= TIER_CAPS.length; tier++) {
            if (nxp < TIER_CAPS[tier - 1]) break; // checkpoints only increase, so nothing further is reached yet
            if (alreadyPreviewed.contains(tier)) continue;

            String key = rollReleaseForTier(player, tier);
            if (key == null) continue; // nothing eligible for this tier yet - retry next tick

            ReleaseDef def = RELEASES.get(key);
            if (def == null) continue;

            grantRelease(player, def);
            data.markPreviewTierGranted(player.getUniqueID(), tier);
            // Merge (not replace) into the allowed set so enforceReleaseOwnership()
            // doesn't immediately confiscate this preview item as "not entitled".
            data.addAllowedItemIds(player.getUniqueID(), Arrays.asList(def.itemIds));

            player.sendMessage(new TextComponentString(
                    "§b[NarutoNewGen] You've reached " + TIER_CAPS[tier - 1] + " NXP and unlocked "
                            + def.displayName + " early! Run /prestige once you're ready to lock in your rank."));
        }
    }

    /**
     * For a FIXED (non-random) tier entry: if the player is eligible for
     * `key`, returns it as-is. If not, walks back to that release's
     * fallbackKey and checks again, repeating until something eligible is
     * found (or there's nowhere left to fall back to). This is what
     * guarantees a fixed capstone tier (Rinnegan, Tenseigan, Mangekyou)
     * always grants useful forward progress instead of nothing.
     */
    private static String resolveWithFallback(EntityPlayerMP player, String key) {
        String current = key;
        // Small safety cap on chain length so a misconfigured fallback loop
        // can never hang the server.
        for (int i = 0; i < 10 && current != null; i++) {
            ReleaseDef def = RELEASES.get(current);
            if (def == null) return current;
            if (isEligible(player, current)) return current;
            current = def.fallbackKey;
        }
        return current;
    }

    /**
     * Grants a release directly: equips armor pieces (or adds a held item to
     * the inventory), then grants the matching advancement criterion if one
     * is configured. Completely bypasses kabutoaddon's "/giveNinjaRelease"
     * command and its ProcedureGiveRelease bugs.
     */
    private static void grantRelease(EntityPlayerMP player, ReleaseDef def) {
        UUID uuid = player.getUniqueID();
        for (int i = 0; i < def.itemIds.length; i++) {
            Item item = Item.REGISTRY.getObject(new ResourceLocation(def.itemIds[i]));
            if (item == null) {
                player.sendMessage(new TextComponentString(
                        "§c[NarutoNewGen] Missing item " + def.itemIds[i] + " for " + def.displayName
                                + " - is that mod installed?"));
                continue;
            }
            ItemStack stack = new ItemStack(item);

            if (def.armorSlots != null) {
                // Dojutsu/armor: stamp ownership NBT (player_idMost/Least +
                // display name) the same way a naturally-obtained item gets,
                // then equip it directly - this also naturally replaces
                // whatever was worn in that slot before, which is exactly
                // right for an eye evolving into a stronger form.
                NBTTagCompound tag = new NBTTagCompound();
                tag.setLong("player_idMost", uuid.getMostSignificantBits());
                tag.setLong("player_idLeast", uuid.getLeastSignificantBits());
                NBTTagCompound display = new NBTTagCompound();
                display.setString("Name", player.getName() + "'s " + def.displayName);
                tag.setTag("display", display);
                stack.setTagCompound(tag);

                player.setItemStackToSlot(def.armorSlots[i], stack);
            } else {
                giveOrDropItem(player, stack);
            }
        }

        if (def.advancementId != null && def.criterionId != null) {
            MinecraftServer server = net.minecraftforge.fml.common.FMLCommonHandler.instance().getMinecraftServerInstance();
            if (server != null) {
                net.minecraft.advancements.Advancement advancement =
                        server.getAdvancementManager().getAdvancement(new ResourceLocation(def.advancementId));
                if (advancement != null) {
                    player.getAdvancements().grantCriterion(advancement, def.criterionId);
                }
            }
        }
    }

    /**
     * Adds a held-item release/reward to the player's inventory, dropping
     * whatever doesn't fit at their feet instead of silently discarding it
     * (2026-09-20, per Dennis's request - "make sure players dont lose the
     * release"). InventoryPlayer.addItemStackToInventory() mutates `stack`
     * down to whatever's LEFT OVER (fully empties it on complete success),
     * so checking !stack.isEmpty() after the call - not just the boolean
     * return value - also catches a partial merge into existing stacks.
     * Mirrors vanilla's own CommandGive: dropItem(stack, false) tosses it
     * gently in front of the player rather than flinging it, and
     * setNoPickupDelay() lets them grab it back immediately once they free
     * up a slot instead of vanilla's default ~2-second delay.
     */
    private static void giveOrDropItem(EntityPlayerMP player, ItemStack stack) {
        boolean fullyAdded = player.inventory.addItemStackToInventory(stack);
        if (fullyAdded && stack.isEmpty()) return;

        EntityItem entityItem = player.dropItem(stack, false);
        if (entityItem != null) {
            entityItem.setNoPickupDelay();
        }
        player.sendMessage(new TextComponentString(
                "§e[NarutoNewGen] Your inventory was full, so it was dropped at your feet instead - grab it before it despawns!"));
    }

    // Public (2026-09-20) so PrefixManager can read a player's current tier
    // for the "[P5]"-style chat/tab/nametag prefix without duplicating this
    // scoreboard-objective lookup.
    public static int getPrestigeScore(EntityPlayerMP player) {
        Scoreboard scoreboard = player.getWorldScoreboard();
        ScoreObjective objective = scoreboard.getObjective("prestige");
        if (objective == null) return 0;
        Score score = scoreboard.getOrCreateScore(player.getName(), objective);
        return score.getScorePoints();
    }

    private static void setPrestigeScore(EntityPlayerMP player, int value) {
        Scoreboard scoreboard = player.getWorldScoreboard();
        ScoreObjective objective = scoreboard.getObjective("prestige");
        if (objective == null) return;
        Score score = scoreboard.getOrCreateScore(player.getName(), objective);
        score.setScorePoints(value);
    }

    /**
     * Walks NXP_TAG_PATH down to the raw number, starting from
     * player.getEntityData() rather than a full writeToNBT() snapshot.
     * NXP_TAG_PATH[0] ("ForgeData") is exactly the tag name Entity's custom
     * per-entity data gets serialized under when the WHOLE entity is
     * written to NBT - getEntityData() IS that same compound already
     * unwrapped, so the walk below intentionally starts at path index 1,
     * not 0. See resetNxp()'s javadoc for why this replaced a
     * writeToNBT()/readFromNBT() round trip.
     */
    private static Integer readNxp(EntityPlayerMP player) {
        if (NXP_TAG_PATH.length < 2) return null;

        NBTTagCompound current = player.getEntityData();
        for (int i = 1; i < NXP_TAG_PATH.length - 1; i++) {
            String key = NXP_TAG_PATH[i];
            if (!current.hasKey(key)) return null;
            current = current.getCompoundTag(key);
        }
        String lastKey = NXP_TAG_PATH[NXP_TAG_PATH.length - 1];
        if (!current.hasKey(lastKey)) return null;
        // If your NXP is stored as a decimal instead of a whole number, swap
        // getInteger for getDouble and (int) cast the result.
        return current.getInteger(lastKey);
    }

    /**
     * FIXED (2026-09-19): the previous implementation took a full
     * player.writeToNBT() snapshot, edited battle_experience to 0 inside
     * that snapshot, then called player.readFromNBT(nbt) to write it back.
     * That's the actual reason NXP kept not resetting: Forge's
     * Entity#readFromNBT() doesn't edit the entity's existing custom-data
     * object in place - it REPLACES the entity's customEntityData field
     * with a brand new NBTTagCompound built from the snapshot
     * (this.customEntityData = compound.getCompoundTag("ForgeData")). If
     * narutomod itself grabbed player.getEntityData() once and held onto
     * that reference (very likely, since it's the standard way a
     * non-capability-based mod persists a simple stat like this) rather
     * than calling getEntityData() fresh every time it reads/writes NXP,
     * that stale reference kept pointing at the OLD, orphaned compound
     * after our swap - so narutomod itself, and anything checking NXP
     * through it, kept seeing the pre-reset value forever, even though a
     * NEW, disconnected copy correctly had 0 in it.
     *
     * Fix: mutate player.getEntityData() DIRECTLY, in place. getEntityData()
     * always returns the SAME live object (it only ever allocates a new one
     * the first time, if none exists yet) - so this changes the exact
     * compound narutomod's own code is holding onto, instead of swapping in
     * a different one out from under it. No full-entity round trip, so
     * nothing else on the player (inventory, position, capabilities, etc.)
     * gets touched at all.
     */
    private static void resetNxp(EntityPlayerMP player) {
        if (NXP_TAG_PATH.length < 2) return;

        NBTTagCompound current = player.getEntityData();
        for (int i = 1; i < NXP_TAG_PATH.length - 1; i++) {
            String key = NXP_TAG_PATH[i];
            if (!current.hasKey(key)) return; // path doesn't exist, nothing to reset
            current = current.getCompoundTag(key);
        }
        String lastKey = NXP_TAG_PATH[NXP_TAG_PATH.length - 1];
        // If your NXP is stored as a decimal, swap setInteger for setDouble.
        current.setInteger(lastKey, 0);
    }

    /**
     * Same NXP_TAG_PATH walk as readNxp()/resetNxp() above, but read/written
     * as a double rather than an int. Confirmed via decompiling narutomod's
     * ProcedureSharinganHelmetTickEvent (it reads battle_experience with
     * NBTTagCompound.getDouble()) that narutomod itself actually stores NXP
     * as an NBTTagDouble - readNxp()/resetNxp() have always treated it as a
     * whole number instead, which has been harmless for THOSE two (an int
     * read/write of a double-backed tag just truncates any fractional part,
     * and every threshold check anywhere in this class only ever compares
     * against whole-number TIER_CAPS anyway). It would NOT be harmless for
     * applyPrestigeNxpBonus() below, though: that works off small per-check
     * deltas, and silently truncating every single one to a whole number
     * would throw away most of a typical tick's worth of gain. These two
     * read/write the real underlying type instead, to avoid that.
     */
    private static Double readNxpRaw(EntityPlayerMP player) {
        if (NXP_TAG_PATH.length < 2) return null;
        NBTTagCompound current = player.getEntityData();
        for (int i = 1; i < NXP_TAG_PATH.length - 1; i++) {
            String key = NXP_TAG_PATH[i];
            if (!current.hasKey(key)) return null;
            current = current.getCompoundTag(key);
        }
        String lastKey = NXP_TAG_PATH[NXP_TAG_PATH.length - 1];
        if (!current.hasKey(lastKey)) return null;
        return current.getDouble(lastKey);
    }

    private static void writeNxpRaw(EntityPlayerMP player, double value) {
        if (NXP_TAG_PATH.length < 2) return;
        NBTTagCompound current = player.getEntityData();
        for (int i = 1; i < NXP_TAG_PATH.length - 1; i++) {
            String key = NXP_TAG_PATH[i];
            if (!current.hasKey(key)) return;
            current = current.getCompoundTag(key);
        }
        String lastKey = NXP_TAG_PATH[NXP_TAG_PATH.length - 1];
        current.setDouble(lastKey, value);
    }

    /**
     * Boosts NXP gains - from ANY source, per Dennis's request - by
     * NXP_BONUS_PER_PRESTIGE per prestige level the player has already
     * earned. narutomod adds to battle_experience from many scattered
     * internal places (combat, quests, and more), none of which this mod
     * can hook directly without decompiling and patching narutomod's own
     * class files - so instead of intercepting every gain at its source,
     * this works by simple before/after comparison: NXP_BASELINE_TAG
     * remembers the last raw NXP value this method has already seen and
     * accounted for, and every time it runs again (every 20 ticks and on
     * login, alongside the other periodic checks - see
     * ReleaseEnforcementHandler, which calls this FIRST each pass so any
     * bonus is already reflected before checkPrestigeProgressPreview()
     * checks tier thresholds that same pass) it compares CURRENT raw NXP
     * against that baseline:
     *
     *   - No baseline tag yet (first time ever seen for this player - a
     *     brand new join, or their first check after this feature ships):
     *     just records the current value as the baseline and stops there.
     *     A player's EXISTING NXP total never gets retroactively boosted -
     *     only NXP earned from this point on does.
     *   - Current > baseline (a genuine gain happened since the last
     *     check): the gain gets topped up by prestige * NXP_BONUS_PER_PRESTIGE
     *     - e.g. 500 raw NXP gained at Prestige 3 becomes a total increase
     *     of 500 * 1.30 = 650. The baseline then advances to this NEW
     *     (boosted) value, so the bonus itself is never re-counted as a
     *     further "gain" on the next check.
     *   - Current <= baseline (no gain, or NXP went DOWN - most notably
     *     /prestige's own resetNxp() dropping it to 0, though execute()
     *     also resets this baseline directly at the same time to avoid
     *     even the small timing window this fallback exists for): no bonus
     *     applied, baseline just pulled down to match - which alone is
     *     enough to naturally re-arm this for a fresh climb after every
     *     prestige, no special-casing needed.
     *   - Prestige 0 (never prestiged): multiplier is 0, so gains pass
     *     through unmodified, but the baseline still advances every check -
     *     a player's eventual first prestige doesn't suddenly try to "catch
     *     up" on a huge backlog of ungained bonus.
     */
    public static void applyPrestigeNxpBonus(EntityPlayerMP player) {
        Double currentRaw = readNxpRaw(player);
        if (currentRaw == null) return;

        NBTTagCompound data = player.getEntityData();
        if (!data.hasKey(NXP_BASELINE_TAG)) {
            data.setDouble(NXP_BASELINE_TAG, currentRaw);
            return;
        }

        double baseline = data.getDouble(NXP_BASELINE_TAG);
        double gain = currentRaw - baseline;
        if (gain <= 0.0) {
            data.setDouble(NXP_BASELINE_TAG, currentRaw);
            return;
        }

        int prestige = getPrestigeScore(player);
        if (prestige <= 0) {
            data.setDouble(NXP_BASELINE_TAG, currentRaw);
            return;
        }

        double boosted = currentRaw + gain * (NXP_BONUS_PER_PRESTIGE * prestige);
        writeNxpRaw(player, boosted);
        data.setDouble(NXP_BASELINE_TAG, boosted);
    }

    /**
     * Wipes every known release from a player's inventory/armor. Called at
     * the start of every successful /prestige so nothing from the previous
     * prestige level survives - every release for the new level has to be
     * earned back via checkPrestigeProgressPreview() as NXP climbs again.
     */
    private static void clearReleaseItems(EntityPlayerMP player) {
        if (RELEASE_ITEMS_TO_CLEAR.length == 0) return;
        List<String> toRemove = Arrays.asList(RELEASE_ITEMS_TO_CLEAR);
        IInventory inv = player.inventory;
        for (int i = 0; i < inv.getSizeInventory(); i++) {
            ItemStack stack = inv.getStackInSlot(i);
            if (stack.isEmpty()) continue;
            String regName = stack.getItem().getRegistryName() != null
                    ? stack.getItem().getRegistryName().toString() : "";
            if (toRemove.contains(regName)) {
                inv.setInventorySlotContents(i, ItemStack.EMPTY);
            }
        }

        resetDojutsuBlindnessTracking(player);
    }

    /**
     * FIXED (2026-09-19, per Dennis's report of repeating 1-minute
     * Blindness after prestiging with an active - even perfectly healthy,
     * undamaged - Dojutsu). Decompiling narutomod's ProcedureOnPlayerPostTick
     * (a global per-tick check on every player) turned up a completely
     * separate mechanic from the "worn-out eye" durability blindness:
     * every tick, it compares PlayerTracker.Deaths.mostRecentTime(player)
     * (an IN-MEMORY-ONLY death log the mod keeps, defaulting to 0 for
     * anyone who hasn't died since the server started) against this
     * player's LAST_WORN_DOJUTSU_TIME_TAG NBT value - a timestamp
     * ItemDojutsu.Base.onArmorTick() (shared by every dojutsu type -
     * Byakugan, the whole Sharingan line, Rinnegan, Tenseigan) refreshes
     * every 20 ticks to "now" for as long as ANY dojutsu is equipped. If
     * that "last worn" timestamp is more recent than the "last died"
     * timestamp, narutomod blinds the player for 1200 ticks (1 minute) -
     * and re-applies it EVERY tick the condition still holds, which is
     * forever, since removing the item just FREEZES "last worn" at
     * whatever it last was rather than clearing it, and "last died" only
     * ever changes if the player actually dies. This is presumably meant
     * as a "your eyes need a death/respawn to recover" penalty for
     * voluntarily taking a dojutsu off mid-game - but our own /prestige
     * wipe (clearReleaseItems() above) forcibly removes a player's dojutsu
     * with no death involved at all, permanently satisfying that
     * condition for anyone who hasn't happened to die recently by
     * unrelated means (which is most players grinding NXP peacefully).
     *
     * Fix: reset this tag back to 0 the instant we take a dojutsu away,
     * putting the player back in exactly the state of someone who's never
     * worn one - narutomod's own comparison (0 vs a death time that's
     * never negative) then never fires. Safe to call unconditionally even
     * when nothing removed this prestige was actually a dojutsu; a no-op
     * reset here has no downside.
     */
    private static void resetDojutsuBlindnessTracking(EntityPlayerMP player) {
        player.getEntityData().setLong(LAST_WORN_DOJUTSU_TIME_TAG, 0L);
    }

    /**
     * Revokes every release's advancement criterion from the player, the
     * exact inverse of what grantRelease() grants. Called alongside
     * clearReleaseItems() at the start of every successful /prestige, so a
     * player's advancement/achievement list matches what they actually
     * still hold - without this, "Sharingan Acquired" (say) would stay
     * marked complete forever after the first time it's earned, even once
     * the item itself has been wiped, and re-earning it on a future climb
     * wouldn't show the achievement toast again since the game already
     * considers that criterion done.
     *
     * Iterates every ReleaseDef unconditionally rather than trying to figure
     * out which ones this specific player actually holds - revoking a
     * criterion that was never granted is a harmless no-op, and several
     * ReleaseDefs intentionally share the same (advancementId, criterionId)
     * pair (e.g. both Mangekyou variants grant
     * narutomod:mangekyosharinganopened/mangekyosharinganopened), so this is
     * simpler and just as correct as tracking exactly which were granted.
     */
    private static void revokeAllReleaseAdvancements(EntityPlayerMP player) {
        MinecraftServer server = net.minecraftforge.fml.common.FMLCommonHandler.instance().getMinecraftServerInstance();
        if (server == null) return;
        for (ReleaseDef def : RELEASES.values()) {
            if (def.advancementId == null || def.criterionId == null) continue;
            net.minecraft.advancements.Advancement advancement =
                    server.getAdvancementManager().getAdvancement(new ResourceLocation(def.advancementId));
            if (advancement != null) {
                player.getAdvancements().revokeCriterion(advancement, def.criterionId);
            }
        }
    }

    /**
     * Anti-storage-exploit check: strips any release item from the player's
     * inventory/armor that isn't part of the set PrestigeReleaseData
     * recorded as their current full batch (every tier 1..N granted on
     * their last successful /prestige). Without this, a player could stash
     * a release in a chest right before running /prestige (dodging
     * clearReleaseItems, which only sees what's in their inventory at that
     * exact moment) and pull it back out afterward to keep something they
     * were no longer entitled to. Called every tick (ReleaseEnforcementHandler)
     * and immediately on login, so a stashed item gets caught the moment
     * it's back in inventory rather than only at the next /prestige.
     *
     * HEADS UP: narutomod's dojutsu are also traditionally obtainable by
     * killing another player and picking up the eye they drop - a normal,
     * intended game mechanic. This check will confiscate a legitimately
     * stolen eye too, since it only recognizes items PrestigeReleaseData
     * recorded as /prestige grants. If that mechanic matters on this
     * server, this check needs a carve-out for it (or needs to come back
     * off) - flagging this now rather than after someone loses a stolen eye.
     *
     * Public + static so the tick handler and login hook can call it without
     * needing a CommandPrestige instance.
     */
    public static void enforceReleaseOwnership(EntityPlayerMP player) {
        if (RELEASE_ITEMS_TO_CLEAR.length == 0) return;
        List<String> watched = Arrays.asList(RELEASE_ITEMS_TO_CLEAR);
        List<String> allowed = PrestigeReleaseData.get(player.world).getAllowedItemIds(player.getUniqueID());

        IInventory inv = player.inventory;
        boolean confiscatedAny = false;
        for (int i = 0; i < inv.getSizeInventory(); i++) {
            ItemStack stack = inv.getStackInSlot(i);
            if (stack.isEmpty()) continue;
            String regName = stack.getItem().getRegistryName() != null
                    ? stack.getItem().getRegistryName().toString() : "";
            if (watched.contains(regName) && !allowed.contains(regName)) {
                inv.setInventorySlotContents(i, ItemStack.EMPTY);
                confiscatedAny = true;
            }
        }

        if (confiscatedAny) {
            resetDojutsuBlindnessTracking(player);
            player.sendMessage(new TextComponentString(
                    "§c[NarutoNewGen] A release you're not currently entitled to was removed from your inventory."));
        }
    }
}

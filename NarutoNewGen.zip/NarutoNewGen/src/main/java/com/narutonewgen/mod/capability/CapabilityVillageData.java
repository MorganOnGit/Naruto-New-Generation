package com.narutonewgen.mod.capability;

import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityInject;
import net.minecraftforge.common.capabilities.CapabilityManager;

public class CapabilityVillageData {

    @CapabilityInject(IVillageData.class)
    public static Capability<IVillageData> VILLAGE_DATA_CAPABILITY = null;

    public static void register() {
        CapabilityManager.INSTANCE.register(IVillageData.class, new Capability.IStorage<IVillageData>() {
            @Override
            public NBTBase writeNBT(Capability<IVillageData> capability, IVillageData instance, EnumFacing side) {
                return instance.writeToNBT();
            }

            @Override
            public void readNBT(Capability<IVillageData> capability, IVillageData instance, EnumFacing side, NBTBase nbt) {
                instance.readFromNBT((NBTTagCompound) nbt);
            }
        }, VillageData::new);
    }
}

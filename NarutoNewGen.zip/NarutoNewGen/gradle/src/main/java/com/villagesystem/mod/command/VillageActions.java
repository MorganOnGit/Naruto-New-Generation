package com.villagesystem.mod.command;

import com.villagesystem.mod.capability.CapabilityVillageData;
import com.villagesystem.mod.capability.IVillageData;
import com.villagesystem.mod.capability.Quest;
import com.villagesystem.mod.client.gui.RosterEntry;
import com.villagesystem.mod.client.gui.VillageDisplayData;
import com.villagesystem.mod.network.MessageOpenVillageGui;
import com.villagesystem.mod.network.NetworkHandler;
import com.villagesystem.mod.worlddata.Team;
import com.villagesystem.mod.worlddata.VillageWorldData;
import com.villagesystem.mod.worlddata.VotingSession;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.fml.common.FMLCommonHandler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * All the real logic behind every /village action, shared between the chat
 * command (CommandVillage) and GUI button clicks (MessageVillageAction) so
 * both paths behave identically and there's exactly one place to fix a bug.
 */
public class VillageActions {

    private static final List<String> RANKS = Arrays.asList("genin", "chunin", "jonin");

    /** Confirmed-safe way to get the running server, rather than the unverified EntityPlayerMP.getServer(). */
    private static MinecraftServer server() {
        return FMLCommonHandler.instance().getMinecraftServerInstance();
    }

    // ---------------------------------------------------------------
    // Snapshot building / sending
    // ---------------------------------------------------------------

    public static VillageDisplayData buildDisplayData(EntityPlayerMP player) {
        MinecraftServer server = server();
        IVillageData selfData = player.getCapability(CapabilityVillageData.VILLAGE_DATA_CAPABILITY, null);
        String selfVillage = selfData.getVillage();

        VillageWorldData worldData = VillageWorldData.get(server.getEntityWorld());
        String kage = worldData.getKage(selfVillage);
        boolean isKage = player.getName().equals(kage);

        List<RosterEntry> roster = new ArrayList<>();
        for (EntityPlayerMP p : server.getPlayerList().getPlayers()) {
            IVillageData d = p.getCapability(CapabilityVillageData.VILLAGE_DATA_CAPABILITY, null);
            if (d != null && selfVillage.equals(d.getVillage())) {
                roster.add(new RosterEntry(p.getName(), d.getRank()));
            }
        }

        Map<String, String> allKages = new HashMap<>(worldData.getAllKages());
        for (String village : com.villagesystem.mod.VillageSystemMod.VILLAGES) {
            allKages.putIfAbsent(village, "");
        }

        VotingSession session = worldData.getActiveVote(selfVillage);
        boolean votingActive = session != null && !session.isExpired();
        long endTime = session != null ? session.getEndTimeMillis() : 0L;
        Map<String, Integer> tally = new HashMap<>();
        String selfVotedFor = "";
        if (session != null) {
            for (Map.Entry<String, String> vote : session.getVotes().entrySet()) {
                tally.merge(vote.getValue(), 1, Integer::sum);
                if (vote.getKey().equals(player.getName())) {
                    selfVotedFor = vote.getValue();
                }
            }
        }

        List<String> teamNames = new ArrayList<>();
        for (Team t : worldData.getAllTeams().values()) {
            if (selfVillage.equals(t.getVillage())) {
                teamNames.add(t.getName());
            }
        }

        return new VillageDisplayData(player.getName(), selfVillage, selfData.getRank(), selfData.getTeamName(),
                isKage, roster.size(), kage == null ? "" : kage, roster, selfData.getQuests(), allKages,
                votingActive, endTime, tally, selfVotedFor, teamNames);
    }

    public static void sendGuiSnapshot(EntityPlayerMP player) {
        NetworkHandler.INSTANCE.sendTo(new MessageOpenVillageGui(buildDisplayData(player)), player);
    }

    // ---------------------------------------------------------------
    // Action dispatch (shared by GUI buttons and the chat command)
    // ---------------------------------------------------------------

    public static void handleGuiAction(EntityPlayerMP player, String action, String arg1, String arg2, String arg3) {
        switch (action) {
            case "VOTE":
                vote(player, arg1);
                break;
            case "PROMOTE":
                promote(player, arg1, arg2);
                break;
            case "GIVE_QUEST":
                giveQuest(player, arg1, arg2);
                break;
            case "VERIFY_QUEST":
                verifyQuest(player, arg1);
                break;
            case "TURNIN_QUEST":
                turninQuest(player);
                break;
            case "CREATE_TEAM":
                createTeam(player, arg1, arg2, Arrays.asList(arg3.split(",")));
                break;
            case "REFRESH":
                break; // no-op, sendGuiSnapshot below covers it
            default:
                player.sendMessage(new TextComponentString("Unknown village action: " + action));
                return;
        }
        sendGuiSnapshot(player);
    }

    private static IVillageData dataOf(EntityPlayerMP player) {
        return player.getCapability(CapabilityVillageData.VILLAGE_DATA_CAPABILITY, null);
    }

    private static boolean isKageOf(EntityPlayerMP player, String village) {
        VillageWorldData worldData = VillageWorldData.get(server().getEntityWorld());
        return player.getName().equals(worldData.getKage(village));
    }

    private static EntityPlayerMP findOnline(MinecraftServer server, String name) {
        return server.getPlayerList().getPlayerByUsername(name);
    }

    public static void vote(EntityPlayerMP player, String candidateName) {
        IVillageData selfData = dataOf(player);
        String village = selfData.getVillage();
        VillageWorldData worldData = VillageWorldData.get(server().getEntityWorld());
        VotingSession session = worldData.getActiveVote(village);
        if (session == null || session.isExpired()) {
            player.sendMessage(new TextComponentString("There's no active Kage vote for your village right now."));
            return;
        }
        EntityPlayerMP candidate = findOnline(server(), candidateName);
        if (candidate == null || !village.equals(dataOf(candidate) != null ? dataOf(candidate).getVillage() : null)) {
            player.sendMessage(new TextComponentString(candidateName + " isn't an online member of your village."));
            return;
        }
        session.castVote(player.getName(), candidateName);
        worldData.markVotesDirty();
        player.sendMessage(new TextComponentString("Voted for " + candidateName + " for Kage."));
    }

    public static void promote(EntityPlayerMP kage, String targetName, String newRank) {
        String village = dataOf(kage).getVillage();
        if (!isKageOf(kage, village)) {
            kage.sendMessage(new TextComponentString("Only your village's Kage can promote players."));
            return;
        }
        if (!RANKS.contains(newRank)) {
            kage.sendMessage(new TextComponentString("Rank must be genin, chunin, or jonin."));
            return;
        }
        EntityPlayerMP target = findOnline(server(), targetName);
        if (target == null || !village.equals(dataOf(target).getVillage())) {
            kage.sendMessage(new TextComponentString(targetName + " isn't an online member of your village."));
            return;
        }
        dataOf(target).setRank(newRank);
        kage.sendMessage(new TextComponentString("Set " + targetName + "'s rank to " + newRank + "."));
        target.sendMessage(new TextComponentString("\u00A76Your rank was set to " + newRank + " by your Kage."));
    }

    public static void giveQuest(EntityPlayerMP kage, String targetName, String questText) {
        String village = dataOf(kage).getVillage();
        if (!isKageOf(kage, village)) {
            kage.sendMessage(new TextComponentString("Only your village's Kage can assign quests."));
            return;
        }
        EntityPlayerMP target = findOnline(server(), targetName);
        if (target == null || !village.equals(dataOf(target).getVillage())) {
            kage.sendMessage(new TextComponentString(targetName + " isn't an online member of your village."));
            return;
        }
        if (questText == null || questText.trim().isEmpty()) {
            kage.sendMessage(new TextComponentString("Quest text can't be empty."));
            return;
        }
        dataOf(target).addQuest(new Quest(questText, kage.getName(), Quest.Status.IN_PROGRESS));
        kage.sendMessage(new TextComponentString("Gave " + targetName + " a quest."));
        target.sendMessage(new TextComponentString("\u00A76New quest from your Kage: " + questText));
    }

    public static void verifyQuest(EntityPlayerMP kage, String targetName) {
        String village = dataOf(kage).getVillage();
        if (!isKageOf(kage, village)) {
            kage.sendMessage(new TextComponentString("Only your village's Kage can verify quests."));
            return;
        }
        EntityPlayerMP target = findOnline(server(), targetName);
        if (target == null || !village.equals(dataOf(target).getVillage())) {
            kage.sendMessage(new TextComponentString(targetName + " isn't an online member of your village."));
            return;
        }
        Quest quest = dataOf(target).getLatestQuest();
        if (quest == null || quest.getStatus() != Quest.Status.PENDING_VERIFICATION) {
            kage.sendMessage(new TextComponentString(targetName + " has no quest awaiting verification."));
            return;
        }
        quest.setStatus(Quest.Status.COMPLETE);
        kage.sendMessage(new TextComponentString("Verified " + targetName + "'s quest."));
        target.sendMessage(new TextComponentString("\u00A76Your Kage verified your quest as complete!"));
    }

    public static void turninQuest(EntityPlayerMP player) {
        Quest quest = dataOf(player).getLatestQuest();
        if (quest == null || quest.getStatus() != Quest.Status.IN_PROGRESS) {
            player.sendMessage(new TextComponentString("You don't have an in-progress quest to turn in."));
            return;
        }
        quest.setStatus(Quest.Status.PENDING_VERIFICATION);
        player.sendMessage(new TextComponentString("Quest turned in. Waiting on your Kage to verify it."));
    }

    public static void createTeam(EntityPlayerMP kage, String teamName, String joninLeaderName, List<String> members) {
        String village = dataOf(kage).getVillage();
        if (!isKageOf(kage, village)) {
            kage.sendMessage(new TextComponentString("Only your village's Kage can create teams."));
            return;
        }
        if (teamName == null || teamName.trim().isEmpty()) {
            kage.sendMessage(new TextComponentString("Team name can't be empty."));
            return;
        }
        VillageWorldData worldData = VillageWorldData.get(server().getEntityWorld());
        if (worldData.getTeam(teamName) != null) {
            kage.sendMessage(new TextComponentString("A team named '" + teamName + "' already exists."));
            return;
        }
        EntityPlayerMP leader = findOnline(server(), joninLeaderName);
        if (leader == null || !village.equals(dataOf(leader).getVillage()) || !"jonin".equals(dataOf(leader).getRank())) {
            kage.sendMessage(new TextComponentString(joninLeaderName + " must be an online Jonin in your village."));
            return;
        }
        List<String> cleanMembers = new ArrayList<>();
        for (String m : members) {
            String trimmed = m.trim();
            if (trimmed.isEmpty()) continue;
            EntityPlayerMP member = findOnline(server(), trimmed);
            if (member == null || !village.equals(dataOf(member).getVillage())) {
                kage.sendMessage(new TextComponentString(trimmed + " isn't an online member of your village - skipped."));
                continue;
            }
            cleanMembers.add(trimmed);
        }
        if (cleanMembers.size() > 3) {
            kage.sendMessage(new TextComponentString("A team can have at most 3 members plus the Jonin leader."));
            return;
        }

        worldData.addTeam(new Team(teamName, village, joninLeaderName, cleanMembers));
        dataOf(leader).setTeamName(teamName);
        leader.sendMessage(new TextComponentString("\u00A76You're now leading team '" + teamName + "'."));
        for (String m : cleanMembers) {
            EntityPlayerMP member = findOnline(server(), m);
            dataOf(member).setTeamName(teamName);
            member.sendMessage(new TextComponentString("\u00A76You've been added to team '" + teamName + "'."));
        }
        kage.sendMessage(new TextComponentString("Created team '" + teamName + "'."));
    }
}

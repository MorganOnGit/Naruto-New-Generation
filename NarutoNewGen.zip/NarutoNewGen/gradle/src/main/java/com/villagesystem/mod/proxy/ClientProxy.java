package com.villagesystem.mod.proxy;

import com.villagesystem.mod.client.gui.GuiVillage;
import com.villagesystem.mod.client.gui.VillageDisplayData;
import net.minecraft.client.Minecraft;

public class ClientProxy extends CommonProxy {

    @Override
    public void preInit() {
        super.preInit();
    }

    @Override
    public void openVillageGui(VillageDisplayData data) {
        Minecraft.getMinecraft().addScheduledTask(() -> {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.currentScreen instanceof GuiVillage) {
                // A refresh after a GUI action - update in place so the
                // player doesn't get bounced back to page 1.
                ((GuiVillage) mc.currentScreen).updateData(data);
            } else {
                mc.displayGuiScreen(new GuiVillage(data));
            }
        });
    }
}

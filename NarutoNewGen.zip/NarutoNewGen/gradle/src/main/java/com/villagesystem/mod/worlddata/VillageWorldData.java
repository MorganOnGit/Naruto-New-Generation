package com.villagesystem.mod.worlddata;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.world.World;
import net.minecraft.world.storage.WorldSavedData;
import net.minecraft.world.storage.MapStorage;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Server-wide village state: who's Kage of each village, all teams, and any
 * currently-active Kage votes. Stored in the overworld's map data, same
 * mechanism vanilla uses for things like villages.dat.
 */
public class VillageWorldData extends WorldSavedData {

    private static final String DATA_NAME = "villagesystem_data";

    private final Map<String, String> kageOf = new HashMap<>();
    private final Map<String, Team> teams = new LinkedHashMap<>();
    private final Map<String, VotingSession> activeVotes = new HashMap<>();

    public VillageWorldData(String name) {
        super(name);
    }

    public static VillageWorldData get(World world) {
        MapStorage storage = world.getPerWorldStorage();
        VillageWorldData data = (VillageWorldData) storage.getOrLoadData(VillageWorldData.class, DATA_NAME);
        if (data == null) {
            data = new VillageWorldData(DATA_NAME);
            storage.setData(DATA_NAME, data);
        }
        return data;
    }

    public String getKage(String village) { return kageOf.get(village); }

    public void setKage(String village, String playerName) {
        kageOf.put(village, playerName);
        markDirty();
    }

    public Map<String, String> getAllKages() { return kageOf; }

    public void addTeam(Team team) {
        teams.put(team.getName(), team);
        markDirty();
    }

    public Team getTeam(String name) { return teams.get(name); }
    public Map<String, Team> getAllTeams() { return teams; }

    public VotingSession getActiveVote(String village) { return activeVotes.get(village); }

    public void startVote(String village, long endTimeMillis) {
        activeVotes.put(village, new VotingSession(endTimeMillis));
        markDirty();
    }

    public void endVote(String village) {
        activeVotes.remove(village);
        markDirty();
    }

    public void markVotesDirty() { markDirty(); }

    @Override
    public void readFromNBT(NBTTagCompound nbt) {
        kageOf.clear();
        NBTTagList kageList = nbt.getTagList("kageOf", 10); // TAG_COMPOUND
        for (int i = 0; i < kageList.tagCount(); i++) {
            NBTTagCompound entry = kageList.getCompoundTagAt(i);
            kageOf.put(entry.getString("village"), entry.getString("player"));
        }

        teams.clear();
        NBTTagList teamList = nbt.getTagList("teams", 10);
        for (int i = 0; i < teamList.tagCount(); i++) {
            Team team = Team.readFromNBT(teamList.getCompoundTagAt(i));
            teams.put(team.getName(), team);
        }

        activeVotes.clear();
        NBTTagList voteList = nbt.getTagList("activeVotes", 10);
        for (int i = 0; i < voteList.tagCount(); i++) {
            NBTTagCompound entry = voteList.getCompoundTagAt(i);
            activeVotes.put(entry.getString("village"), VotingSession.readFromNBT(entry.getCompoundTag("session")));
        }
    }

    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound compound) {
        NBTTagList kageList = new NBTTagList();
        for (Map.Entry<String, String> entry : kageOf.entrySet()) {
            NBTTagCompound tag = new NBTTagCompound();
            tag.setString("village", entry.getKey());
            tag.setString("player", entry.getValue());
            kageList.appendTag(tag);
        }
        compound.setTag("kageOf", kageList);

        NBTTagList teamList = new NBTTagList();
        for (Team team : teams.values()) {
            teamList.appendTag(team.writeToNBT());
        }
        compound.setTag("teams", teamList);

        NBTTagList voteList = new NBTTagList();
        for (Map.Entry<String, VotingSession> entry : activeVotes.entrySet()) {
            NBTTagCompound tag = new NBTTagCompound();
            tag.setString("village", entry.getKey());
            tag.setTag("session", entry.getValue().writeToNBT());
            voteList.appendTag(tag);
        }
        compound.setTag("activeVotes", voteList);

        return compound;
    }
}

package com.villagesystem.mod.client.gui;

import com.villagesystem.mod.capability.Quest;
import com.villagesystem.mod.network.MessageVillageAction;
import com.villagesystem.mod.network.NetworkHandler;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

@SideOnly(Side.CLIENT)
public class GuiVillage extends GuiScreen {

    private static final ResourceLocation TEXTURE =
            new ResourceLocation("villagesystem", "textures/gui/scroll.png");
    private static final int TEX_W = 512, TEX_H = 384;
    private static final int PAGE_COUNT = 8;
    private static final String[] PAGE_TITLES = {
            "Village Overview", "Village Roster", "Your Quests", "Kage Vote",
            "Other Villages", "Promotions (Kage)", "Assign Quest (Kage)", "Create Team (Kage)"
    };

    private VillageDisplayData data;
    private int page = 0;

    private GuiTextField questTextField;
    private GuiTextField teamNameTextField;
    private String selectedJoninLeader = "";
    private final Set<String> selectedMembers = new LinkedHashSet<>();

    private final Map<Integer, Runnable> buttonActions = new HashMap<>();
    private int nextButtonId;

    public GuiVillage(VillageDisplayData data) {
        this.data = data;
    }

    /** Called by the network handler when a fresh snapshot arrives after an action. */
    public void updateData(VillageDisplayData newData) {
        this.data = newData;
        rebuildPageWidgets();
    }

    @Override
    public void initGui() {
        super.initGui();
        rebuildPageWidgets();
    }

    private int left() { return (this.width - TEX_W) / 2; }
    private int top() { return (this.height - TEX_H) / 2; }

    private void rebuildPageWidgets() {
        this.buttonList.clear();
        buttonActions.clear();
        nextButtonId = 100;
        questTextField = null;
        teamNameTextField = null;

        int left = left();
        int top = top();

        addButton(1, left + 20, top + TEX_H - 26, 20, 16, "<", () -> changePage(-1));
        addButton(2, left + TEX_W - 40, top + TEX_H - 26, 20, 16, ">", () -> changePage(1));

        int contentLeft = left + 34;
        int contentTop = top + 60;
        int rowHeight = 16;

        switch (page) {
            case 0:
            case 1:
            case 4:
                break; // read-only pages, no widgets needed
            case 2: {
                Quest latest = data.quests.isEmpty() ? null : data.quests.get(data.quests.size() - 1);
                if (latest != null && latest.getStatus() == Quest.Status.IN_PROGRESS) {
                    addButton(nextButtonId++, contentLeft, top + TEX_H - 60, 110, 16, "Turn In Quest",
                            () -> sendAction("TURNIN_QUEST", "", "", ""));
                }
                break;
            }
            case 3: {
                if (data.votingActive) {
                    int y = contentTop + 20;
                    for (RosterEntry r : data.roster) {
                        final String name = r.playerName;
                        String label = name.equals(data.selfVotedFor) ? "Voted" : "Vote";
                        addButton(nextButtonId++, contentLeft + 160, y, 60, 14, label,
                                () -> sendAction("VOTE", name, "", ""));
                        y += rowHeight;
                    }
                }
                break;
            }
            case 5: {
                if (data.selfIsKage) {
                    int y = contentTop;
                    for (RosterEntry r : data.roster) {
                        final String name = r.playerName;
                        addButton(nextButtonId++, contentLeft + 160, y, 26, 14, "G",
                                () -> sendAction("PROMOTE", name, "genin", ""));
                        addButton(nextButtonId++, contentLeft + 190, y, 26, 14, "C",
                                () -> sendAction("PROMOTE", name, "chunin", ""));
                        addButton(nextButtonId++, contentLeft + 224, y, 26, 14, "J",
                                () -> sendAction("PROMOTE", name, "jonin", ""));
                        y += rowHeight;
                    }
                } else {
                    addButton(nextButtonId++, contentLeft, contentTop, 200, 16, "Kage-only page", null);
                    disableLast();
                }
                break;
            }
            case 6: {
                if (data.selfIsKage) {
                    questTextField = new GuiTextField(50, this.fontRenderer, contentLeft, contentTop - 20, 300, 16);
                    questTextField.setMaxStringLength(256);
                    questTextField.setText("Type a quest here...");
                    int y = contentTop + 6;
                    for (RosterEntry r : data.roster) {
                        final String name = r.playerName;
                        addButton(nextButtonId++, contentLeft + 160, y, 60, 14, "Give",
                                () -> sendAction("GIVE_QUEST", name, questTextField.getText(), ""));
                        addButton(nextButtonId++, contentLeft + 225, y, 60, 14, "Verify",
                                () -> sendAction("VERIFY_QUEST", name, "", ""));
                        y += rowHeight;
                    }
                } else {
                    addButton(nextButtonId++, contentLeft, contentTop, 200, 16, "Kage-only page", null);
                    disableLast();
                }
                break;
            }
            case 7: {
                if (data.selfIsKage) {
                    teamNameTextField = new GuiTextField(51, this.fontRenderer, contentLeft, contentTop - 20, 200, 16);
                    teamNameTextField.setMaxStringLength(32);
                    teamNameTextField.setText("Team name...");
                    int y = contentTop + 6;
                    for (RosterEntry r : data.roster) {
                        final String name = r.playerName;
                        final String rank = r.rank;
                        String label = name.equals(selectedJoninLeader) ? "Leader"
                                : selectedMembers.contains(name) ? "Selected" : "Select";
                        addButton(nextButtonId++, contentLeft + 160, y, 80, 14, label,
                                () -> toggleTeamSelection(name, rank));
                        y += rowHeight;
                    }
                    addButton(nextButtonId++, contentLeft, top + TEX_H - 60, 110, 16, "Create Team",
                            this::submitCreateTeam);
                } else {
                    addButton(nextButtonId++, contentLeft, contentTop, 200, 16, "Kage-only page", null);
                    disableLast();
                }
                break;
            }
        }
    }

    private void disableLast() {
        this.buttonList.get(this.buttonList.size() - 1).enabled = false;
    }

    private void addButton(int id, int x, int y, int w, int h, String label, Runnable onClick) {
        this.buttonList.add(new GuiButton(id, x, y, w, h, label));
        if (onClick != null) buttonActions.put(id, onClick);
    }

    private void changePage(int delta) {
        int newPage = page + delta;
        if (newPage >= 0 && newPage < PAGE_COUNT) {
            page = newPage;
            rebuildPageWidgets();
        }
    }

    private void toggleTeamSelection(String name, String rank) {
        if ("jonin".equals(rank)) {
            selectedJoninLeader = name.equals(selectedJoninLeader) ? "" : name;
        } else if (selectedMembers.contains(name)) {
            selectedMembers.remove(name);
        } else if (selectedMembers.size() < 3) {
            selectedMembers.add(name);
        }
        rebuildPageWidgets();
    }

    private void submitCreateTeam() {
        String teamName = teamNameTextField != null ? teamNameTextField.getText() : "";
        String members = String.join(",", selectedMembers);
        sendAction("CREATE_TEAM", teamName, selectedJoninLeader, members);
        selectedJoninLeader = "";
        selectedMembers.clear();
    }

    private void sendAction(String action, String arg1, String arg2, String arg3) {
        NetworkHandler.INSTANCE.sendToServer(new MessageVillageAction(action, arg1, arg2, arg3));
    }

    @Override
    protected void actionPerformed(GuiButton button) {
        Runnable action = buttonActions.get(button.id);
        if (action != null) action.run();
    }

    @Override
    public void updateScreen() {
        if (questTextField != null) questTextField.updateCursorCounter();
        if (teamNameTextField != null) teamNameTextField.updateCursorCounter();
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        if (questTextField != null) questTextField.mouseClicked(mouseX, mouseY, mouseButton);
        if (teamNameTextField != null) teamNameTextField.mouseClicked(mouseX, mouseY, mouseButton);
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (questTextField != null && questTextField.isFocused()) {
            questTextField.textboxKeyTyped(typedChar, keyCode);
            return;
        }
        if (teamNameTextField != null && teamNameTextField.isFocused()) {
            teamNameTextField.textboxKeyTyped(typedChar, keyCode);
            return;
        }
        super.keyTyped(typedChar, keyCode);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();

        int left = left();
        int top = top();

        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        this.mc.getTextureManager().bindTexture(TEXTURE);
        drawTexturedModalRect(left, top, 0, 0, TEX_W, TEX_H);

        int centerX = left + TEX_W / 2;
        drawCenteredString(this.fontRenderer, TextFormatting.BOLD + PAGE_TITLES[page], centerX, top + 16, 0x3B2A17);
        drawCenteredString(this.fontRenderer, "Page " + (page + 1) + " / " + PAGE_COUNT, centerX, top + TEX_H - 22, 0x3B2A17);

        int contentLeft = left + 34;
        int contentTop = top + 40;

        switch (page) {
            case 0: drawOverviewPage(contentLeft, contentTop); break;
            case 1: drawRosterPage(contentLeft, contentTop, false); break;
            case 2: drawQuestsPage(contentLeft, contentTop); break;
            case 3: drawVotingPage(contentLeft, contentTop); break;
            case 4: drawOtherVillagesPage(contentLeft, contentTop); break;
            case 5: drawRosterPage(contentLeft, contentTop, true); break;
            case 6: drawGiveQuestPage(contentLeft, contentTop); break;
            case 7: drawTeamPage(contentLeft, contentTop); break;
        }

        if (questTextField != null) questTextField.drawTextBox();
        if (teamNameTextField != null) teamNameTextField.drawTextBox();

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    private void drawOverviewPage(int x, int y) {
        int lineHeight = 14;
        drawField(x, y, "Village", capitalize(data.selfVillage)); y += lineHeight;
        drawField(x, y, "Members Online", String.valueOf(data.villageMemberCount)); y += lineHeight;
        drawField(x, y, "Current Kage", data.villageKageName.isEmpty() ? "None" : data.villageKageName); y += lineHeight;
        drawField(x, y, "Your Team", data.selfTeamName.isEmpty() ? "None" : data.selfTeamName); y += lineHeight;
        drawField(x, y, "Your Rank", capitalize(data.selfRank));
    }

    private void drawRosterPage(int x, int y, boolean withPromotionColumns) {
        this.fontRenderer.drawString(TextFormatting.UNDERLINE + "Player", x, y, 0x3B2A17);
        this.fontRenderer.drawString(TextFormatting.UNDERLINE + "Rank", x + 100, y, 0x3B2A17);
        y += 16;
        for (RosterEntry r : data.roster) {
            this.fontRenderer.drawString(r.playerName, x, y, 0x2A1E10);
            this.fontRenderer.drawString(capitalize(r.rank), x + 100, y, 0x2A1E10);
            y += 16;
        }
        if (withPromotionColumns && !data.selfIsKage) {
            this.fontRenderer.drawString(TextFormatting.ITALIC + "Only your village's Kage can promote players.",
                    x, y + 10, 0x8A2A1A);
        }
    }

    private void drawQuestsPage(int x, int y) {
        drawField(x, y, "Your Rank", capitalize(data.selfRank));
        y += 20;
        this.fontRenderer.drawString(TextFormatting.UNDERLINE + "Current Quests", x, y, 0x3B2A17);
        y += 16;
        if (data.quests.isEmpty()) {
            this.fontRenderer.drawString("No quests assigned.", x + 4, y, 0x5C4A2E);
            return;
        }
        for (Quest q : data.quests) {
            String status;
            int color;
            switch (q.getStatus()) {
                case COMPLETE: status = "[Complete]"; color = 0x2E6B1F; break;
                case PENDING_VERIFICATION: status = "[Pending]"; color = 0x8A6D1A; break;
                default: status = "[In Progress]"; color = 0x5C4A2E;
            }
            for (String wrapped : this.fontRenderer.listFormattedStringToWidth(q.getDescription(), 420)) {
                this.fontRenderer.drawString(wrapped, x + 4, y, 0x2A1E10);
                y += 14;
            }
            this.fontRenderer.drawString(status + " from " + q.getAssignedBy(), x + 8, y, color);
            y += 18;
        }
    }

    private void drawVotingPage(int x, int y) {
        if (!data.votingActive) {
            this.fontRenderer.drawString("No active Kage vote for your village right now.", x, y, 0x5C4A2E);
            return;
        }
        long remainingMs = data.votingEndTimeMillis - System.currentTimeMillis();
        long minutes = Math.max(0, remainingMs / 60000);
        this.fontRenderer.drawString("Voting ends in about " + minutes + " minute(s).", x, y, 0x2A1E10);
        y += 20;
        this.fontRenderer.drawString(TextFormatting.UNDERLINE + "Candidate", x, y, 0x3B2A17);
        this.fontRenderer.drawString(TextFormatting.UNDERLINE + "Votes", x + 100, y, 0x3B2A17);
        y += 16;
        for (RosterEntry r : data.roster) {
            this.fontRenderer.drawString(r.playerName, x, y, 0x2A1E10);
            int votes = data.voteTally.getOrDefault(r.playerName, 0);
            this.fontRenderer.drawString(String.valueOf(votes), x + 100, y, 0x2A1E10);
            y += 16;
        }
    }

    private void drawOtherVillagesPage(int x, int y) {
        this.fontRenderer.drawString(TextFormatting.UNDERLINE + "Village", x, y, 0x3B2A17);
        this.fontRenderer.drawString(TextFormatting.UNDERLINE + "Kage", x + 100, y, 0x3B2A17);
        y += 16;
        for (Map.Entry<String, String> entry : data.allKages.entrySet()) {
            if (entry.getKey().equals(data.selfVillage)) continue;
            this.fontRenderer.drawString(capitalize(entry.getKey()), x, y, 0x2A1E10);
            String kage = entry.getValue();
            this.fontRenderer.drawString(kage.isEmpty() ? "None" : kage, x + 100, y, 0x2A1E10);
            y += 16;
        }
    }

    private void drawGiveQuestPage(int x, int y) {
        if (!data.selfIsKage) {
            this.fontRenderer.drawString(TextFormatting.ITALIC + "Only your village's Kage can assign quests.", x, y, 0x8A2A1A);
            return;
        }
        this.fontRenderer.drawString("Quest text:", x, y - 12, 0x2A1E10);
        y += 26;
        for (RosterEntry r : data.roster) {
            this.fontRenderer.drawString(r.playerName, x, y, 0x2A1E10);
            y += 16;
        }
    }

    private void drawTeamPage(int x, int y) {
        if (!data.selfIsKage) {
            this.fontRenderer.drawString(TextFormatting.ITALIC + "Only your village's Kage can create teams.", x, y, 0x8A2A1A);
            return;
        }
        this.fontRenderer.drawString("Team name:", x, y - 12, 0x2A1E10);
        y += 26;
        for (RosterEntry r : data.roster) {
            this.fontRenderer.drawString(r.playerName + " (" + capitalize(r.rank) + ")", x, y, 0x2A1E10);
            y += 16;
        }
        y += 6;
        if (!data.teamNamesInVillage.isEmpty()) {
            this.fontRenderer.drawString("Existing teams: " + String.join(", ", data.teamNamesInVillage), x, y, 0x5C4A2E);
        }
    }

    private void drawField(int x, int y, String label, String value) {
        String line = TextFormatting.BOLD + label + ": " + TextFormatting.RESET + value;
        this.fontRenderer.drawString(line, x, y, 0x2A1E10);
    }

    private String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}

package com.villagesystem.mod.capability;

import net.minecraft.nbt.NBTTagCompound;

import java.util.List;

public interface IVillageData {

    String getVillage();
    void setVillage(String village);

    // "genin", "chunin", or "jonin". Kage status is NOT stored here - it's
    // derived from VillageWorldData (whoever the village's current Kage is),
    // so there's exactly one source of truth for who's Kage.
    String getRank();
    void setRank(String rank);

    String getTeamName();
    void setTeamName(String teamName);

    List<Quest> getQuests();
    void addQuest(Quest quest);
    boolean removeQuest(int index);
    Quest getLatestQuest();
    void clearQuests();

    NBTTagCompound writeToNBT();
    void readFromNBT(NBTTagCompound nbt);
}

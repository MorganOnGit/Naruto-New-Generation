package com.villagesystem.mod.capability;

import com.villagesystem.mod.VillageSystemMod;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.Random;

public class PlayerEventHandler {

    public static final ResourceLocation VILLAGE_DATA_ID =
            new ResourceLocation(VillageSystemMod.MODID, "village_data");

    private static final Random RANDOM = new Random();

    @SubscribeEvent
    public void attachCapability(AttachCapabilitiesEvent<Entity> event) {
        if (event.getObject() instanceof EntityPlayer) {
            event.addCapability(VILLAGE_DATA_ID, new VillageDataProvider());
        }
    }

    @SubscribeEvent
    public void onPlayerClone(PlayerEvent.Clone event) {
        IVillageData oldData = event.getOriginal().getCapability(CapabilityVillageData.VILLAGE_DATA_CAPABILITY, null);
        IVillageData newData = event.getEntityPlayer().getCapability(CapabilityVillageData.VILLAGE_DATA_CAPABILITY, null);
        if (oldData != null && newData != null) {
            newData.readFromNBT(oldData.writeToNBT());
        }
    }

    // Auto-assign a random village the first time a player ever logs in.
    @SubscribeEvent
    public void onPlayerLoggedIn(net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.player instanceof EntityPlayerMP)) return;
        EntityPlayerMP player = (EntityPlayerMP) event.player;
        IVillageData data = player.getCapability(CapabilityVillageData.VILLAGE_DATA_CAPABILITY, null);
        if (data == null || !data.getVillage().isEmpty()) return; // already assigned

        String village = VillageSystemMod.VILLAGES[RANDOM.nextInt(VillageSystemMod.VILLAGES.length)];
        data.setVillage(village);

        // Grant the matching FTBUtilities rank (ranks named exactly "rain",
        // "cloud", etc. must already exist - see one_time_setup_commands.txt).
        net.minecraft.server.MinecraftServer server =
                net.minecraftforge.fml.common.FMLCommonHandler.instance().getMinecraftServerInstance();
        server.getCommandManager().executeCommand(server, "rank add " + player.getName() + " " + village);

        player.sendMessage(new net.minecraft.util.text.TextComponentString(
                "\u00A76You have been assigned to the " + village.substring(0, 1).toUpperCase()
                        + village.substring(1) + " Village!"));
    }
}

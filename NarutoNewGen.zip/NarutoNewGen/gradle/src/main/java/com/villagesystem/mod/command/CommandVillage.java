package com.villagesystem.mod.command;

import com.villagesystem.mod.VillageSystemMod;
import com.villagesystem.mod.capability.CapabilityVillageData;
import com.villagesystem.mod.capability.IVillageData;
import com.villagesystem.mod.worlddata.VillageWorldData;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;

import java.util.Arrays;
import java.util.List;

public class CommandVillage extends CommandBase {

    @Override
    public String getName() {
        return "village";
    }

    @Override
    public String getUsage(ICommandSender sender) {
        return "/village open | /village assignvillage <player> <village> | /village kage startvote <village> <minutes> "
                + "| /village kage vote <candidate> | /village setrank <player> <genin|chunin|jonin> "
                + "| /village quest give <player> <text> | /village quest verify <player> | /village quest turnin "
                + "| /village team create <teamName> <joninLeader> <member1> [member2] [member3]";
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 0; // sub-actions check their own permissions
    }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (args.length == 0) throw new WrongUsageException(getUsage(sender));

        switch (args[0].toLowerCase()) {
            case "open":
                VillageActions.sendGuiSnapshot(requireSelf(sender));
                break;
            case "assignvillage":
                assignVillage(server, sender, args);
                break;
            case "kage":
                handleKage(server, sender, args);
                break;
            case "setrank":
                if (args.length < 3) throw new WrongUsageException("/village setrank <player> <genin|chunin|jonin>");
                VillageActions.promote(requireSelf(sender), args[1], args[2].toLowerCase());
                break;
            case "quest":
                handleQuest(server, sender, args);
                break;
            case "team":
                handleTeam(server, sender, args);
                break;
            default:
                throw new WrongUsageException(getUsage(sender));
        }
    }

    private void assignVillage(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        requireOp(sender);
        if (args.length < 3) throw new WrongUsageException("/village assignvillage <player> <village>");
        String village = args[2].toLowerCase();
        if (!Arrays.asList(VillageSystemMod.VILLAGES).contains(village)) {
            throw new CommandException("Village must be one of: " + Arrays.toString(VillageSystemMod.VILLAGES));
        }
        EntityPlayerMP target = getPlayer(server, sender, args[1]);
        IVillageData data = target.getCapability(CapabilityVillageData.VILLAGE_DATA_CAPABILITY, null);
        data.setVillage(village);
        server.getCommandManager().executeCommand(server, "rank add " + target.getName() + " " + village);
        sender.sendMessage(new TextComponentString("Set " + target.getName() + "'s village to " + village + "."));
    }

    private void handleKage(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (args.length < 2) throw new WrongUsageException(getUsage(sender));
        switch (args[1].toLowerCase()) {
            case "startvote": {
                requireOp(sender);
                if (args.length < 4) throw new WrongUsageException("/village kage startvote <village> <minutes>");
                String village = args[2].toLowerCase();
                if (!Arrays.asList(VillageSystemMod.VILLAGES).contains(village)) {
                    throw new CommandException("Village must be one of: " + Arrays.toString(VillageSystemMod.VILLAGES));
                }
                int minutes = parseInt(args[3], 1, 1440);
                long endTime = System.currentTimeMillis() + minutes * 60_000L;
                VillageWorldData.get(server.getEntityWorld()).startVote(village, endTime);
                sender.sendMessage(new TextComponentString("Started a " + minutes + "-minute Kage vote for " + village + "."));
                break;
            }
            case "vote": {
                if (args.length < 3) throw new WrongUsageException("/village kage vote <candidate>");
                VillageActions.vote(requireSelf(sender), args[2]);
                break;
            }
            default:
                throw new WrongUsageException(getUsage(sender));
        }
    }

    private void handleQuest(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (args.length < 2) throw new WrongUsageException(getUsage(sender));
        switch (args[1].toLowerCase()) {
            case "give": {
                if (args.length < 4) throw new WrongUsageException("/village quest give <player> <text>");
                VillageActions.giveQuest(requireSelf(sender), args[2], joinFrom(args, 3));
                break;
            }
            case "verify": {
                if (args.length < 3) throw new WrongUsageException("/village quest verify <player>");
                VillageActions.verifyQuest(requireSelf(sender), args[2]);
                break;
            }
            case "turnin":
                VillageActions.turninQuest(requireSelf(sender));
                break;
            default:
                throw new WrongUsageException(getUsage(sender));
        }
    }

    private void handleTeam(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (args.length < 2 || !args[1].equalsIgnoreCase("create")) throw new WrongUsageException(getUsage(sender));
        if (args.length < 4) throw new WrongUsageException("/village team create <teamName> <joninLeader> <member1> [member2] [member3]");
        String teamName = args[2];
        String joninLeader = args[3];
        List<String> members = Arrays.asList(args).subList(4, args.length);
        VillageActions.createTeam(requireSelf(sender), teamName, joninLeader, members);
    }

    private EntityPlayerMP requireSelf(ICommandSender sender) throws CommandException {
        if (!(sender.getCommandSenderEntity() instanceof EntityPlayerMP)) {
            throw new CommandException("This command must be run by a player.");
        }
        return (EntityPlayerMP) sender.getCommandSenderEntity();
    }

    private void requireOp(ICommandSender sender) throws CommandException {
        if (!sender.canUseCommand(2, "village")) {
            throw new CommandException("You do not have permission to do that.");
        }
    }

    private String joinFrom(String[] args, int startIndex) {
        StringBuilder sb = new StringBuilder();
        for (int i = startIndex; i < args.length; i++) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(args[i]);
        }
        return sb.toString();
    }

    @Override
    public List<String> getTabCompletions(MinecraftServer server, ICommandSender sender, String[] args, BlockPos targetPos) {
        if (args.length == 1) {
            return getListOfStringsMatchingLastWord(args, "open", "assignvillage", "kage", "setrank", "quest", "team");
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("assignvillage")) {
            return getListOfStringsMatchingLastWord(args, server.getPlayerList().getOnlinePlayerNames());
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("assignvillage")) {
            return getListOfStringsMatchingLastWord(args, VillageSystemMod.VILLAGES);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("kage")) {
            return getListOfStringsMatchingLastWord(args, "startvote", "vote");
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("kage") && args[1].equalsIgnoreCase("startvote")) {
            return getListOfStringsMatchingLastWord(args, VillageSystemMod.VILLAGES);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("setrank")) {
            return getListOfStringsMatchingLastWord(args, server.getPlayerList().getOnlinePlayerNames());
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("setrank")) {
            return getListOfStringsMatchingLastWord(args, "genin", "chunin", "jonin");
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("quest")) {
            return getListOfStringsMatchingLastWord(args, "give", "verify", "turnin");
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("team")) {
            return getListOfStringsMatchingLastWord(args, "create");
        }
        return super.getTabCompletions(server, sender, args, targetPos);
    }
}

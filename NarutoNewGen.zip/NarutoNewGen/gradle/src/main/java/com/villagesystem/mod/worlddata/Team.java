package com.villagesystem.mod.worlddata;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagString;

import java.util.ArrayList;
import java.util.List;

/** A named team: a Jonin leader plus up to 3 other members, all from the same village. */
public class Team {
    private String name;
    private String village;
    private String joninLeader;
    private List<String> members = new ArrayList<>();

    public Team() {
    }

    public Team(String name, String village, String joninLeader, List<String> members) {
        this.name = name;
        this.village = village;
        this.joninLeader = joninLeader;
        this.members = members;
    }

    public String getName() { return name; }
    public String getVillage() { return village; }
    public String getJoninLeader() { return joninLeader; }
    public List<String> getMembers() { return members; }

    public NBTTagCompound writeToNBT() {
        NBTTagCompound tag = new NBTTagCompound();
        tag.setString("name", name);
        tag.setString("village", village);
        tag.setString("joninLeader", joninLeader);
        NBTTagList memberList = new NBTTagList();
        for (String m : members) {
            memberList.appendTag(new NBTTagString(m));
        }
        tag.setTag("members", memberList);
        return tag;
    }

    public static Team readFromNBT(NBTTagCompound tag) {
        Team team = new Team();
        team.name = tag.getString("name");
        team.village = tag.getString("village");
        team.joninLeader = tag.getString("joninLeader");
        team.members = new ArrayList<>();
        NBTTagList memberList = tag.getTagList("members", 8); // TAG_STRING
        for (int i = 0; i < memberList.tagCount(); i++) {
            team.members.add(memberList.getStringTagAt(i));
        }
        return team;
    }
}

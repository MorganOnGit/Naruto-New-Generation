package com.villagesystem.mod.client.gui;

import com.villagesystem.mod.capability.Quest;

import java.util.List;
import java.util.Map;

/** Full data snapshot sent from server to client whenever the GUI opens or needs refreshing. */
public class VillageDisplayData {
    public final String selfName;
    public final String selfVillage;
    public final String selfRank;
    public final String selfTeamName;
    public final boolean selfIsKage;

    public final int villageMemberCount;
    public final String villageKageName;
    public final List<RosterEntry> roster; // everyone in the player's own village

    public final List<Quest> quests; // the player's own quests

    public final Map<String, String> allKages; // village -> kage name, all 6

    public final boolean votingActive;
    public final long votingEndTimeMillis;
    public final Map<String, Integer> voteTally; // candidate -> vote count so far
    public final String selfVotedFor; // empty if the player hasn't voted yet

    public final List<String> teamNamesInVillage;

    public VillageDisplayData(String selfName, String selfVillage, String selfRank, String selfTeamName,
                               boolean selfIsKage, int villageMemberCount, String villageKageName,
                               List<RosterEntry> roster, List<Quest> quests, Map<String, String> allKages,
                               boolean votingActive, long votingEndTimeMillis, Map<String, Integer> voteTally,
                               String selfVotedFor, List<String> teamNamesInVillage) {
        this.selfName = selfName;
        this.selfVillage = selfVillage;
        this.selfRank = selfRank;
        this.selfTeamName = selfTeamName;
        this.selfIsKage = selfIsKage;
        this.villageMemberCount = villageMemberCount;
        this.villageKageName = villageKageName;
        this.roster = roster;
        this.quests = quests;
        this.allKages = allKages;
        this.votingActive = votingActive;
        this.votingEndTimeMillis = votingEndTimeMillis;
        this.voteTally = voteTally;
        this.selfVotedFor = selfVotedFor;
        this.teamNamesInVillage = teamNamesInVillage;
    }
}

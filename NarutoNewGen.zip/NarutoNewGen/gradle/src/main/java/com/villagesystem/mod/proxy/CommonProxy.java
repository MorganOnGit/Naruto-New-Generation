package com.villagesystem.mod.proxy;

import com.villagesystem.mod.client.gui.VillageDisplayData;

public class CommonProxy {

    public void preInit() {
        // nothing needed server-side
    }

    public void openVillageGui(VillageDisplayData data) {
        // intentionally empty on the server side
    }
}

package com.villagesystem.mod;

import com.villagesystem.mod.capability.CapabilityVillageData;
import com.villagesystem.mod.capability.PlayerEventHandler;
import com.villagesystem.mod.command.CommandVillage;
import com.villagesystem.mod.network.NetworkHandler;
import com.villagesystem.mod.proxy.CommonProxy;
import com.villagesystem.mod.worlddata.VotingTickHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;

@Mod(modid = VillageSystemMod.MODID, name = VillageSystemMod.NAME, version = VillageSystemMod.VERSION,
        acceptedMinecraftVersions = "[1.12.2]", dependencies = "required-after:forge")
public class VillageSystemMod {

    public static final String MODID = "villagesystem";
    public static final String NAME = "Village System";
    public static final String VERSION = "1.0.0";

    public static final String[] VILLAGES = { "rain", "cloud", "mist", "leaf", "stone", "sand" };

    @Mod.Instance(MODID)
    public static VillageSystemMod instance;

    @SidedProxy(clientSide = "com.villagesystem.mod.proxy.ClientProxy",
            serverSide = "com.villagesystem.mod.proxy.CommonProxy")
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        CapabilityVillageData.register();
        NetworkHandler.register();
        MinecraftForge.EVENT_BUS.register(new PlayerEventHandler());
        MinecraftForge.EVENT_BUS.register(new VotingTickHandler());
        proxy.preInit();
    }

    @Mod.EventHandler
    public void serverStarting(FMLServerStartingEvent event) {
        event.registerServerCommand(new CommandVillage());
    }
}

package com.villagesystem.mod.network;

import com.villagesystem.mod.VillageSystemMod;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

public class NetworkHandler {

    public static final SimpleNetworkWrapper INSTANCE =
            NetworkRegistry.INSTANCE.newSimpleChannel(VillageSystemMod.MODID);

    private static int id = 0;

    public static void register() {
        INSTANCE.registerMessage(MessageOpenVillageGui.Handler.class, MessageOpenVillageGui.class, id++, Side.CLIENT);
        INSTANCE.registerMessage(MessageVillageAction.Handler.class, MessageVillageAction.class, id++, Side.SERVER);
    }
}

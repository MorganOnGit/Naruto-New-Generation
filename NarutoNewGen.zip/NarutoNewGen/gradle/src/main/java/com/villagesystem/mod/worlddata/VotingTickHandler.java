package com.villagesystem.mod.worlddata;

import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;


/**
 * Checks once every 20 ticks (1 second) for any active Kage vote whose
 * window has ended, tallies it, and promotes the winner automatically.
 * Cheap enough at this interval to not be a lag concern.
 */
public class VotingTickHandler {

    private static final int CHECK_INTERVAL_TICKS = 20;
    private int tickCounter = 0;

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        tickCounter++;
        if (tickCounter < CHECK_INTERVAL_TICKS) return;
        tickCounter = 0;

        MinecraftServer server = FMLCommonHandler.instance().getMinecraftServerInstance();
        if (server == null) return;

        VillageWorldData data = VillageWorldData.get(server.getEntityWorld());

        for (String village : com.villagesystem.mod.VillageSystemMod.VILLAGES) {
            VotingSession session = data.getActiveVote(village);
            if (session == null || !session.isExpired()) continue;

            String winner = session.getWinner();
            data.endVote(village);
            if (winner != null) {
                data.setKage(village, winner);
                announce(server, "\u00A76The " + capitalize(village) + " Village has a new Kage: " + winner + "!");
            } else {
                announce(server, "\u00A76The Kage vote for " + capitalize(village) + " Village ended with no votes cast.");
            }
        }
    }

    private String capitalize(String s) {
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }

    private void announce(MinecraftServer server, String message) {
        for (EntityPlayerMP player : server.getPlayerList().getPlayers()) {
            player.sendMessage(new TextComponentString(message));
        }
    }
}

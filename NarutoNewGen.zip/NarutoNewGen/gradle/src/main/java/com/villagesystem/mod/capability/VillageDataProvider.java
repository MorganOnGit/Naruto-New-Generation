package com.villagesystem.mod.capability;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.common.util.INBTSerializable;

import javax.annotation.Nullable;

public class VillageDataProvider implements ICapabilityProvider, INBTSerializable<NBTTagCompound> {

    private final IVillageData instance = CapabilityVillageData.VILLAGE_DATA_CAPABILITY.getDefaultInstance();

    @Override
    public boolean hasCapability(Capability<?> capability, @Nullable EnumFacing facing) {
        return capability == CapabilityVillageData.VILLAGE_DATA_CAPABILITY;
    }

    @Nullable
    @Override
    @SuppressWarnings("unchecked")
    public <T> T getCapability(Capability<T> capability, @Nullable EnumFacing facing) {
        return capability == CapabilityVillageData.VILLAGE_DATA_CAPABILITY
                ? (T) CapabilityVillageData.VILLAGE_DATA_CAPABILITY.cast(instance)
                : null;
    }

    @Override
    public NBTTagCompound serializeNBT() {
        return instance.writeToNBT();
    }

    @Override
    public void deserializeNBT(NBTTagCompound nbt) {
        instance.readFromNBT(nbt);
    }
}

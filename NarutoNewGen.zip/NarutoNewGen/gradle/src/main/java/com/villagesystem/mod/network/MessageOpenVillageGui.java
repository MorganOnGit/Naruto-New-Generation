package com.villagesystem.mod.network;

import com.villagesystem.mod.VillageSystemMod;
import com.villagesystem.mod.capability.Quest;
import com.villagesystem.mod.client.gui.RosterEntry;
import com.villagesystem.mod.client.gui.VillageDisplayData;
import io.netty.buffer.ByteBuf;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Server -> client packet carrying a full data snapshot for every GUI page
 * at once. Contains no client-only classes - the handler builds a plain
 * data object and hands it to the proxy, which is the only place rendering
 * classes get touched, keeping a dedicated server safe.
 */
public class MessageOpenVillageGui implements IMessage {

    private String selfName, selfVillage, selfRank, selfTeamName;
    private boolean selfIsKage;
    private int villageMemberCount;
    private String villageKageName;
    private List<RosterEntry> roster = new ArrayList<>();
    private List<Quest> quests = new ArrayList<>();
    private Map<String, String> allKages = new HashMap<>();
    private boolean votingActive;
    private long votingEndTimeMillis;
    private Map<String, Integer> voteTally = new HashMap<>();
    private String selfVotedFor = "";
    private List<String> teamNamesInVillage = new ArrayList<>();

    public MessageOpenVillageGui() {
    }

    public MessageOpenVillageGui(VillageDisplayData d) {
        this.selfName = d.selfName;
        this.selfVillage = d.selfVillage;
        this.selfRank = d.selfRank;
        this.selfTeamName = d.selfTeamName;
        this.selfIsKage = d.selfIsKage;
        this.villageMemberCount = d.villageMemberCount;
        this.villageKageName = d.villageKageName;
        this.roster = d.roster;
        this.quests = d.quests;
        this.allKages = d.allKages;
        this.votingActive = d.votingActive;
        this.votingEndTimeMillis = d.votingEndTimeMillis;
        this.voteTally = d.voteTally;
        this.selfVotedFor = d.selfVotedFor;
        this.teamNamesInVillage = d.teamNamesInVillage;
    }

    @Override
    public void toBytes(ByteBuf buf) {
        ByteBufUtils.writeUTF8String(buf, selfName);
        ByteBufUtils.writeUTF8String(buf, selfVillage);
        ByteBufUtils.writeUTF8String(buf, selfRank);
        ByteBufUtils.writeUTF8String(buf, selfTeamName);
        buf.writeBoolean(selfIsKage);
        buf.writeInt(villageMemberCount);
        ByteBufUtils.writeUTF8String(buf, villageKageName);

        buf.writeInt(roster.size());
        for (RosterEntry r : roster) {
            ByteBufUtils.writeUTF8String(buf, r.playerName);
            ByteBufUtils.writeUTF8String(buf, r.rank);
        }

        buf.writeInt(quests.size());
        for (Quest q : quests) {
            ByteBufUtils.writeUTF8String(buf, q.getDescription());
            ByteBufUtils.writeUTF8String(buf, q.getAssignedBy());
            ByteBufUtils.writeUTF8String(buf, q.getStatus().name());
        }

        buf.writeInt(allKages.size());
        for (Map.Entry<String, String> e : allKages.entrySet()) {
            ByteBufUtils.writeUTF8String(buf, e.getKey());
            ByteBufUtils.writeUTF8String(buf, e.getValue());
        }

        buf.writeBoolean(votingActive);
        buf.writeLong(votingEndTimeMillis);
        buf.writeInt(voteTally.size());
        for (Map.Entry<String, Integer> e : voteTally.entrySet()) {
            ByteBufUtils.writeUTF8String(buf, e.getKey());
            buf.writeInt(e.getValue());
        }
        ByteBufUtils.writeUTF8String(buf, selfVotedFor);

        buf.writeInt(teamNamesInVillage.size());
        for (String t : teamNamesInVillage) {
            ByteBufUtils.writeUTF8String(buf, t);
        }
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        selfName = ByteBufUtils.readUTF8String(buf);
        selfVillage = ByteBufUtils.readUTF8String(buf);
        selfRank = ByteBufUtils.readUTF8String(buf);
        selfTeamName = ByteBufUtils.readUTF8String(buf);
        selfIsKage = buf.readBoolean();
        villageMemberCount = buf.readInt();
        villageKageName = ByteBufUtils.readUTF8String(buf);

        int rosterCount = buf.readInt();
        roster = new ArrayList<>();
        for (int i = 0; i < rosterCount; i++) {
            roster.add(new RosterEntry(ByteBufUtils.readUTF8String(buf), ByteBufUtils.readUTF8String(buf)));
        }

        int questCount = buf.readInt();
        quests = new ArrayList<>();
        for (int i = 0; i < questCount; i++) {
            String desc = ByteBufUtils.readUTF8String(buf);
            String assignedBy = ByteBufUtils.readUTF8String(buf);
            Quest.Status status = Quest.Status.valueOf(ByteBufUtils.readUTF8String(buf));
            quests.add(new Quest(desc, assignedBy, status));
        }

        int kageCount = buf.readInt();
        allKages = new HashMap<>();
        for (int i = 0; i < kageCount; i++) {
            allKages.put(ByteBufUtils.readUTF8String(buf), ByteBufUtils.readUTF8String(buf));
        }

        votingActive = buf.readBoolean();
        votingEndTimeMillis = buf.readLong();
        int tallyCount = buf.readInt();
        voteTally = new HashMap<>();
        for (int i = 0; i < tallyCount; i++) {
            voteTally.put(ByteBufUtils.readUTF8String(buf), buf.readInt());
        }
        selfVotedFor = ByteBufUtils.readUTF8String(buf);

        int teamCount = buf.readInt();
        teamNamesInVillage = new ArrayList<>();
        for (int i = 0; i < teamCount; i++) {
            teamNamesInVillage.add(ByteBufUtils.readUTF8String(buf));
        }
    }

    public VillageDisplayData toDisplayData() {
        return new VillageDisplayData(selfName, selfVillage, selfRank, selfTeamName, selfIsKage,
                villageMemberCount, villageKageName, roster, quests, allKages,
                votingActive, votingEndTimeMillis, voteTally, selfVotedFor, teamNamesInVillage);
    }

    public static class Handler implements IMessageHandler<MessageOpenVillageGui, IMessage> {
        @Override
        public IMessage onMessage(MessageOpenVillageGui message, MessageContext ctx) {
            VillageSystemMod.proxy.openVillageGui(message.toDisplayData());
            return null;
        }
    }
}

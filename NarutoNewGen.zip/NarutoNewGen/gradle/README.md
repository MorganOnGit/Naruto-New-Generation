# Village System

Replaces the playerscroll mod. Modid: `villagesystem`, package `com.villagesystem.mod`,
jar comes out as `villagesystem-1.0.0.jar`.

## One-time server setup
Run every line in `one_time_setup_commands.txt` in console once, before anyone
logs in - it creates the 6 FTBUtilities ranks (rain/cloud/mist/leaf/stone/sand)
that get auto-assigned to new players.

## Build
Same drill as playerscroll/prestige: copy `src` into your working MDK (make sure
NO other mod's `com\...` package is still sitting there - only `com\villagesystem`
should be under `src\main\java\com\`), copy this project's `build.gradle` in too,
then `.\gradlew.bat build`. Jar lands in `build\libs\villagesystem-1.0.0.jar`.

## Commands
- `/village open` - opens the GUI (anyone)
- `/village assignvillage <player> <village>` - op-only manual override
- `/village kage startvote <village> <minutes>` - op-only, starts a Kage vote
- `/village kage vote <candidate>` - chat alternative to the GUI vote button
- `/village setrank <player> <genin|chunin|jonin>` - Kage-only, chat alternative to GUI promotions
- `/village quest give <player> <text>` / `quest verify <player>` / `quest turnin` - chat alternatives
- `/village team create <teamName> <joninLeader> <member1> [member2] [member3]` - Kage-only

## Design notes / things to test carefully
- "Number of players in the village" (page 1) counts **currently online**
  members, not everyone ever assigned to that village. If you wanted a
  lifetime total instead, that needs a persistent per-village member list -
  let me know if the online count isn't what you actually wanted.
- Kage voting: an op starts a window for one specific village; when it
  expires (checked once a second), the highest-vote player is automatically
  set as that village's Kage. Ties resolve to whichever candidate happened
  to be tallied first internally - not a fair tiebreak, just what happens by
  default. Flag it if you want a real tiebreak rule (e.g. re-vote, or
  earliest-vote-wins).
- Voting/roster/promotion/quest-giving all only work against players who are
  **currently online** - you can't vote for or promote someone who's offline.
- The GUI refreshes in place after any action (stays on the same page)
  rather than reopening from page 1 - but this only refreshes the acting
  player's own screen, not other village members who might also have the
  GUI open at the same time.
- Team creation caps at 3 regular members + 1 Jonin leader (4 total), per
  your spec. A player can only be in one team at a time in this version
  (creating a new team just overwrites their teamName field) - no explicit
  "leave team" command exists yet if that's needed.
- This is a first pass on a genuinely large feature set (8 GUI pages) - treat
  this like the earlier mods: expect a few rounds of real-server testing to
  shake out bugs, especially around the GUI layout at different screen sizes.
